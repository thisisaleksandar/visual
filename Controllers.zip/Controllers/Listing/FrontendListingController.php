<?php

namespace App\Http\Controllers\Listing;

use App\Http\Controllers\Controller;
use App\Http\Requests\ListingContactRequest;
use App\Services\Listing\ListingService;
use Illuminate\Http\Request;
use App\Models\ListingContact;
use Illuminate\Pagination\LengthAwarePaginator; // Importovan Paginator
use Illuminate\Support\Facades\Request as FacadeRequest; // Alias za Request facade

class FrontendListingController extends Controller
{
    public $listingService;

    public function __construct()
    {
        // Pretpostavka da je ACTIVE definisana konstanta
        if (getOption('LISTING_STATUS', 0) != ACTIVE) {
            abort(404);
        }
        $this->listingService = new ListingService;
    }

   public function list(Request $request) // $request je injected, ne FacadeRequest
{
    $data['pageTitle'] = __('Properties');

    // Dohvati kompletnu listu (pretpostavka: getAllActive vraća kolekciju)
    $listCollection = $this->listingService->getAllActive($request);

    // Učitaj relacije na celoj kolekciji
    // Ovo je neophodno ako getAllActive() u servisu NE radi with('property.propertyUnits')
    // Ako servis VEĆ radi with(), onda je ovaj ->load() suvišan i može se ukloniti.
    $listCollection->load('property.propertyUnits');

    // Mapbox podaci se generišu iz cele kolekcije pre paginacije
    $mapData = [];
    foreach ($listCollection as $listing) {
        if ($listing->latitude && $listing->longitude) {
            // Provera da li listing ima file_name i folder_name (koji su dolazili iz join-a u servisu)
            // Ako ne, koristi coverImageUrl accessor ili default sliku
            $image = ($listing->file_name && $listing->folder_name)
                       ? assetUrl($listing->folder_name . '/' . $listing->file_name)
                       : ($listing->cover_image_url ?? asset('assets/images/default-property.jpg'));


            $mapData[] = [
                'coordinates' => [
                    'lat' => $listing->latitude,
                    'long' => $listing->longitude,
                ],
                'properties' => [
                    'image' => $image,
                    'name' => $listing->name,
                    'popup' => view('listing.frontend.components.details', [
                        'listing' => $listing,
                        'image' => $image,
                        'type' => LISTING_CARD_TYPE_ONE // Pretpostavka da je LISTING_CARD_TYPE_ONE definisana
                    ])->render(),
                ]
            ];
        }
    }
    $data['mapData'] = $mapData;


    // Manuelna paginacija
    $currentPage = FacadeRequest::get('page', 1); // Koristi FacadeRequest za dobijanje 'page' parametra
    $perPage = 12; // Ili config('listing.per_page', 12)

    $data['listings'] = new LengthAwarePaginator(
        $listCollection->forPage($currentPage, $perPage),
        $listCollection->count(),
        $perPage,
        $currentPage,
        ['path' => FacadeRequest::url(), 'query' => FacadeRequest::query()]
    );

    // Filter podaci
    $data['cities']    = $request->state ? $this->listingService->getCitiesByState($request->state) : [];
    $data['bedRooms']  = $this->listingService->getBedRooms();
    $data['bathRooms'] = $this->listingService->getBathRooms();
    $data['kitchens']  = $this->listingService->getKitchenRooms(); // Ostaje getKitchenRooms kao što je bilo u servisu

    return view('listing.frontend.list', $data);
}

    public function details($slug)
    {
        $data['listing'] = $this->listingService->getBySlug($slug);
        if (!$data['listing']) {
            abort(404);
        }
        // Eager load units i za related listings ako je potrebno
        $data['relatedListings'] = $this->listingService->getByCity($data['listing']->city, $slug);
        $data['pageTitle'] = $data['listing']->name;
        $data['images'] = $this->listingService->getImages($data['listing']->id);
        $data['information'] = $this->listingService->getInfoByListId($data['listing']->id);

        $mapDataDetails = [];
        if ($data['listing']->latitude && $data['listing']->longitude) {
            $firstImage = $data['images']?->first();
            $image = $firstImage
                        ? assetUrl($firstImage->folder_name . '/' . $firstImage->file_name)
                        : ($data['listing']->cover_image_url ?? asset('assets/images/default-property.jpg'));

            $mapDataDetails[] = [
                'coordinates' => ['long' => $data['listing']->longitude, 'lat' => $data['listing']->latitude],
                "properties" => [
                    'image' => $image,
                    'name' => $data['listing']->name,
                    'popup' => view('listing.frontend.components.details', [
                        'listing' => $data['listing'],
                        'image' => $image,
                        'type' => LISTING_CARD_TYPE_ONE
                    ])->render()
                ]
            ];
        }
        $data['mapData'] = $mapDataDetails;

        return view('listing.frontend.details', $data);
    }

  public function contactStore(ListingContactRequest $request)
{
    ListingContact::create([
        'listing_id'  => $request->input('listing_id'),
        'name'        => $request->input('name'),
        'email'       => $request->input('email'),
        'phone'       => $request->input('phone'),
        'start_date'  => $request->input('start_date'),
        'end_date'    => $request->input('end_date'),
        'details'     => $request->input('details'),
        'status'      => 1, // Pretpostavka: 1 je neki status npr. 'pending'
    ]);

    return response()->json([
        'status' => true,
        'message' => __('Uspešno ste rezervisali oglas.') // Koristi __() za prevod
    ]);
}
}