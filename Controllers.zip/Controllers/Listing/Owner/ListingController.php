<?php

namespace App\Http\Controllers\Listing\Owner;

use App\Http\Controllers\Controller;
use App\Http\Requests\ListingRequest;
use App\Http\Requests\ListingContactReplyRequest;
use App\Models\ListingContact;
use App\Models\RentUser;
use App\Models\Property;
use App\Models\Listing;
use App\Services\Listing\ListingService;
use App\Traits\ResponseTrait;
use Illuminate\Http\Request;

class ListingController extends Controller
{
    use ResponseTrait;

    protected ListingService $listingService;

    public function __construct(ListingService $listingService)
    {
        // Pretpostavljam da je ACTIVE konstanta definisana
        if (getOption('LISTING_STATUS', 0) != (defined('ACTIVE') ? ACTIVE : 1)) {
            abort(404);
        }
        $this->listingService = $listingService;
    }

    /**
     * Prikaz svih oglasa vlasnika
     */
    public function index()
    {
        $data['pageTitle'] = __('Svi Oglasi'); // Prevod
        $data['listings']  = $this->listingService->getAllByOwner();
        return view('listing.owner.index', $data);
    }

    /**
     * Forma za kreiranje novog oglasa
     */
    public function create()
    {
        $data['pageTitle'] = __('Dodaj Oglas');
        $data['rentUsers']  = RentUser::select('id', 'first_name', 'last_name', 'contact_number')->get();
        $data['properties'] = Property::where('owner_user_id', getOwnerUserId())->get();
        $data['standaloneListings'] = Listing::whereNull('property_id')
                                            ->where('owner_user_id', getOwnerUserId())
                                            ->get(['id', 'name', 'price', 'price_duration_type']); // Dodajemo polja za standalone

        return view('listing.owner.create', $data);
    }

    /**
     * AJAX: Vrati sve listinge za dati property_id ili standalone listinge ako property_id nije prosleđen
     */
    public function getPropertyListings(Request $request)
    {
        $propertyId = $request->query('property_id');
        $ownerUserId = getOwnerUserId();

        $query = Listing::where('owner_user_id', $ownerUserId);

        if ($propertyId) {
            // Ako je odabrana nekretnina, prikaži samo Listing-e povezane sa tom nekretninom
            $query->where('property_id', $propertyId);
        } else {
            // Ako nekretnina nije odabrana, prikaži Standalone Listings
            $query->whereNull('property_id');
        }

        // Dohvatamo samo potrebna polja
        $listings = $query->get(['id', 'name', 'price', 'price_duration_type']);

        // Vraćamo uspeh koristeći ResponseTrait radi konzistentnosti,
        // osiguravajući da JS dobije podatke unutar 'data' ključa.
        return $this->success($listings);
    }

    /**
     * Čuvanje novog oglasa
     */
    public function store(ListingRequest $request)
    {
        return $this->listingService->store($request);
    }

    /**
     * Forma za izmenu postojećeg oglasa
     */
    public function edit(int $id)
    {
        $listing = $this->listingService->getById($id); // Pretpostavka da getById vraća Listing sa svim potrebnim relacijama
        if(!$listing || $listing->owner_user_id != getOwnerUserId()){
             return back()->with('error', __('Oglas nije pronađen ili nemate pristup.')); // Prevod
        }

        $data['pageTitle']   = __('Izmeni Oglas'); // Prevod
        $data['listing']     = $listing;
        $data['images']      = $this->listingService->getImages($id);
        $data['information'] = $this->listingService->getInfoByListId($id); // Pretpostavka da vraća niz informacija
        $data['rentUsers']   = RentUser::select('id', 'first_name', 'last_name', 'contact_number')->get();
        $data['properties']  = Property::where('owner_user_id', getOwnerUserId())->get();

        // Prosleđujemo standalone listinge, uključujući cenu i tip trajanja cene
        $data['standaloneListings'] = Listing::whereNull('property_id')
                                             ->where('owner_user_id', getOwnerUserId())
                                             ->get(['id', 'name', 'price', 'price_duration_type']);

        // Listinzi za trenutno izabrani property (ako postoji)
        if ($listing->property_id) {
            $data['propertyListings'] = Listing::where('property_id', $listing->property_id)
                                              ->where('owner_user_id', getOwnerUserId())
                                              ->get(['id', 'name', 'price', 'price_duration_type']);
        } else {
            $data['propertyListings'] = collect();
        }

        return view('listing.owner.edit', $data);
    }

    /**
     * Ažuriranje oglasa
     */
    public function update(ListingRequest $request, int $id)
    {
        return $this->listingService->update($request, $id);
    }

    /**
     * Brisanje oglasa
     */
    public function destroy(int $id)
    {
        return $this->listingService->delete($id);
    }

    /**
     * Brisanje slike oglasa
     */
    public function imageDelete(int $id)
    {
        return $this->listingService->imageDelete($id);
    }

    /**
     * Prikaz liste kontakata za oglase
     */
    public function contact(Request $request)
    {
        if ($request->ajax()) {
            return $this->listingService->getAllContactByOwner();
        }
        return view('listing.owner.contact', [
            'pageTitle' => __('Lista Kontakata'), // Prevod
        ]);
    }

    /**
     * Podaci za DataTable kontakata
     */
    public function contactData(): \Illuminate\Http\JsonResponse
    {
        $contacts = ListingContact::select('listing_contacts.*', 'listings.name as listing_name')
            ->leftJoin('listings', 'listing_contacts.listing_id', '=', 'listings.id')
            ->whereHas('listing', function ($query) {
                $query->where('owner_user_id', getOwnerUserId());
            })
            ->latest();

        return datatables()->of($contacts)
            ->addIndexColumn()
            ->addColumn('listing_name', fn($row) => $row->listing_name ?? '-')
            ->addColumn('actions', fn($row) => '<a href="#" data-id="'.$row->id.'" class="btn btn-sm btn-info reply">Odgovori</a>')
            ->rawColumns(['actions'])
            ->make(true);
    }

    /**
     * Detalji pojedinačnog kontakta
     */
    public function contactInfo(Request $request)
    {
        $contact = ListingContact::with('listing')->find($request->id);
        if (!$contact || $contact->listing->owner_user_id != getOwnerUserId()) {
            return $this->error([], __('Kontakt nije pronađen ili nemate pristup.')); // Prevod
        }
        return $this->listingService->getContactInfo($request->id);
    }

    /**
     * Odgovor na kontakt upit
     */
    public function contactReply(ListingContactReplyRequest $request)
    {
        $contact = ListingContact::with('listing')->find($request->id);
        if (!$contact || $contact->listing->owner_user_id != getOwnerUserId()) {
            return $this->error([], __('Kontakt nije pronađen ili nemate pristup.')); // Prevod
        }
        return $this->listingService->contactReply($request);
    }
}