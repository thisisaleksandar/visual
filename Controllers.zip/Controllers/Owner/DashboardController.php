<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Property;
use App\Models\Listing;
use App\Models\Tenant;
use App\Models\Notification;
use App\Services\TicketService;
use App\Services\OwnerService;
use Carbon\Carbon;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    protected TicketService $ticketService;

    public function __construct()
    {
        $this->ticketService = new TicketService;

        if (!defined('TENANT_STATUS_ACTIVE')) define('TENANT_STATUS_ACTIVE', 1);
        if (!defined('INVOICE_STATUS_PENDING')) define('INVOICE_STATUS_PENDING', 0);
        if (!defined('INVOICE_STATUS_PAID'))    define('INVOICE_STATUS_PAID', 1);
        if (!defined('INVOICE_STATUS_OVERDUE')) define('INVOICE_STATUS_OVERDUE', 2); // Definiši ovo ako nemaš, npr. ako je status 2 za dospelo
    }

    public function dashboard()
    {
        $ownerId = getOwnerUserId();

        // Statistika
        $totalProperties = Property::where('owner_user_id', $ownerId)->count();
        $totalListings   = Listing::where('owner_user_id', $ownerId)->count();
        $totalTenants    = Tenant::where('owner_user_id', $ownerId)
            ->where('status', TENANT_STATUS_ACTIVE)
            ->count();
        $properties      = Property::withCount('listings') // Osiguraj da Property model ima 'listings' relaciju
            ->where('owner_user_id', $ownerId)
            ->orderByDesc('created_at')
            ->take(3)
            ->get();

        // Tiketi (primer, prilagodi)
        $totalUserTickets = 0;
        $ticketsForDisplay = collect(); // Prazna kolekcija ako se ne koriste tiketi
        // Ako prikazuješ tikete:
        // $totalUserTickets = $this->ticketService->getQuery()
        //     ->where('user_id', $ownerId) // Prilagodi
        //     ->count();
        // $ticketsForDisplay = $this->ticketService->getQuery()
        //     ->where('user_id', $ownerId) // Prilagodi
        //     ->latest()
        //     ->take(5)
        //     ->get();

        $invoices = Invoice::with([
                'tenant' => function ($query) {
                    $query->select('id', 'user_id', 'preferred_payment_method'); // Učitaj samo potrebna polja
                },
                'tenant.user' => function ($query) {
                    $query->select('id', 'first_name', 'last_name'); // Ime iz User modela
                }
            ])
            ->where('owner_user_id', $ownerId)
            // VAŽNO: Ukloni filter po godini za testiranje da vidiš SVE fakture.
            // U PRODUKCIJI, moraš imati efikasan filter po datumu!
            // Npr. ->whereBetween('due_date', [Carbon::now()->startOfMonth(), Carbon::now()->endOfMonth()]) za tekući mesec
            // Ili da FullCalendar šalje start/end datume.
            // Za testiranje:
            // ->whereYear('due_date', 2025) // Ako imaš podatke za 2025.
            ->get();

        $preferredPaymentMethodColorMap = [
            'wu'            => '#FF6600', // Narandžasta
            'postnet'       => '#E61D2B', // Crvena
            'bank_transfer' => '#007bff', // Plava
            'cash'          => '#FFC107', // Žuta
            'manual'        => '#6c757d', // Siva
            'default'       => '#A9A9A9'  // Tamno siva
        ];

        $readablePaymentMethodMap = [
            'wu'            => __('Western Union'),
            'postnet'       => __('PostNet'),
            'bank_transfer' => __('Na račun u banci'),
            'cash'          => __('Gotovina'),
            'manual'        => __('Ručni unos/Ostalo'),
        ];
        $readableInvoiceStatusMap = [
            INVOICE_STATUS_PENDING => __('Na čekanju'),
            INVOICE_STATUS_PAID    => __('Plaćeno'),
            INVOICE_STATUS_OVERDUE => __('Dospelo'), // Pretpostavka da je ovo status za dospelo
        ];

        $calendarEvents = $invoices->map(function($inv) use ($preferredPaymentMethodColorMap, $readablePaymentMethodMap, $readableInvoiceStatusMap) {
            $tenant = $inv->tenant;
            $tenantUser = optional($tenant)->user;

            $tenantNameDisplay = __('Nepoznat stanar');
            if ($tenantUser && $tenantUser->first_name) {
                $tenantNameDisplay = trim($tenantUser->first_name . ' ' . $tenantUser->last_name);
            } elseif ($tenant) {
                $tenantNameDisplay = __('Stanar ID:') . ' ' . $tenant->id; // Fallback
            }

            $invoiceAmountDisplay = number_format($inv->amount ?? 0, 2, ',', '.') . ' ' . ($inv->currency_code ?? getOption('currency_symbol', 'EUR'));

            $preferredMethodKey = strtolower(optional($tenant)->preferred_payment_method ?? '');
            $eventColor = $preferredPaymentMethodColorMap[$preferredMethodKey] ?? $preferredPaymentMethodColorMap['default'];

            $preferredMethodText = $readablePaymentMethodMap[$preferredMethodKey] ?? ($preferredMethodKey ?: __('Nije navedeno'));

            $invoiceStatusKey = $inv->status; // 0=pending, 1=paid, 2=overdue (proveri vrednosti)
            $invoiceStatusText = $readableInvoiceStatusMap[$invoiceStatusKey] ?? __('Status: ') . $invoiceStatusKey;


            // Logika za dospelost ako želiš da ima prioritet za boju ili status text
            $isOverdue = ($invoiceStatusKey == INVOICE_STATUS_PENDING && Carbon::parse($inv->due_date)->isPast() && !Carbon::parse($inv->due_date)->isToday())
                         || $invoiceStatusKey == INVOICE_STATUS_OVERDUE; // Ako imaš poseban status za OVERDUE

            if ($isOverdue && $invoiceStatusKey != INVOICE_STATUS_PAID) { // Samo ako nije plaćena
                // OPCIONO: Preboji dospele u crveno
                // $eventColor = '#dc3545';
                $invoiceStatusText = $readableInvoiceStatusMap[INVOICE_STATUS_OVERDUE] ?? __('Dospelo');
            }

            return [
                'id'            => $inv->id,
                'title'         => $tenantNameDisplay, // Samo ime stanara za kalendar
                'start'         => Carbon::parse($inv->due_date)->toDateString(),
                'color'         => $eventColor,
                'extendedProps' => [
                    'full_title'        => "{$tenantNameDisplay} - {$invoiceAmountDisplay}",
                    'invoice_amount'    => $invoiceAmountDisplay,
                    'due_date_formatted'=> Carbon::parse($inv->due_date)->format(getOption('date_format', 'd.m.Y')),
                    'tenant_id'         => optional($tenant)->id,
                    'preferred_payment_method_text' => $preferredMethodText,
                    'invoice_status_text' => $invoiceStatusText,
                    'invoice_actual_payment_method' => $inv->payment_method, // Stvarni način plaćanja fakture
                    'invoice_actual_payment_status' => $inv->payment_status, // Stvarni status plaćanja fakture
                ],
            ];
        });
        
        // dd($calendarEvents->toArray()); // Za debug, da vidiš šta se šalje u view

        return view('owner.dashboard', [
            'pageTitle'        => __('Kontrolna tabla'),
            'totalProperties'  => $totalProperties,
            'totalListings'    => $totalListings,
            'totalTenants'     => $totalTenants,
            'properties'       => $properties,
            'tickets'          => $ticketsForDisplay, // Šalješ praznu kolekciju ako ne koristiš
            'totalUserTickets' => $totalUserTickets,  // Šalješ 0 ako ne koristiš
            'calendarEvents'   => $calendarEvents,
        ]);
    }

    // ... ostale metode (notification, topSearch) ...
    public function notification()
    {
        if (!defined('ACTIVE')) define('ACTIVE', 1);
        Notification::query()
            ->where(function($q) {
                $q->where('notifications.user_id', getOwnerUserId())
                  ->orWhereNull('notifications.user_id');
            })
            ->where('is_seen', '!=', ACTIVE)
            ->update(['is_seen' => ACTIVE]);

        $notifications = Notification::query()
            ->where(function($q) {
                $q->where('notifications.user_id', getOwnerUserId())
                  ->orWhereNull('notifications.user_id');
            })
            ->orderByDesc('created_at')
            ->paginate(getOption('app_paginate', 10));

        return view('owner.notification', [
            'pageTitle'     => __('Obaveštenja'),
            'notifications' => $notifications
        ]);
    }

    public function topSearch(Request $request)
    {
        $data['status'] = false;
        $searchContent = ['status' => false, 'data' => ''];
        if ($request->keyword) {
            $searchService = new OwnerService();
            $searchContent = $searchService->topSearch($request);
            if ($searchContent['status']) {
                 $data['data']   = view('owner.layouts.top-search-append', $searchContent)->render();
                 $data['status'] = true;
            } else {
                 $data['data'] = '<div class="no-search-results p-3 text-center">Nema rezultata.</div>';
            }
        }
        return response()->json($data);
    }
}