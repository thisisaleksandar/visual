<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RentUser extends Model
{
    protected $table = 'rent_users';

    protected $fillable = [
        'first_name',
        'last_name',
        'contact_number',
        'email',
        'status',
        'western_union',
        'paypal',
        'address',
        'is_company',
        'jmbg',
        'pib',
        'maticni_broj',
        'account_number',
        'city',
        'commission_percentage',
        'is_fixed_commission',
        'fixed_commission_percentage',
    ];

    // Ako nema created_at / updated_at kolone
    public $timestamps = true;

    // Getter za puno ime
    public function getNameAttribute(): string
    {
        return "{$this->first_name} {$this->last_name}";
    }

    // Ako koristiš vezu sa listingom
    public function listings()
    {
        return $this->hasMany(Listing::class, 'rent_user_id');
    }

    // Ako koristiš vezu sa property tabelom (npr. stariji deo sistema)
    public function properties()
    {
        return $this->hasMany(Property::class, 'user_id');
    }
    
    public function units()
{
    return $this->hasMany(\App\Models\Unit::class, 'rent_user_id');
}

}
