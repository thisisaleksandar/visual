<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Http\Requests\RentUserRequest;
use App\Models\RentUser;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class RentUserController extends Controller
{
    public function index(): View
    {
       $rentUsers = RentUser::withCount(['listings', 'properties'])->paginate(15);
        return view('owner.rent_users.index', compact('rentUsers'));
    }

    public function create(): View
    {
        return view('owner.rent_users.create');
    }

    public function store(RentUserRequest $request): RedirectResponse
    {
        $data = $request->validated();

        $data['is_fixed_commission'] = $request->has('is_fixed_commission') ? 1 : 0;

        // Ako nije fiksna, zadrži vrednost commission_percentage
        if (! $data['is_fixed_commission']) {
            $data['fixed_commission_percentage'] = 15.00;
        }

        RentUser::create($data);

        return redirect()
            ->route('owner.rent-users.index')
            ->with('success', 'Rent korisnik je uspešno dodat.');
    }

    public function edit(RentUser $rentUser): View
    {
        return view('owner.rent_users.edit', compact('rentUser'));
    }

    public function update(RentUserRequest $request, RentUser $rentUser): RedirectResponse
    {
        $data = $request->validated();

        $data['is_fixed_commission'] = $request->has('is_fixed_commission') ? 1 : 0;

        if (! $data['is_fixed_commission']) {
            $data['fixed_commission_percentage'] = 15.00;
        }

        $rentUser->update($data);

        return redirect()
            ->route('owner.rent-users.index')
            ->with('success', 'Rent korisnik je uspešno izmenjen.');
    }

    public function destroy(RentUser $rentUser): RedirectResponse
    {
        $rentUser->delete();

        return redirect()
            ->route('owner.rent-users.index')
            ->with('success', 'Rent korisnik je obrisan.');
    }
}
