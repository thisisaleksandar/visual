<?php

namespace App\Http\Controllers\Owner;

use App\Http\Controllers\Controller;
use App\Http\Requests\TenantCloseRequest;
use App\Http\Requests\TenantDeleteRequest;
use App\Http\Requests\TenantRequest;
use App\Services\InvoiceTypeService;
use App\Services\PropertyService;
use App\Services\TenantService;
use App\Services\Listing\ListingService;
use App\Traits\ResponseTrait;
use Illuminate\Http\Request;

class TenantController extends Controller
{
    use ResponseTrait;

    protected TenantService $tenantService;
    protected PropertyService $propertyService;
    protected InvoiceTypeService $invoiceTypeService;
    protected ListingService $listingService;

    public function __construct(
        TenantService $tenantService,
        PropertyService $propertyService,
        InvoiceTypeService $invoiceTypeService,
        ListingService $listingService
    ) {
        $this->tenantService      = $tenantService;
        $this->propertyService    = $propertyService;
        $this->invoiceTypeService = $invoiceTypeService;
        $this->listingService     = $listingService;
    }

    public function index(Request $request)
    {
        $common = [
            'subNavAllTenantMMActiveClass' => 'mm-active',
            'subNavAllTenantActiveClass'   => 'active',
            'pageTitle'                    => __('Stanari'),
            'properties'                   => $this->propertyService->getAll(),
        ];

        if ($request->type === 'history') {
            $data = array_merge($common, [
                'navTenantMMShowClass'           => 'mm-show',
                'subNavTenantHistoryMMActiveClass' => 'mm-active',
                'subNavTenantHistoryActiveClass'   => 'active',
                'pageTitle'                      => __('Istorija Stanara'),
            ]);

            if ($request->ajax()) {
                return $this->tenantService->getAllHistoryData();
            }

            return view('owner.tenants.history', $data);
        }

        if (getOption('app_card_data_show', 1) == 1) {
            $common['tenants'] = $this->tenantService->getAll();
        }

        if ($request->ajax()) {
            return $this->tenantService->getAllData();
        }

        return view('owner.tenants.index', $common);
    }

    public function create()
    {
        if (getOwnerLimit(RULES_TENANT) < 1) {
            return back()->with('error', __('Vaš limit za dodavanje stanara je popunjen.'));
        }

        return view('owner.tenants.add', [
            'pageTitle'                    => __('Dodaj Stanara'),
            'subNavAllTenantMMActiveClass' => 'mm-active',
            'subNavAllTenantActiveClass'   => 'active',
            'properties'                   => $this->propertyService->getAll(),
            'tenant'                       => new \App\Models\Tenant(),
            'listingsForSelectedProperty'  => collect(),
        ]);
    }

    public function edit($id)
    {
        $tenant = $this->tenantService->getById($id);

        $listingsForSelectedProperty = collect();
        if ($tenant && $tenant->property_id) {
            $response = $this->listingService->getByPropertyId($tenant->property_id);
            if (($response->getData()->status ?? false) === true) {
                 $listingsForSelectedProperty = collect($response->getData()->data);
            }
        }

        return view('owner.tenants.add', [
            'pageTitle'                    => __('Izmeni Stanara'),
            'subNavAllTenantMMActiveClass' => 'mm-active',
            'subNavAllTenantActiveClass'   => 'active',
            'tenant'                       => $tenant,
            'properties'                   => $this->propertyService->getAll(),
            'listingsForSelectedProperty'  => $listingsForSelectedProperty,
        ]);
    }

    /**
     * Čuva nove podatke o stanaru (jednokoračna forma).
     *
     * @param TenantRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(TenantRequest $request)
    {
        try {
            $result = $this->tenantService->storeOrUpdateTenantAllData($request);

            // Ako TenantService već vraća validan JSON, samo ga vrati!
            if ($result instanceof \Illuminate\Http\JsonResponse) {
                return $result;
            }

            // Ako je return array ili model, obradi i pošalji JSON:
            return response()->json([
                'success' => true,
                'message' => __('Stanari uspešno sačuvan!'),
                'data'    => $result,
            ]);
        } catch (\Throwable $e) {
            // Sigurno vrati grešku AJAX-u!
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Ažurira postojeće podatke o stanaru (jednokoračna forma).
     *
     * @param TenantRequest $request
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(TenantRequest $request, $id)
    {
        try {
            $result = $this->tenantService->storeOrUpdateTenantAllData($request);

            if ($result instanceof \Illuminate\Http\JsonResponse) {
                return $result;
            }

            return response()->json([
                'success' => true,
                'message' => __('Stanari uspešno izmenjen!'),
                'data'    => $result,
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function details(Request $request, $id)
    {
        $tenantDetails = $this->tenantService->getDetailsById($id);

        $common = [
            'navTenantMMShowClass'         => 'mm-show',
            'subNavAllTenantMMActiveClass' => 'mm-active',
            'subNavAllTenantActiveClass'   => 'active',
            'tenant'                       => $tenantDetails,
        ];

        switch ($request->tab) {
            case 'profile':
                $common['pageTitle']                 = __('Profil');
                $common['navTenantProfileActiveClass'] = 'active';
                $common['paymentDueInvoiceCount']    = $this->tenantService->paymentDue($id)->count();
                return view('owner.tenants.details.profile', $common);

            case 'home':
                $common['pageTitle']               = __('Detalji Doma');
                $common['navTenantHomeActiveClass'] = 'active';
                return view('owner.tenants.details.home', $common);

            case 'payment':
                $common['pageTitle']                 = __('Detalji Plaćanja');
                $common['navTenantPaymentActiveClass'] = 'active';
                $common['invoiceTypes']              = $this->invoiceTypeService->getAll();
                if ($request->ajax()) {
                    return $this->tenantService->payment($id);
                }
                return view('owner.tenants.details.payment', $common);

            case 'document':
                $common['pageTitle']                  = __('Dokumenta');
                $common['navTenantDocumentActiveClass'] = 'active';
                return view('owner.tenants.details.document', $common);

            case 'closing-history':
                $common['pageTitle']                    = __('Istorija Zatvaranja');
                $common['navTenantClosingHistoryActiveClass'] = 'active';
                $common['tenant']                       = $this->tenantService->closingStatusHistory($id);
                return view('owner.tenants.details.closing-history', $common);

            default:
                abort(404);
        }
    }

    public function closeHistoryStore(TenantCloseRequest $request, $id)
    {
        return $this->tenantService->closeHistoryStore($request, $id);
    }

    public function documentDestroy($id)
    {
        return $this->tenantService->documentDestroy($id);
    }

    public function delete(TenantDeleteRequest $request)
    {
        return $this->tenantService->delete($request);
    }
}
