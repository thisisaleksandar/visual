@extends('saas.frontend.layouts.app')
@section('content')
    <div class="property-details-area pt-0 bg-white">
        {{-- BANER I NAVIGACIJA --}}
        <div class="row">
            <div class="col-md-12">
                <div class="property-bander-text bg-white py-3 px-3 shadow-sm mb-4">
                    <h5 class="property-bander-header mb-1">{{ __('Detalji Nekretnine') }}</h5>
                    <p class="property-home-part mb-0">
                        <a href="{{ route('frontend') }}">{{ __('Početna') }} </a> / <a
                            href="{{ route('listings') }}">{{ __('Nekretnine') }}</a> /
                        {{ $listing->name }}
                    </p>
                </div>
            </div>
        </div>

        <div class="container">
            {{-- SLIDER SLIKA --}}
            <div class="row">
                <div class="col-md-12">
                    <div class="property-slider-area owl-carousel mb-4">
                        @if(isset($images) && $images->count() > 0)
                            @foreach ($images as $image)
                                <div class="single-property-slider">
                                    <img src="{{ assetUrl($image->folder_name . '/' . $image->file_name) }}"
                                        alt="{{ $listing->name }}" class="img-fluid rounded" style="max-height: 500px; object-fit: cover;">
                                </div>
                            @endforeach
                        @else
                             <div class="single-property-slider">
                                <img src="{{ asset('assets/images/default-property.jpg') }}"
                                    alt="{{ $listing->name }}" class="img-fluid rounded" style="max-height: 500px; object-fit: cover;">
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            <div class="row">
                {{-- LEVA KOLONA - OPIS, SPECIFIKACIJE --}}
                <div class="col-lg-7">
                    <div class="property-description-area p-3 border rounded shadow-sm mb-4">
                        <h4 class="property-description-title border-bottom pb-2 mb-3">{{ __('Opis') }}</h4>
                        <p class="property-description-info">{!! $listing->details !!}</p>

                        <div class="location-property-area mt-3 pt-3 border-top">
                            <p class="location-name mb-1 fw-bold">{{ __('Lokacija') }}:</p>
                            <h4 class="location-title h5">{{ $listing->address }}</h4>
                            <h6 class="property-price mt-2">
                                {{ __('Cena') }} : <span class="fw-bold text-primary"> {{ currencyPrice($listing->price) }}/
                                    @if (isset($listing->price_duration_type) && $listing->price_duration_type == 1) {{-- Pretpostavljena vrednost za MONTHLY --}}
                                        {{ __('Mesec') }}
                                    @elseif (isset($listing->price_duration_type) && $listing->price_duration_type == 2) {{-- Pretpostavljena vrednost za YEARLY --}}
                                        {{ __('Godina') }}
                                    @elseif (isset($listing->price_duration_type) && $listing->price_duration_type == 3) {{-- Pretpostavljena vrednost za CUSTOM --}}
                                        {{ __('Po Dogovoru') }}
                                    @else
                                        {{ __('Dan') }}
                                    @endif
                                </span>
                            </h6>
                        </div>
                    </div>

                    <div class="single-property-specie p-3 border rounded shadow-sm mb-4">
                        <h5 class="specie-catagories border-bottom pb-2 mb-3">{{ __('Specifikacija') }}</h5>
                        <div class="specie-list">
                            <div class="row">
                                @if ($listing->bed_room)
                                    <div class="col-md-6"><p class="specie-list-text"><i><img src="{{ asset('assets/images/properties-img/arrow.png') }}"></i> {{ __('Spavaće Sobe') }}: <span>{{ $listing->bed_room }}</span></p></div>
                                @endif
                                @if ($listing->bath_room)
                                    <div class="col-md-6"><p class="specie-list-text"><i><img src="{{ asset('assets/images/properties-img/arrow.png') }}"></i> {{ __('Kupatila') }}: <span>{{ $listing->bath_room }}</span></p></div>
                                @endif
                                @if ($listing->kitchen_room)
                                    <div class="col-md-6"><p class="specie-list-text"><i><img src="{{ asset('assets/images/properties-img/arrow.png') }}"></i> {{ __('Kuhinje') }}: <span>{{ $listing->kitchen_room }}</span></p></div>
                                @endif
                                @if ($listing->dining_room)
                                    <div class="col-md-6"><p class="specie-list-text"><i><img src="{{ asset('assets/images/properties-img/arrow.png') }}"></i> {{ __('Trpezarije') }}: <span>{{ $listing->dining_room }}</span></p></div>
                                @endif
                                @if ($listing->living_room)
                                    <div class="col-md-6"><p class="specie-list-text"><i><img src="{{ asset('assets/images/properties-img/arrow.png') }}"></i> {{ __('Dnevne Sobe') }}: <span>{{ $listing->living_room }}</span></p></div>
                                @endif
                                @if ($listing->storage_room)
                                    <div class="col-md-6"><p class="specie-list-text"><i><img src="{{ asset('assets/images/properties-img/arrow.png') }}"></i> {{ __('Ostave') }}: <span>{{ $listing->storage_room }}</span></p></div>
                                @endif
                            </div>
                            @if(isset($listing->other_room) && !empty(trim($listing->other_room)))
                                <h6 class="mt-2 mb-1">{{ __('Ostale prostorije') }}:</h6>
                                @foreach (explode(',', $listing->other_room) as $room)
                                    @if (trim($room))
                                        <p class="specie-list-text mb-1"><i><img src="{{ asset('assets/images/properties-img/arrow.png') }}"></i> <span>{{ trim($room) }}</span></p>
                                    @endif
                                @endforeach
                            @endif
                        </div>
                    </div>

                    <div class="single-property-specie p-3 border rounded shadow-sm mb-4">
                        <h5 class="specie-catagories border-bottom pb-2 mb-3">{{ __('Dodatni Detalji Nekretnine') }}</h5>
                        <div class="specie-list">
                             <p class="specie-list-text"><i><img src="{{ asset('assets/images/properties-img/arrow.png') }}"></i> {{ __('Enterijer') }}: <span>{{ $listing->interior ?? __('Nije navedeno') }}</span></p>
                             <p class="specie-list-text"><i><img src="{{ asset('assets/images/properties-img/arrow.png') }}"></i> {{ __('Tip Nekretnine') }}: <span>{{ $listing->type ?? __('Nije navedeno') }}</span></p>
                        </div>
                    </div>

                    @if(isset($listing->amenities) && !empty(json_decode($listing->amenities)))
                    <div class="single-property-specie p-3 border rounded shadow-sm mb-4">
                        <h5 class="specie-catagories border-bottom pb-2 mb-3">{{ __('Sadržaji') }}</h5>
                        <div class="specie-list row">
                            @foreach (json_decode($listing->amenities) ?? [] as $amenityKey)
                                <div class="col-md-6">
                                    <p class="specie-list-text"><i><img src="{{ asset('assets/images/properties-img/arrow.png') }}"></i> {{ getPropertyAmenities($amenityKey) }}</p>
                                </div>
                            @endforeach
                        </div>
                    </div>
                    @endif
                </div>

                {{-- DESNA KOLONA - VLASNIK, MAPA, DUGME ZA KONTAKT --}}
                <div class="col-lg-5">
                    <div class="property-woner-location sticky-lg-top" style="top: 20px;">
                        <div class="property-woner-info p-3 border rounded shadow-sm mb-3">
                            <div class="property-woner-image text-center mb-2">
                                @php
                                    $ownerName = __('Vlasnik');
                                    $ownerImage = asset('assets/images/default-user.png');
                                    if ($listing->owner_user_id && $listing->ownerUser) { // Pretpostavka da je relacija ownerUser
                                        $ownerName = $listing->ownerUser->first_name . ' ' . $listing->ownerUser->last_name;
                                        if ($listing->ownerUser->image && $listing->ownerUser->image->file_name) { // Provera za sliku vlasnika
                                            $ownerImage = assetUrl($listing->ownerUser->image->folder_name . '/' . $listing->ownerUser->image->file_name);
                                        }
                                    }
                                @endphp
                                <img src="{{ $ownerImage }}" alt="{{ $ownerName }}" class="img-fluid rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">
                            </div>
                            <div class="property-woner-name-location text-center">
                                <h5 class="property-woner-name mb-1">{{ $ownerName }}</h5>
                                @if($listing->owner_user_id && $listing->ownerUser && $listing->ownerUser->contact_number)
                                <p class="mb-0"><i class="fas fa-phone-alt me-1"></i> <a href="tel:{{ $listing->ownerUser->contact_number }}">{{ $listing->ownerUser->contact_number }}</a></p>
                                @endif
                                @if($listing->owner_user_id && $listing->ownerUser && $listing->ownerUser->email)
                                <p class="mt-1 mb-0"><i class="far fa-envelope me-1"></i> <a href="mailto:{{ $listing->ownerUser->email }}">{{ $listing->ownerUser->email }}</a></p>
                                @endif
                            </div>
                        </div>

                        <div class="property-location-area map-embed-wrapper border rounded shadow-sm mb-3" style="overflow: hidden;">
                            <iframe
                                src="https://maps.google.com/maps?q={{ $listing->latitude ?? '44.7866' }},{{ $listing->longitude ?? '20.4489' }}&hl=sr&z=15&output=embed"
                                width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>

                        <button class="theme-btn py-2 px-4 w-100" data-bs-toggle="modal"
                            data-bs-target="#contactModal">{{ __('Kontaktirajte / Rezervišite') }}</button>
                    </div>
                </div>
            </div>

            {{-- INFORMACIJE O OKOLINI --}}
            @if(isset($information) && $information->count() > 0)
            <div class="row mt-5">
                <div class="col-md-12 text-center mb-4">
                    <h4 class="related-title h2">{{ __('Informacije o Okolini') }}</h4>
                </div>
                @foreach ($information as $info)
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="single-nearby-info h-100 border rounded p-3 shadow-sm text-center">
                             @if($info->file_name)
                            <div class="nearby-image mb-2">
                                <img src="{{ assetUrl($info->folder_name . '/' . $info->file_name) }}" alt="{{ $info->name }}" class="img-fluid rounded" style="max-height: 150px; width:auto;">
                            </div>
                            @endif
                            <div class="nearby-info">
                                <h6 class="nearby-name fw-bold">{{ $info->name }}</h6>
                                @if($info->details)
                                <p class="nearby-details small text-muted">{!! Str::limit(strip_tags($info->details), 70, '...') !!}</p>
                                @endif
                                @if($info->distance)
                                <p class="distance-nearby mb-1"><small>{{ __('Udaljenost') }}: <span>{{ $info->distance }}</span></small></p>
                                @endif
                                @if($info->contact_number)
                                <p class="nearby-contact mb-0"><small>{{ __('Kontakt') }}: <a href="tel:{{ $info->contact_number }}">{{ $info->contact_number }}</a></small> </p>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            @endif

            {{-- PREDNOSTI --}}
            @if(isset($listing->advantage) && !empty(json_decode($listing->advantage)))
            <div class="row mt-4">
                <div class="col-lg-12">
                    <div class="single-property-specie p-3 border rounded shadow-sm">
                        <h5 class="specie-catagories border-bottom pb-2 mb-3">{{ __('Prednosti Nekretnine') }}</h5>
                        <div class="specie-list row">
                            @foreach (json_decode($listing->advantage) ?? [] as $advantageKey)
                                <div class="col-md-6">
                                    <p class="specie-list-text"><i><img src="{{ asset('assets/images/properties-img/arrow.png') }}"></i> {{ getPropertyAdvantages($advantageKey) }}</p>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>

    {{-- SRODNE NEKRETNINE --}}
    @if(isset($relatedListings) && $relatedListings->count() > 0)
    <div class="related-properties mt-5 py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center mb-4">
                    <h4 class="related-title h2">{{ __('Srodne Nekretnine') }}</h4>
                </div>
            </div>
            <div class="row">
                @foreach ($relatedListings as $relatedListing)
                    @php
                        $firstRelImage = null;
                        if ($relatedListing->images()->exists() && $relatedListing->images->first()->fileManager) {
                            $firstRelImage = $relatedListing->images->first()->fileManager;
                        }
                    @endphp
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="all-single-properties h-100 shadow-sm rounded overflow-hidden">
                            <div class="single-properties h-100 d-flex flex-column">
                                <div class="properties-img">
                                    <a href="{{ route('listing.details', $relatedListing->slug) }}">
                                        <img src="{{ $firstRelImage ? assetUrl($firstRelImage->folder_name . '/' . $firstRelImage->file_name) : asset('assets/images/default-property.jpg') }}"
                                             alt="{{ $relatedListing->name }}" class="img-fluid w-100" style="object-fit: cover; height: 230px;">
                                    </a>
                                </div>
                                <div class="properties-text-info p-3 flex-grow-1 d-flex flex-column">
                                    <h5 class="properties-name"><a href="{{ route('listing.details', $relatedListing->slug) }}" class="text-decoration-none text-dark stretched-link-pseudo">{{ Str::limit($relatedListing->name, 35) }}</a></h5>
                                    <div class="properties-location d-flex align-items-center mb-2 text-muted small">
                                        <i class="fas fa-map-marker-alt me-2"></i>
                                        <p class="mb-0">{{ Str::limit($relatedListing->address, 40) }}</p>
                                    </div>
                                    <div class="room-details mb-2 small">
                                        @if($relatedListing->interior)
                                        <span class="me-3"><i class="fas fa-ruler-combined me-1"></i>{{ $relatedListing->interior }} {{ __('m²') }}</span>
                                        @endif
                                        @if($relatedListing->bed_room)
                                        <span class="me-3"><i class="fas fa-bed me-1"></i>{{ $relatedListing->bed_room }} {{ $relatedListing->bed_room == 1 ? __('Soba') : __('Sobe') }}</span>
                                        @endif
                                    </div>
                                    <p class="price-properties mt-auto mb-0 fw-bold text-primary">
                                        {{ currencyPrice($relatedListing->price) }}/
                                        @if (isset($relatedListing->price_duration_type) && $relatedListing->price_duration_type == 1) {{ __('Mesec') }}
                                        @elseif (isset($relatedListing->price_duration_type) && $relatedListing->price_duration_type == 2) {{ __('Godina') }}
                                        @elseif (isset($relatedListing->price_duration_type) && $relatedListing->price_duration_type == 3) {{ __('Po Dogovoru') }}
                                        @else {{ __('Dan') }}
                                        @endif
                                    </p>
                                    {{-- Dugme je uklonjeno jer je cela kartica link --}}
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif

    {{-- MODALNA FORMA ZA KONTAKT / REZERVACIJU SA KALENDAROM --}}
    <div class="modal fade bd-example-modal-lg" id="contactModal" tabindex="-1" aria-labelledby="contactModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg customs-model">
            <div class="modal-content">
                <div class="customs-model-content p-4">
                    <div class="contact-us text-center mb-4">
                        <h5 class="modal-title" id="contactModalLabel">{{ __('Rezervacija za Nekretninu') }}: <br><strong>{{ $listing->name }}</strong></h5>
                    </div>
                    <div class="contact-us-from-properties">
                        <form class="ajax" action="{{ route('listing.contact.store') }}" method="POST" data-handler="getShowMessage">
                            @csrf
                            <input type="hidden" name="listing_id" value="{{ $listing->id }}">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="modal_contact_name" class="form-label">{{ __('Puno Ime') }} <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" placeholder="{{ __('Unesite puno ime') }}" id="modal_contact_name" name="name" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="modal_contact_email" class="form-label">{{ __('Email Adresa') }} <span class="text-danger">*</span></label>
                                    <input class="form-control" type="email" placeholder="{{ __('Unesite email adresu') }}" id="modal_contact_email" name="email" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="modal_contact_phone" class="form-label">{{ __('Broj Telefona') }}</label>
                                    <input class="form-control" type="text" placeholder="{{ __('Unesite broj telefona') }}" id="modal_contact_phone" name="phone">
                                </div>
                                <div class="col-md-6 mb-3">
                                    {{-- Prazno mesto gde je bila profesija, da bi datumi bili u istom redu --}}
                                </div>


                                <div class="col-md-6 mb-3">
                                    <label for="start-date-picker" class="form-label">{{ __('Datum Dolaska') }} <span class="text-danger">*</span></label>
                                    <input type="text" name="start_date" id="start-date-picker" class="form-control" placeholder="{{ __('DD.MM.GGGG') }}" autocomplete="off" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="end-date-picker" class="form-label">{{ __('Datum Odlaska') }} <span class="text-danger">*</span></label>
                                    <input type="text" name="end_date" id="end-date-picker" class="form-control" placeholder="{{ __('DD.MM.GGGG') }}" autocomplete="off" required>
                                </div>

                                <div class="col-lg-12 mb-3">
                                    <label for="modal_contact_details" class="form-label">{{ __('Dodatna Poruka') }}</label>
                                    <textarea name="details" id="modal_contact_details" class="form-control" rows="3" placeholder="{{ __('Unesite dodatne zahteve ili pitanja') }}"></textarea>
                                </div>
                                <div class="col-lg-12 mt-2">
                                    <div class="submit-box-text d-flex justify-content-end">
                                        <button type="button" data-bs-dismiss="modal" class="btn btn-outline-secondary py-2 px-4 me-2">{{ __('Otkaži') }}</button>
                                        <button type="submit" class="btn theme-btn py-2 px-4">{{ __('Pošalji Upit') }}</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('style')
    <link rel="stylesheet" href="{{ asset('assets/properties/css/properties.css') }}">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

    <style>
        .property-slider-area .owl-nav button {
            font-size: 1.8rem; color: #555; position: absolute; top: 50%; transform: translateY(-50%);
            background: rgba(255,255,255,0.8) !important; padding: 8px 15px !important; border-radius: 50% !important;
            transition: all 0.3s ease;
        }
        .property-slider-area .owl-nav button:hover { color: var(--bs-primary, #0d6efd); background: rgba(255,255,255,1) !important; box-shadow: 0 0 10px rgba(0,0,0,0.2); }
        .property-slider-area .owl-prev { left: -25px; }
        .property-slider-area .owl-next { right: -25px; }
        @media (max-width: 767px) {
            .property-slider-area .owl-prev { left: 5px; }
            .property-slider-area .owl-next { right: 5px; }
        }

        .ui-datepicker { z-index: 9999 !important; }
        .specie-list-text i img { width: 12px; margin-right: 5px; vertical-align: middle; }
        .nearby-title, .related-title { font-weight: 600; margin-bottom: 1.5rem; }
        .all-single-properties:hover { transform: translateY(-5px); transition: transform 0.3s ease-out; }
        .stretched-link-pseudo::after { position: absolute; top: 0; right: 0; bottom: 0; left: 0; z-index: 1; content: "";}
        .customs-model .form-label { margin-bottom: 0.3rem; font-weight: 500; }
    </style>
@endpush

@push('script')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    {{-- Uključite srpsku lokalizaciju za datepicker ako je imate --}}
    {{-- <script src="path/to/datepicker-sr.js"></script> --}}
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.13.2/i18n/datepicker-sr.js"></script>


    <script>
        $(document).ready(function() {
            if ($('.property-slider-area').length && typeof $.fn.owlCarousel === 'function') {
                $('.property-slider-area').owlCarousel({
                    loop: ($('.property-slider-area .single-property-slider').length > 1),
                    margin: 15,
                    nav: true,
                    dots: true, // Vraćene tačkice za navigaciju
                    navText: ['<i class="fas fa-chevron-left"></i>', '<i class="fas fa-chevron-right"></i>'],
                    items: 1 // Uvek jedna glavna slika
                });
            }

            $(document).on('shown.bs.modal', '#contactModal', function () {
                initializeDatepickers();
            });
        });

        function initializeDatepickers() {
            if (typeof $.fn.datepicker !== 'function') {
                console.error("jQuery UI Datepicker nije učitan!");
                return;
            }

            try {
                if ($("#start-date-picker").hasClass('hasDatepicker')) { $("#start-date-picker").datepicker("destroy"); }
                if ($("#end-date-picker").hasClass('hasDatepicker')) { $("#end-date-picker").datepicker("destroy"); }
            } catch(e) { console.warn("Greška pri uništavanju datepickera:", e); }

            // Postavljanje srpske lokalizacije ako je fajl učitan
            if($.datepicker.regional['sr']) {
                $.datepicker.setDefaults($.datepicker.regional['sr']);
            }


            let startDateSelected, endDateSelected;

            $("#start-date-picker").datepicker({
                dateFormat: 'dd.mm.yy',
                minDate: 0,
                changeMonth: true,
                changeYear: true,
                numberOfMonths: 1, // Prikazuje jedan mesec
                onSelect: function(dateText) {
                    startDateSelected = $(this).datepicker('getDate');
                    $("#end-date-picker").datepicker("option", "minDate", startDateSelected);
                    if (endDateSelected && endDateSelected < startDateSelected) {
                        $("#end-date-picker").val('');
                        endDateSelected = null;
                    }
                }
            });

            $("#end-date-picker").datepicker({
                dateFormat: 'dd.mm.yy',
                minDate: 0,
                changeMonth: true,
                changeYear: true,
                numberOfMonths: 1,
                onSelect: function(dateText) {
                    endDateSelected = $(this).datepicker('getDate');
                    startDateSelected = $("#start-date-picker").datepicker('getDate'); // Uvek pročitaj
                    if (startDateSelected && endDateSelected < startDateSelected) {
                        alert("Datum odlaska ne može biti pre datuma dolaska.");
                        $(this).val('');
                        endDateSelected = null;
                    }
                }
            });
        }

        $('form.ajax').on('submit', function(e) {
            const startDateStr = $('#start-date-picker').val();
            const endDateStr = $('#end-date-picker').val();

            if (startDateStr && endDateStr) {
                let startDate, endDate;
                try {
                    startDate = $.datepicker.parseDate('dd.mm.yy', startDateStr);
                    endDate = $.datepicker.parseDate('dd.mm.yy', endDateStr);
                } catch (parseError) {
                    alert('Format datuma nije ispravan. Koristite DD.MM.GGGG');
                    e.preventDefault();
                    return;
                }
                if (endDate < startDate) {
                    e.preventDefault();
                    alert("Datum odlaska ne može biti pre datuma dolaska.");
                }
            }
        });
    </script>
@endpush