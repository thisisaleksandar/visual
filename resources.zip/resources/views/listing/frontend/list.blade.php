@extends('saas.frontend.layouts.app')

@section('content')
    <div>
        {{-- SEKCIJA SA POZADINSKOM SLIKOM ZA FORMU --}}
        <div class="search-form-background-section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <form id="searchForm"
                              action="{{ route('listings') }}"
                              method="GET"
                              class="properties-filter d-flex flex-wrap justify-content-center">
                          {{-- Keyword --}}
                          <div class="properties-search me-2">
                            <div class="search-icon"><i class="ri-search-line"></i></div>
                            <input type="search" name="q" placeholder="Pretraži..." value="{{ request('q') }}" class="form-control">
                          </div>
                          {{-- Location --}}
                          <div class="single-filter me-2">
                            <select name="location" id="location-filter" class="form-select">
                              <option value="">Izaberi deo grada</option>
                              @foreach([
                                'strogi-centar'=>'Strogi Centar','vozdovac'=>'Voždovac','zvezdara'=>'Zvezdara',
                                'palilula'=>'Palilula','novi-beograd'=>'Novi Beograd','beograd-na-vodi'=>'Beograd na vodi',
                                'a-blok-savada'=>'A blok','centar'=>'Centar','vidikovac'=>'Vidikovac',
                                'vracar'=>'Vračar','savski-venac'=>'Savski venac','zemun'=>'Zemun',
                                'belvil'=>'Belvil','cukarica'=>'Čukarica','splavovi'=>'Splavovi',
                                'dorcol'=>'Dorćol','zarkovo'=>'Žarkovo','banovo-brdo'=>'Banovo brdo',
                                'slavija'=>'Slavija','sumice'=>'Šumice'
                              ] as $val => $label)
                                <option value="{{ $val }}" {{ request('location') == $val ? 'selected' : '' }}>
                                  {{ $label }}
                                </option>
                              @endforeach
                            </select>
                          </div>
                          {{-- Datum prijave --}}
                          <div class="single-filter me-2 position-relative">
                            <i class="ri-calendar-line calendar-icon"></i>
                            <input type="text"
                                   name="date_in"
                                   id="date-in-filter"
                                   placeholder="Datum prijave"
                                   autocomplete="off"
                                   class="hasDatepicker form-control">
                          </div>
                          {{-- Datum odjave --}}
                          <div class="single-filter me-2 position-relative">
                            <i class="ri-calendar-line calendar-icon"></i>
                            <input type="text"
                                   name="date_out"
                                   id="date-out-filter"
                                   placeholder="Datum odjave"
                                   autocomplete="off"
                                   class="hasDatepicker form-control">
                          </div>
                          {{-- Broj gostiju --}}
                          <div class="single-filter me-2">
                            <select name="people" id="people-filter" class="form-select">
                              <option value="">Broj gostiju</option>
                              @for($i=1; $i<=10; $i++)
                                <option value="{{ $i }}" {{ request('people') == $i ? 'selected' : '' }}>
                                  {{ $i }}
                                </option>
                              @endfor
                            </select>
                          </div>
                          {{-- Struktura --}}
                          <div class="single-filter me-2">
                            <select name="structure" id="structure-filter" class="form-select">
                              <option value="">Struktura</option>
                              <option value="1" {{ request('structure')=='1'?'selected':'' }}>Jednosoban</option>
                              <option value="2" {{ request('structure')=='2'?'selected':'' }}>Dvosoban</option>
                              <option value="3" {{ request('structure')=='3'?'selected':'' }}>Trosoban</option>
                              <option value="4" {{ request('structure')=='4'?'selected':'' }}>Četvorosoban</option>
                            </select>
                          </div>
                          {{-- Cena --}}
                          <div class="single-filter me-2">
                            <select name="price" id="price-filter" class="form-select">
                              <option value="">Cena</option>
                              <option value="20-50"  {{ request('price')=='20-50'?'selected':'' }}>20€–50€</option>
                              <option value="50-100" {{ request('price')=='50-100'?'selected':'' }}>50€–100€</option>
                              <option value="100-150"{{ request('price')=='100-150'?'selected':'' }}>100€–150€</option>
                              <option value="150-250"{{ request('price')=='150-250'?'selected':'' }}>150€–250€</option>
                              <option value="250-500"{{ request('price')=='250-500'?'selected':'' }}>250€–500€</option>
                            </select>
                          </div>
                          {{-- Parking --}}
                          <div class="single-filter form-check form-switch me-2">
                            <input class="form-check-input" type="checkbox" id="parking-filter" name="parking" value="1"
                                   {{ request('parking')?'checked':'' }}>
                            <label class="form-check-label" for="parking-filter">Parking</label>
                          </div>
                          {{-- Jacuzzi --}}
                          <div class="single-filter form-check form-switch me-2">
                            <input class="form-check-input" type="checkbox" id="jacuzzi-filter" name="jacuzzi" value="1"
                                   {{ request('jacuzzi')?'checked':'' }}>
                            <label class="form-check-label" for="jacuzzi-filter">Jacuzzi</label>
                          </div>
                          {{-- Dostupno odmah --}}
                          <div class="single-filter form-check form-switch me-2">
                            <input class="form-check-input" type="checkbox" id="is_instant_filter" name="is_instant" value="1"
                                   {{ request('is_instant') ? 'checked' : '' }}>
                            <label class="form-check-label" for="is_instant_filter">Dostupno odmah</label>
                          </div>
                          {{-- Osveži + Pretraži --}}
                          <div class="single-filter d-flex align-items-center">
                            <button type="button" class="btn btn-link me-2 p-0 text-decoration-none" onclick="returnToDefault()">
                              Osveži
                            </button>
                            <button type="submit" class="theme-btn btn btn-primary">Pretraži</button>
                          </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        {{-- KRAJ SEKCIJE SA POZADINSKOM SLIKOM ZA FORMU --}}


        {{-- Mapa i lista nekretnina --}}
        <div class="container-fluid p-0 mt-4">
            <div class="row g-0">
                @if (isset($listings) && $listings->count() > 0)
                    <div class="col-lg-4">
                        <div class="map-area">
                            {{-- === POČETAK EMBEDOVANE GOOGLE MAPE BEOGRADA === --}}
                            <div id="map_embed_container" class="w-100 h-100 map-embed-wrapper-list">
                                <iframe
                                    width="100%"
                                    height="100%"
                                    style="border:0;"
                                    loading="lazy"
                                    allowfullscreen
                                    referrerpolicy="no-referrer-when-downgrade"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d90585.60479616793!2d20.38006505408015!3d44.81523244986471!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475a7aa3d73755a9%3A0x9095c37f67bcff36!2sBeograd!5e0!3m2!1ssr!2srs!4v1700000000000">
                                </iframe>
                            </div>
                            {{-- === KRAJ EMBEDOVANE GOOGLE MAPE BEOGRADA === --}}
                        </div>
                    </div>
                    <div class="col-lg-8 ps-lg-3">
                        <div class="row gx-3 gy-3">
                            {{-- START OF REPLACED BLOCK AS PER YOUR INSTRUCTION --}}
                            @foreach ($listings as $listing)
                                {{-- ─── KARTICA LISTINGA ─── --}}
                                <div class="col-md-6 col-lg-6 col-xl-4">
                                    <div class="all-single-properties h-100">
                                        <div class="single-properties mb-0 h-100">
                                            {{-- Content for listing card (slika, naziv, meta, detalji) --}}
                                            <div class="properties-img">
                                                <img src="{{ $listing->file_name
                                                    ? assetUrl($listing->folder_name . '/' . $listing->file_name)
                                                    : asset('assets/images/default-property.jpg') }}"
                                                     alt="{{ $listing->name }}">
                                            </div>
                                            <div class="properties-text-info">
                                                <h5 class="properties-name">{{ Str::limit($listing->name, 40) }}</h5>
                                                <div class="d-flex align-items-center gap-2 mb-2">
                                                    <span class="badge bg-secondary">ID: #{{ $listing->id }}</span>
                                                    @if($listing->is_instant)
                                                        <span class="badge bg-success">DOSTUPNO ODMAH</span>
                                                    @endif
                                                </div>
                                                <div class="properties-location">
                                                    <div class="properties-icon-type-location">
                                                        <i class="fas fa-map-marker-alt"></i>
                                                    </div>
                                                    <p>{{ Str::limit($listing->address, 35) }}</p>
                                                </div>
                                                <div class="room-details">
                                                    <div class="single-option">
                                                        <div class="properties-icon-type">
                                                            <i class="fas fa-cube"></i>
                                                        </div>
                                                        <p>{{ Str::limit($listing->interior ?? 'N/A', 15) }}</p>
                                                    </div>
                                                    <div class="single-option">
                                                        <div class="properties-icon-type">
                                                            <i class="ri-layout-2-fill"></i>
                                                        </div>
                                                        <p>{{ $listing->bed_room ?? 'N/A' }} Soba</p>
                                                    </div>
                                                    <div class="single-option">
                                                        <div class="properties-icon-type">
                                                            <i class="ri-user-2-fill"></i>
                                                        </div>
                                                        <p>{{ Str::limit($listing->type ?? 'N/A', 15) }}</p>
                                                    </div>
                                                    <p class="price-properties">
                                                        {{ currencyPrice($listing->price) }} / dan
                                                    </p>
                                                </div>
                                                @if (!empty($listing->slug))
                                                    <a href="{{ route('listing.details', $listing->slug) }}"
                                                       class="theme-btn py-2 px-3 text-nowrap mt-3 d-block text-center">Detalji</a>
                                                @else
                                                    <span class="theme-btn py-2 px-3 text-nowrap mt-3 d-block text-center disabled" title="Slug nedostaje">
                                                        Detalji nisu dostupni
                                                    </span>
                                                @endif
                                            </div>
                                            {{-- End of content for listing card --}}
                                        </div>
                                    </div>
                                </div>

                                {{-- ─── KARTICE JEDINICA ZA TAJ LISTING ─── --}}
                                @foreach ($listing->property->propertyUnits ?? [] as $unit)
                                    <div class="col-md-6 col-lg-6 col-xl-4">
                                        <div class="all-single-properties h-100">
                                            <div class="single-properties mb-0 h-100">
                                                <div class="properties-img">
                                                    <img src="{{ $listing->file_name
                                                        ? assetUrl($listing->folder_name . '/' . $listing->file_name)
                                                        : asset('assets/images/default-property.jpg') }}"
                                                         alt="{{ $unit->unit_name }}">
                                                </div>
                                                <div class="properties-text-info">
                                                    <h5 class="properties-name">{{ Str::limit($unit->unit_name, 40) }}</h5>
                                                    <div class="d-flex align-items-center gap-2 mb-2">
                                                        <span class="badge bg-secondary">ID Jedinice: #U{{ $unit->id }}</span>
                                                        @if($listing->is_instant)
                                                            <span class="badge bg-success">DOSTUPNO ODMAH</span>
                                                        @endif
                                                        @if(!empty($unit->has_jaccuzi) && $unit->has_jaccuzi)
                                                            <span class="badge bg-info">Jacuzzi</span>
                                                        @endif
                                                    </div>
                                                    <div class="properties-location">
                                                        <div class="properties-icon-type-location"><i class="fas fa-map-marker-alt"></i></div>
                                                        <p>{{ Str::limit($listing->address, 35) }}</p>
                                                    </div>
                                                    {{-- Opcionalno dugme za detalje jedinice --}}
                                                    {{-- <a href="{{ route('unit.details', $unit->slug) }}" class="theme-btn py-2 px-3 mt-3 d-block text-center">Detalji jedinice</a> --}}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @endforeach
                            {{-- END OF REPLACED BLOCK --}}

                            <div class="col-md-12 mt-4">
                                {{ $listings->appends(request()->query())->links() }}
                            </div>
                        </div>
                    </div>
                @else
                    <div class="col-12">
                        <div class="no-data-property text-center py-5 my-5">
                            <h3>Nema rezultata za vašu pretragu.</h3>
                            <p class="text-muted">Pokušajte da promenite filtere.</p>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection

@push('style')
    <link rel="stylesheet" href="{{ asset('assets/properties/css/properties.css') }}">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" rel="stylesheet">
    <style>
        .map-area {
            height: 75vh;
            min-height: 500px;
            max-height: 800px;
            position: sticky;
            top: 20px;
            background-color: #f0f0f0; /* Svetla pozadina dok se mapa ne učita */
        }
        @media (max-width: 991.98px) {
            .map-area {
                height: 50vh;
                min-height: 350px;
                position: static;
                margin-bottom: 30px;
            }
            .col-lg-8.ps-lg-3 {
                padding-left: var(--bs-gutter-x, .75rem) !important;
            }
        }
        /* Stil za embedovanu mapu */
        .map-embed-wrapper-list { /* Koristimo ovu klasu da ciljamo omotač iframe-a */
            border-radius: 8px;
            border: 1px solid #ccc;
            overflow: hidden; /* Važno da bi border-radius na iframe-u bio vidljiv */
        }
        .map-embed-wrapper-list iframe {
            display: block; /* Uklanja eventualni mali prostor ispod iframe-a */
        }

        .search-form-background-section {
            background-image: url('{{ asset('assets/images/hero2.jpg') }}');
            background-size: cover;
            background-position: center center;
            padding: 40px 0;
            position: relative;
        }
         .search-form-background-section::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: rgba(0, 0, 0, 0.25);
            z-index: 1;
        }
        .search-form-background-section .container {
            position: relative;
            z-index: 2;
        }
        .properties-filter {
            background-color: rgba(255, 255, 255, 0.97);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
        }
        .properties-filter .single-filter,
        .properties-filter .properties-search {
            margin-bottom: 10px;
            flex-grow: 1;
        }
        .properties-filter .single-filter:last-child,
        .properties-filter .properties-search:last-child {
            margin-right: 0 !important;
        }
        @media (min-width: 768px) {
            .properties-filter .single-filter,
            .properties-filter .properties-search {
                 margin-bottom: 0;
                 margin-right: 0.5rem !important;
            }
        }
        .properties-search, .single-filter.position-relative {
            position: relative;
        }
        .properties-search .search-icon, .single-filter .calendar-icon {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            color: #555;
            z-index: 3;
        }
        .properties-search .search-icon { left: 12px; font-size: 1rem; }
        .single-filter .calendar-icon { right: 12px; pointer-events: none; font-size: 1rem; }
        .properties-filter .form-control, .properties-filter .form-select {
            padding-top: 0.5rem;
            padding-bottom: 0.5rem;
            font-size: 0.9rem;
            height: auto;
            border-color: #ced4da;
        }
        .properties-filter .form-control:focus, .properties-filter .form-select:focus {
            border-color: #86b7fe;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
        }
        .properties-search input[type="search"].form-control { padding-left: 35px; }
        .single-filter input.hasDatepicker.form-control { padding-right: 35px; cursor: pointer; }
        .properties-filter .form-select {
             min-width: 150px;
        }
        .properties-filter .form-check-label {
          color: #212529;
          padding-left: 0.5em;
          line-height: 1.5;
          cursor: pointer;
        }
        .properties-filter .form-check.single-filter {
            display: flex;
            align-items: center;
            padding-top: 0.6rem;
            padding-bottom: 0.6rem;
        }
        .properties-filter .btn-link {
            font-size: 0.85rem;
            color: #0d6efd;
            white-space: nowrap;
            text-decoration: none;
        }
        .properties-filter .btn-link:hover {
            text-decoration: underline;
        }
        .properties-filter .theme-btn {
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
            white-space: nowrap;
        }
        .properties-img img {
            aspect-ratio: 4 / 3;
            object-fit: cover;
            border-radius: 6px 6px 0 0;
        }
        .single-properties {
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            border-radius: 8px;
            transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
            background-color: #fff;
            display: flex; /* Added for consistent height of children */
            flex-direction: column; /* Added for consistent height of children */
        }
        .single-properties:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.12);
        }
        .properties-text-info {
            padding: 15px;
            flex-grow: 1; /* Added for consistent height of children */
            display: flex; /* Added */
            flex-direction: column; /* Added */
        }
        .properties-name { font-size: 1.1rem; font-weight: 600; margin-bottom: 0.5rem; color: #333; }
        .properties-location p { font-size: 0.85rem; color: #6c757d; margin-bottom: 0.75rem;}
        .room-details { margin-bottom: auto; } /* Pushes button down */
        .room-details .single-option { font-size: 0.8rem; color: #555; }
        .price-properties { font-size: 1rem; font-weight: bold; color: var(--bs-primary, #0d6efd); margin-top: 0.5rem; }
        .theme-btn.disabled { opacity: 0.65; cursor: not-allowed; }

    </style>
@endpush

@push('script')
    {{-- jQuery (mora biti PRVI ako ga datepicker koristi) --}}
    {{-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> --}}

    {{-- Uklonjena je kompletna Mapbox JS inicijalIzacija --}}

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    {{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/locales/bootstrap-datepicker.sr-latin.min.js" charset="UTF-8"></script> --}}
    <script>
      $(function(){
        if ($.fn.datepicker) {
            $('.hasDatepicker').datepicker({
              format: 'dd.mm.yyyy.',
              autoclose: true,
              todayHighlight: true,
              // language: 'sr-latin'
            });
        } else {
            console.warn('Bootstrap Datepicker jQuery plugin nije učitan.');
        }
      });

      function returnToDefault(){
          const form = document.getElementById('searchForm');
          if(form) {
              form.reset();
              if ($.fn.datepicker) {
                  $('.hasDatepicker').datepicker('update', '');
              }
              form.submit();
          }
      }
    </script>
@endpush