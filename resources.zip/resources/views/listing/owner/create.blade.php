@extends('owner.layouts.app')
@section('content')
    <div class="main-content">
        <div class="page-content">
            <div class="upload-property">
                <div class="container-fluid">
                    <div class="page-content-wrapper bg-white p-30 radius-20">
                        <div class="row">
                            <div class="col-12">
                                <div
                                    class="page-title-box d-sm-flex align-items-center justify-content-between border-bottom mb-20">
                                    <div class="page-title-left">
                                        <h3 class="mb-sm-0">{{ $pageTitle }}</h3>
                                    </div>
                                    <div class="page-title-right">
                                        <ol class="breadcrumb mb-0">
                                            <li class="breadcrumb-item"><a href="{{ route('owner.dashboard') }}"
                                                    title="{{ __('Kontrolna tabla') }}">{{ __('Kontrolna tabla') }}</a></li>
                                            <li class="breadcrumb-item" aria-current="page">{{ __('Moji oglasi') }}</li>
                                            <li class="breadcrumb-item active" aria-current="page">{{ $pageTitle }}</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <form class="ajax" action="{{ route('owner.listing.store') }}" method="POST"
                                    enctype="multipart/form-data"
                                    data-handler="getShowListingMessage">
                                    @csrf
                                    <div class="upload-from-area">
                                        <div class="row">
                                            {{-- Informacije o nekretnini --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3">
                                                    <div class="col-lg-12">
                                                        <h5 class="single-input-title">{{ __('Informacije o nekretnini') }}</h5>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="name" class="form-label">{{ __('Naziv') }} <span class="text-danger">*</span></label>
                                                                <input type="text" class="form-control" name="name"
                                                                    placeholder="{{ __('Naziv') }}" id="name" value="{{ old('name') }}" required>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="price" class="form-label">{{ __('Cena po danu') }} <span class="text-danger">*</span></label>
                                                                <input type="number" step="any"
                                                                    class="form-control" name="price"
                                                                    placeholder="{{ __('Unesite cenu') }}" id="price" value="{{ old('price') }}" required>
                                                                <input type="hidden" name="price_duration_type" value="daily">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="status" class="form-label">{{ __('Status') }} <span class="text-danger">*</span></label>
                                                                <select name="status" id="status" class="form-select" required>
                                                                    <option value="1" {{ old('status', 1) == 1 ? 'selected' : '' }}> {{ __('Aktivan') }}</option>
                                                                    <option value="2" {{ old('status') == 2 ? 'selected' : '' }}> {{ __('Deaktiviran') }}</option>
                                                                    <option value="3" {{ old('status') == 3 ? 'selected' : '' }}> {{ __('Izdat') }}</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="form-check mt-4 pt-2">
                                                                <input class="form-check-input" type="checkbox" name="is_instant" id="is_instant" value="1" {{ old('is_instant') == 1 ? 'checked' : '' }}>
                                                                <label class="form-check-label" for="is_instant">
                                                                    {{ __('Dostupno odmah') }}
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="city" class="form-label">{{ __('Grad') }}</label>
                                                                <input type="text" class="form-control" name="city"
                                                                    placeholder="{{ __('Grad') }}" id="city" value="{{ old('city') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="zip_code" class="form-label">{{ __('Poštanski broj') }}</label>
                                                                <input type="text" class="form-control" name="zip_code"
                                                                    placeholder="{{ __('Poštanski broj') }}" id="zip_code" value="{{ old('zip_code') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="address" class="form-label">{{ __('Adresa') }}</label>
                                                                <input type="text" class="form-control" name="address"
                                                                    placeholder="{{ __('Adresa') }}" id="address" value="{{ old('address') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="rent_user_id" class="form-label">{{ __('Zakupodavac') }} <span class="text-danger">*</span></label>
                                                                <select name="rent_user_id" id="rent_user_id" class="form-select" required>
                                                                    <option value="">{{ __('Izaberite zakupodavca') }}</option>
                                                                    @if(isset($rentUsers) && $rentUsers->count() > 0)
                                                                        @foreach ($rentUsers as $user)
                                                                            <option value="{{ $user->id }}" {{ old('rent_user_id') == $user->id ? 'selected' : '' }}>
                                                                                {{ $user->first_name }} {{ $user->last_name }} {{ $user->contact_number ? '- ' . $user->contact_number : '' }}
                                                                            </option>
                                                                        @endforeach
                                                                    @else
                                                                        <option value="" disabled>{{ __('Nema dostupnih zakupodavaca') }}</option>
                                                                    @endif
                                                                </select>
                                                                <small class="form-text text-muted">{{ __('Izaberite zakupodavca kojem pripada oglas.') }}</small>
                                                            </div>
                                                        </div>
                                                        {{-- === POČETAK DODATOG POLJA: Pripada property-ju === --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="property_id" class="form-label">{{ __('Pripada property-ju') }}</label>
                                                                <select name="property_id" id="property_id" class="form-select">
                                                                    <option value="">{{ __('Bez dodeljivanja') }}</option>
                                                                    @isset($properties)
                                                                        @foreach($properties as $property)
                                                                            <option value="{{ $property->id }}" {{ old('property_id') == $property->id ? 'selected' : '' }}>
                                                                                {{ $property->name }} (ID: {{ $property->id }})
                                                                            </option>
                                                                        @endforeach
                                                                    @endisset
                                                                </select>
                                                                <small class="form-text text-muted">{{ __('Ovaj oglas će se prikazivati i u okviru izabranog property-ja.') }}</small>
                                                            </div>
                                                        </div>
                                                        {{-- === KRAJ DODATOG POLJA: Pripada property-ju === --}}
                                                         <div class="col-md-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="latitude" class="form-label">{{ __('Geografska širina (Latitude)') }}</label>
                                                                <input type="number" step="any" name="latitude"
                                                                    value="{{ old('latitude') }}" class="form-control"
                                                                    id="latitude" placeholder="{{ __('Latitude') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="longitude" class="form-label">{{ __('Geografska dužina (Longitude)') }}</label>
                                                                <input type="number" step="any" name="longitude"
                                                                    value="{{ old('longitude') }}"
                                                                    class="form-control" id="longitude"
                                                                    placeholder="{{ __('Longitude') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label class="form-label">{{ __('Lokacija na mapi') }}</label>
                                                                <div id="map" style="height: 400px; border: 1px solid #ccc; border-radius: 6px;"></div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-12">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="details" class="form-label">{{ __('Detaljan opis nekretnine') }}</label>
                                                                <textarea name="details" id="details" class="form-control" placeholder="{{ __('Unesite detaljan opis...') }}" cols="30" rows="6">{{ old('details') }}</textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- === POČETAK DODATE SEKCIJE: Specifikacija nekretnine === --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3">
                                                    <div class="col-lg-12">
                                                        <h5 class="single-input-title">{{ __('Specifikacija nekretnine') }}</h5>
                                                    </div>
                                                    <div class="form-check mt-4 pt-2">
                                                        <input class="form-check-input" type="checkbox" name="jacuzzi" id="jacuzzi" value="1"
                                                            {{ old('jacuzzi', $listing->jacuzzi ?? 0) ? 'checked' : '' }}>
                                                        <label class="form-check-label" for="jacuzzi">
                                                            {{ __('Jacuzzi') }}
                                                        </label>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="bed_room" class="form-label">{{ __('Broj spavaćih soba') }}</label>
                                                                <input type="number" name="bed_room" id="bed_room" class="form-control" placeholder="{{ __('Npr. 2') }}" value="{{ old('bed_room') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="bath_room" class="form-label">{{ __('Broj kupatila') }}</label>
                                                                <input type="number" name="bath_room" id="bath_room" class="form-control" placeholder="{{ __('Npr. 1') }}" value="{{ old('bath_room') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="kitchen_room" class="form-label">{{ __('Broj kuhinja') }}</label>
                                                                <input type="number" name="kitchen_room" id="kitchen_room" class="form-control" placeholder="{{ __('Npr. 1') }}" value="{{ old('kitchen_room') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="dining_room" class="form-label">{{ __('Broj trpezarija') }}</label>
                                                                <input type="number" name="dining_room" id="dining_room" class="form-control" placeholder="{{ __('Npr. 1') }}" value="{{ old('dining_room') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="living_room" class="form-label">{{ __('Broj dnevnih soba') }}</label>
                                                                <input type="number" name="living_room" id="living_room" class="form-control" placeholder="{{ __('Npr. 1') }}" value="{{ old('living_room') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="storage_room" class="form-label">{{ __('Broj ostava') }}</label>
                                                                <input type="number" name="storage_room" id="storage_room" class="form-control" placeholder="{{ __('Npr. 0') }}" value="{{ old('storage_room') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="other_room" class="form-label">{{ __('Ostale prostorije (opis)') }}</label>
                                                                <input type="text" name="other_room" id="other_room" class="form-control" placeholder="{{ __('Npr. Terasa, Vešernica...') }}" value="{{ old('other_room') }}">
                                                                <small class="form-text text-muted">{{ __('Odvojite zarezom ako ih je više.') }}</small>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            {{-- === KRAJ DODATE SEKCIJE: Specifikacija nekretnine === --}}

                                            {{-- === POČETAK DODATE SEKCIJE: Detalji o nekretnini (Enterijer, Tip, Slike) === --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3">
                                                    <div class="col-lg-12">
                                                        <h5 class="single-input-title">{{ __('Osnovni detalji o nekretnini') }}</h5>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="interior" class="form-label">{{ __('Kvadratura / Enterijer (opis)') }}</label>
                                                                <input type="text" name="interior" id="interior" class="form-control" placeholder="{{ __('Npr. 75m², Kompletno renoviran') }}" value="{{ old('interior') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="type" class="form-label">{{ __('Tip nekretnine') }}</label>
                                                                <input type="text" name="type" id="type" class="form-control" placeholder="{{ __('Npr. Stan, Kuća, Apartman') }}" value="{{ old('type') }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-12">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="images" class="form-label">{{ __('Slike nekretnine') }} <span class="text-danger">*</span></label>
                                                                <input type="file" class="form-control" id="images" name="images[]" multiple required>
                                                                <small class="form-text text-muted">{{ __('Možete odabrati više slika odjednom.') }}</small>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            {{-- === KRAJ DODATE SEKCIJE: Detalji o nekretnini === --}}

                                            {{-- Sadržaji / Pogodnosti --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3">
                                                    <div class="col-lg-12">
                                                        <h5 class="single-input-title">{{ __('Sadržaji / Pogodnosti') }}</h5>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <div class="amenities-upload-input">
                                                                @php $oldAmenities = old('amenities', []); @endphp
                                                                @foreach (getPropertyAmenities() as $key => $amenity)
                                                                    <div class="single-interior form-check form-check-inline mb-2">
                                                                        <input type="checkbox" class="form-check-input" name="amenities[]" id="amenity{{ $key }}" value="{{ $key }}" {{ in_array((string)$key, $oldAmenities, true) ? 'checked' : '' }}>
                                                                        <label class="form-check-label" for="amenity{{ $key }}">{{ __($amenity) }}</label>
                                                                    </div>
                                                                @endforeach
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Informacije o okolini --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3" id="nearbyInfoSection">
                                                    <div class="col-lg-12 d-flex justify-content-between align-items-center mb-3">
                                                        <h5 class="single-input-title mb-0">{{ __('Informacije o okolini') }}</h5>
                                                        <button type="button" class="btn theme-btn btn-sm" id="addInfo"><i class="fas fa-plus"></i> {{ __('Dodaj još') }}</button>
                                                    </div>
                                                    <div id="infoItems">
                                                         @php
                                                            $infoData = old('info', [['id' => '', 'name' => '', 'distance' => '', 'contact_number' => '', 'details' => '']]);
                                                            $hasOldInfo = !empty(old('info')) && isset(old('info')['name']) && is_array(old('info')['name']);
                                                         @endphp
                                                         @foreach ($infoData as $index => $itemData)
                                                             <div class="row border rounded p-3 mb-3 nearby-item">
                                                                 <input type="hidden" name="info[id][]" value="{{ $itemData['id'] ?? '' }}">
                                                                 <div class="col-lg-6">
                                                                     <div class="single-upload-input-from mb-3">
                                                                         <label class="form-label">{{ __('Naziv mesta/objekta') }}</label>
                                                                         <input type="text" name="info[name][]" class="form-control info-name" placeholder="{{ __('Npr. prodavnica, škola, park') }}" value="{{ $itemData['name'] ?? '' }}">
                                                                     </div>
                                                                 </div>
                                                                 <div class="col-lg-6">
                                                                     <div class="single-upload-input-from mb-3">
                                                                         <label class="form-label">{{ __('Udaljenost') }}</label>
                                                                         <input type="text" name="info[distance][]" class="form-control" placeholder="{{ __('Npr. 500m, 1km, 5 minuta hoda') }}" value="{{ $itemData['distance'] ?? '' }}">
                                                                     </div>
                                                                 </div>
                                                                 <div class="col-lg-6">
                                                                     <div class="single-upload-input-from mb-3">
                                                                         <label class="form-label">{{ __('Kontakt telefon') }}</label>
                                                                         <input type="text" name="info[contact_number][]" class="form-control" placeholder="{{ __('Kontakt telefon (opciono)') }}" value="{{ $itemData['contact_number'] ?? '' }}">
                                                                     </div>
                                                                 </div>
                                                                 <div class="col-lg-6">
                                                                     <div class="single-upload-input-from mb-3">
                                                                         <label class="form-label">{{ __('Postavi sliku') }}</label>
                                                                         <input type="file" name="info[image][{{ $index }}]" class="form-control">
                                                                     </div>
                                                                 </div>
                                                                 <div class="col-lg-12">
                                                                     <div class="single-upload-input-from mb-3">
                                                                         <label class="form-label">{{ __('Detalji') }}</label>
                                                                         <textarea name="info[details][]" class="form-control" placeholder="{{ __('Dodatni detalji (opciono)') }}" cols="30" rows="3">{{ $itemData['details'] ?? '' }}</textarea>
                                                                     </div>
                                                                 </div>
                                                                 <div class="col-md-12 d-flex justify-content-end">
                                                                     <button type="button" class="btn theme-btn-red btn-sm removeInfo" title="{{ __('Ukloni stavku') }}" style="{{ $loop->first && !$hasOldInfo ? 'display: none;' : '' }}"><i class="far fa-trash-alt"></i></button>
                                                                 </div>
                                                             </div>
                                                         @endforeach
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Prednosti --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3">
                                                    <div class="col-lg-12">
                                                        <h5 class="single-input-title">{{ __('Prednosti') }}</h5>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-12">
                                                            <div class="amenities-upload-input">
                                                                @php $oldAdvantages = old('advantage', []); @endphp
                                                                @foreach (getPropertyAdvantages() as $key => $advantage)
                                                                    <div class="single-interior form-check form-check-inline mb-2">
                                                                        <input type="checkbox" class="form-check-input" name="advantage[]" value="{{ $key }}" id="advantage{{ $key }}" {{ in_array((string)$key, $oldAdvantages, true) ? 'checked' : '' }}>
                                                                        <label class="form-check-label" for="advantage{{ $key }}">{{ __($advantage) }}</label>
                                                                    </div>
                                                                @endforeach
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Dugme za čuvanje --}}
                                            <div class="col-lg-12">
                                                <button type="submit"
                                                    class="btn theme-btn py-3 px-4 mt-3">{{ __('Sačuvaj nekretninu') }}</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" value="{{ route('owner.listing.index') }}" id="listingRoute">

    {{-- Skriveni templejt za stavku "Informacije o okolini" --}}
    <div id="nearbyInfoTemplate" style="display: none;">
        <div class="row border rounded p-3 mb-3 nearby-item">
             <input type="hidden" name="info[id][]" value="">
            <div class="col-lg-6">
                <div class="single-upload-input-from mb-3">
                    <label class="form-label">{{ __('Naziv mesta/objekta') }}</label>
                    <input type="text" name="info[name][]" class="form-control info-name" placeholder="{{ __('Npr. prodavnica, škola, park') }}">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="single-upload-input-from mb-3">
                    <label class="form-label">{{ __('Udaljenost') }}</label>
                    <input type="text" name="info[distance][]" class="form-control" placeholder="{{ __('Npr. 500m, 1km, 5 minuta hoda') }}">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="single-upload-input-from mb-3">
                    <label class="form-label">{{ __('Kontakt telefon') }}</label>
                    <input type="text" name="info[contact_number][]" class="form-control" placeholder="{{ __('Kontakt telefon (opciono)') }}">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="single-upload-input-from mb-3">
                    <label class="form-label">{{ __('Postavi sliku') }}</label>
                    <input type="file" name="info_new_image_template[]" class="form-control info-new-image-template"> {{-- Privremeno ime za templejt --}}
                </div>
            </div>
            <div class="col-lg-12">
                <div class="single-upload-input-from mb-3">
                    <label class="form-label">{{ __('Detalji') }}</label>
                    <textarea name="info[details][]" class="form-control" placeholder="{{ __('Dodatni detalji (opciono)') }}" cols="30" rows="3"></textarea>
                </div>
            </div>
            <div class="col-md-12 d-flex justify-content-end">
                <button type="button" class="btn theme-btn-red btn-sm removeInfo" title="{{ __('Ukloni stavku') }}"><i class="far fa-trash-alt"></i></button>
            </div>
        </div>
    </div>
@endsection

@push('style')
    <link rel="stylesheet" href="{{ asset('assets/properties/css/properties.css') }}">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
        integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
        crossorigin=""/>
    <style>
        #map { width: 100%; height: 400px; border-radius: 6px; border: 1px solid #dee2e6; }
        .single-upload-from-property { border: 1px solid #e9ecef; padding: 20px; border-radius: 10px; background-color: #f8f9fa; }
        .single-input-title { margin-bottom: 1.5rem; border-bottom: 1px solid #dee2e6; padding-bottom: 0.5rem; }
        .amenities-upload-input .form-check-inline { min-width: 150px; }
        .nearby-item { background-color: #fff; position: relative; }
        .removeInfo { cursor: pointer; }
        .select2-container--bootstrap-5 .select2-selection--single { height: calc(1.5em + .75rem + 2px) !important; padding: .375rem .75rem !important; }
        .select2-container--bootstrap-5 .select2-selection--single .select2-selection__rendered { line-height: 1.5 !important; }
        .select2-container--bootstrap-5 .select2-selection--single .select2-selection__arrow { height: calc(1.5em + .75rem) !important; }
    </style>
@endpush

@push('script')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
        crossorigin=""></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // --- LOGIKA ZA DODAVANJE/BRISANJE "NEARBY INFORMATION" ---
            const addInfoButton = document.getElementById('addInfo');
            const infoItemsContainer = document.getElementById('infoItems');
            const nearbyInfoTemplate = document.getElementById('nearbyInfoTemplate');
            let infoItemCounter = {{ $hasOldInfo ? count(old('info')['name']) : (isset($infoData) && is_array($infoData) ? count($infoData) : 1) }};

            const toggleRemoveButtons = () => {
                const items = infoItemsContainer.querySelectorAll('.nearby-item');
                items.forEach((item, index) => {
                    const removeBtn = item.querySelector('.removeInfo');
                    if (removeBtn) {
                        const isFirstItemAndNoOldData = (index === 0 && items.length === 1 && !{{ $hasOldInfo ? 'true' : 'false' }});
                        removeBtn.style.display = isFirstItemAndNoOldData ? 'none' : 'inline-block';
                    }
                });
            };

            if (addInfoButton && infoItemsContainer && nearbyInfoTemplate) {
                addInfoButton.addEventListener('click', function() {
                    const newItemHtml = nearbyInfoTemplate.innerHTML.replace(/info\[image\]\[\d+\]/g, `info[image][${infoItemCounter}]`).replace(/info_new_image_template\[\]/g, `info[image][${infoItemCounter}]`);
                    const newItemWrapper = document.createElement('div'); // Privremeni wrapper
                    newItemWrapper.innerHTML = newItemHtml;
                    const actualItem = newItemWrapper.firstElementChild;

                    const idInput = actualItem.querySelector('input[name="info[id][]"]');
                    if(idInput) idInput.value = '';

                    const fileInput = actualItem.querySelector('input[type="file"]');
                    if(fileInput && fileInput.name.includes('template')){
                         fileInput.name = `info[image][${infoItemCounter}]`;
                    } else if(fileInput) {
                         fileInput.name = `info[image][${infoItemCounter}]`;
                    }

                    infoItemsContainer.appendChild(actualItem);
                    infoItemCounter++;
                    toggleRemoveButtons();
                });
            }

            if (infoItemsContainer) {
                infoItemsContainer.addEventListener('click', function(event) {
                    const removeButton = event.target.closest('.removeInfo');
                    if (removeButton) {
                        const itemToRemove = removeButton.closest('.nearby-item');
                        if (itemToRemove && infoItemsContainer.querySelectorAll('.nearby-item').length > 1) {
                             itemToRemove.remove();
                             toggleRemoveButtons();
                        } else if (itemToRemove && infoItemsContainer.querySelectorAll('.nearby-item').length === 1) {
                            const inputs = itemToRemove.querySelectorAll('input[type="text"], input[type="file"], textarea');
                            inputs.forEach(input => input.value = '');
                            const fileInput = itemToRemove.querySelector('input[type="file"]');
                            if(fileInput) fileInput.value = null;
                        }
                    }
                });
            }
            toggleRemoveButtons();

            // --- LEAFLET MAPA INTEGRACIJA ---
            var latInput = document.getElementById('latitude');
            var lngInput = document.getElementById('longitude');
            var defaultLat = parseFloat(latInput.value) || 44.7866;
            var defaultLng = parseFloat(lngInput.value) || 20.4489;
            var initialZoom = (latInput.value && lngInput.value && parseFloat(latInput.value) !== 0 && parseFloat(lngInput.value) !== 0) ? 13 : 7;

            var map = L.map('map').setView([defaultLat, defaultLng], initialZoom);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '© <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            }).addTo(map);
            var marker = L.marker([defaultLat, defaultLng], { draggable: true }).addTo(map);
            marker.on('dragend', function (e) {
                var position = marker.getLatLng();
                latInput.value = position.lat.toFixed(6);
                lngInput.value = position.lng.toFixed(6);
            });
            map.on('click', function (e) {
                marker.setLatLng(e.latlng);
                latInput.value = e.latlng.lat.toFixed(6);
                lngInput.value = e.latlng.lng.toFixed(6);
            });
            function updateMapFromInputs() {
                const lat = parseFloat(latInput.value);
                const lng = parseFloat(lngInput.value);
                if (!isNaN(lat) && !isNaN(lng)) {
                    const newLatLng = L.latLng(lat, lng);
                    marker.setLatLng(newLatLng);
                    map.setView(newLatLng, map.getZoom() < 10 ? 13 : map.getZoom());
                }
            }
            latInput.addEventListener('input', updateMapFromInputs);
            lngInput.addEventListener('input', updateMapFromInputs);

            // --- RUKOVANJE ODGOVOROM AJAX FORME ---
            window.getShowListingMessage = function(response) {
                document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
                document.querySelectorAll('.invalid-feedback').forEach(el => el.remove());

                if (response.status === true) {
                    if (typeof toastr !== 'undefined') {
                        toastr.success(response.message || "{{ __('Nekretnina uspešno sačuvana!') }}");
                    } else {
                        alert(response.message || "{{ __('Nekretnina uspešno sačuvana!') }}");
                    }
                    const form = document.querySelector('form.ajax');
                    if(form) form.reset();

                    // Reset select fields
                    document.getElementById('status').value = '1'; // Reset to default 'Aktivan'
                    document.getElementById('rent_user_id').value = '';
                    document.getElementById('property_id').value = ''; // Reset new field

                    const nearbyItems = infoItemsContainer.querySelectorAll('.nearby-item');
                     nearbyItems.forEach((item, index) => {
                         if (index > 0) item.remove();
                     });
                     if(nearbyItems.length > 0){
                        const firstItemInputs = nearbyItems[0].querySelectorAll('input[type="text"], input[type="file"], textarea');
                        if(firstItemInputs) {
                            firstItemInputs.forEach(input => input.value = '');
                        }
                        const firstFileInput = nearbyItems[0].querySelector('input[type="file"]');
                        if(firstFileInput) firstFileInput.value = null;
                     }
                     toggleRemoveButtons();
                     // Reset map to default
                     latInput.value = '';
                     lngInput.value = '';
                     marker.setLatLng([44.7866, 20.4489]); // Default Belgrade coordinates
                     map.setView([44.7866, 20.4489], 7); // Default view

                } else {
                     if (typeof toastr !== 'undefined') {
                        toastr.error(response.message || "{{ __('Došlo je do greške.') }}");
                     } else {
                         alert(response.message || "{{ __('Došlo je do greške.') }}");
                     }
                    if (response.errors) {
                        console.error("Greške validacije:", response.errors);
                        for (const field in response.errors) {
                            const errorMessages = response.errors[field];
                            let inputField;
                            if (field.includes('.')) {
                                const parts = field.split('.');
                                const baseName = parts[0];
                                const index = parts[1];
                                const actualField = parts[2];
                                const infoItemDivs = document.querySelectorAll(`#infoItems .nearby-item`);
                                if(infoItemDivs[index]){
                                     inputField = infoItemDivs[index].querySelector(`[name="${baseName}[${actualField}][]"], [name^="${baseName}[image][${index}]"]`);
                                }
                            } else {
                                inputField = document.querySelector(`[name="${field}"], [name="${field}[]"]`);
                            }

                            if (inputField) {
                                inputField.classList.add('is-invalid');
                                const errorDiv = document.createElement('div');
                                errorDiv.classList.add('invalid-feedback');
                                errorDiv.style.display = 'block';
                                errorDiv.textContent = errorMessages[0];
                                if(inputField.parentNode.classList.contains('single-upload-input-from') || inputField.parentNode.classList.contains('form-check')) {
                                    inputField.parentNode.appendChild(errorDiv);
                                } else if (inputField.nextSibling) {
                                    inputField.parentNode.insertBefore(errorDiv, inputField.nextSibling);
                                } else {
                                    inputField.parentNode.appendChild(errorDiv);
                                }
                            }
                        }
                    }
                }
            };

            const form = document.querySelector('form.ajax');
            if(form){
                form.addEventListener('input', function(event){
                    if(event.target.classList.contains('is-invalid')){
                        event.target.classList.remove('is-invalid');
                        const errorFeedback = event.target.parentNode.querySelector('.invalid-feedback');
                        if(errorFeedback) errorFeedback.remove();
                    }
                });
                 form.addEventListener('change', function(event){
                    if(event.target.classList.contains('is-invalid')){
                        event.target.classList.remove('is-invalid');
                        const errorFeedback = event.target.parentNode.querySelector('.invalid-feedback');
                        if(errorFeedback) errorFeedback.remove();
                    }
                });
            }
        });
    </script>
@endpush