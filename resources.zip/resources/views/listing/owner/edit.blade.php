@extends('owner.layouts.app')
@section('content')
    <div class="main-content">
        <div class="page-content">
            <div class="upload-property">
                <div class="container-fluid">
                    <div class="page-content-wrapper bg-white p-30 radius-20">
                        <div class="row">
                            <div class="col-12">
                                <div
                                    class="page-title-box d-sm-flex align-items-center justify-content-between border-bottom mb-20">
                                    <div class="page-title-left">
                                        <h3 class="mb-sm-0">{{ $pageTitle }}</h3>
                                    </div>
                                    <div class="page-title-right">
                                        <ol class="breadcrumb mb-0">
                                            <li class="breadcrumb-item"><a href="{{ route('owner.dashboard') }}"
                                                    title="{{ __('Kontrolna tabla') }}">{{ __('Kontrolna tabla') }}</a></li>
                                            <li class="breadcrumb-item" aria-current="page">{{ __('Moji oglasi') }}</li>
                                            <li class="breadcrumb-item active" aria-current="page">{{ $pageTitle }}</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <form class="ajax"
                                      action="{{ route('owner.listing.update', $listing->id) }}"
                                      method="POST"
                                      enctype="multipart/form-data"
                                      data-handler="getShowListingMessage">
                                    @csrf
                                    @method('PUT')
                                    <div class="upload-from-area">
                                        <div class="row">
                                            {{-- Informacije o nekretnini --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3">
                                                    <div class="col-lg-12">
                                                        <h5 class="single-input-title">{{ __('Informacije o nekretnini') }}</h5>
                                                    </div>
                                                    <div class="row">
                                                        {{-- Naziv --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="name" class="form-label">
                                                                    {{ __('Naziv') }} <span class="text-danger">*</span>
                                                                </label>
                                                                <input type="text"
                                                                       class="form-control"
                                                                       name="name"
                                                                       id="name"
                                                                       placeholder="{{ __('Naziv') }}"
                                                                       value="{{ old('name', $listing->name) }}"
                                                                       required>
                                                            </div>
                                                        </div>
                                                        {{-- Cena --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="price" class="form-label">
                                                                    {{ __('Cena po danu') }} <span class="text-danger">*</span>
                                                                </label>
                                                                <input type="number"
                                                                       step="any"
                                                                       class="form-control"
                                                                       name="price"
                                                                       id="price"
                                                                       placeholder="{{ __('Unesite cenu') }}"
                                                                       value="{{ old('price', $listing->price) }}"
                                                                       required>
                                                                <input type="hidden"
                                                                       name="price_duration_type"
                                                                       value="daily">
                                                            </div>
                                                        </div>
                                                        {{-- Status --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="status" class="form-label">
                                                                    {{ __('Status') }} <span class="text-danger">*</span>
                                                                </label>
                                                                <select name="status"
                                                                        id="status"
                                                                        class="form-select"
                                                                        required>
                                                                    <option value="1"
                                                                        {{ old('status', $listing->status) == 1 ? 'selected' : '' }}>
                                                                        {{ __('Aktivan') }}
                                                                    </option>
                                                                    <option value="2"
                                                                        {{ old('status', $listing->status) == 2 ? 'selected' : '' }}>
                                                                        {{ __('Deaktiviran') }}
                                                                    </option>
                                                                    <option value="3"
                                                                        {{ old('status', $listing->status) == 3 ? 'selected' : '' }}>
                                                                        {{ __('Izdat') }}
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        {{-- Instant --}}
                                                        <div class="col-lg-6">
                                                            <div class="form-check mt-4 pt-2">
                                                                <input class="form-check-input"
                                                                       type="checkbox"
                                                                       name="is_instant"
                                                                       id="is_instant"
                                                                       value="1"
                                                                       {{ old('is_instant', $listing->is_instant) ? 'checked' : '' }}>
                                                                <label class="form-check-label" for="is_instant">
                                                                    {{ __('Dostupno odmah') }}
                                                                </label>
                                                            </div>
                                                        </div>
                                                        {{-- Grad --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="city" class="form-label">{{ __('Grad') }}</label>
                                                                <input type="text"
                                                                       class="form-control"
                                                                       name="city"
                                                                       id="city"
                                                                       placeholder="{{ __('Grad') }}"
                                                                       value="{{ old('city', $listing->city) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Poštanski broj --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="zip_code" class="form-label">
                                                                    {{ __('Poštanski broj') }}
                                                                </label>
                                                                <input type="text"
                                                                       class="form-control"
                                                                       name="zip_code"
                                                                       id="zip_code"
                                                                       placeholder="{{ __('Poštanski broj') }}"
                                                                       value="{{ old('zip_code', $listing->zip_code) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Adresa --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="address" class="form-label">{{ __('Adresa') }}</label>
                                                                <input type="text"
                                                                       class="form-control"
                                                                       name="address"
                                                                       id="address"
                                                                       placeholder="{{ __('Adresa') }}"
                                                                       value="{{ old('address', $listing->address) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Zakupodavac --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="rent_user_id" class="form-label">
                                                                    {{ __('Zakupodavac') }} <span class="text-danger">*</span>
                                                                </label>
                                                                <select name="rent_user_id"
                                                                        id="rent_user_id"
                                                                        class="form-select"
                                                                        required>
                                                                    <option value="">{{ __('Izaberite zakupodavca') }}</option>
                                                                    @foreach($rentUsers as $user)
                                                                        <option value="{{ $user->id }}"
                                                                            {{ old('rent_user_id', $listing->rent_user_id) == $user->id ? 'selected' : '' }}>
                                                                            {{ $user->first_name }} {{ $user->last_name }}
                                                                            {{ $user->contact_number ? '- ' . $user->contact_number : '' }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                                <small class="form-text text-muted">
                                                                    {{ __('Izaberite zakupodavca kojem pripada oglas.') }}
                                                                </small>
                                                            </div>
                                                        </div>
                                                        {{-- Pripada property-ju --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="property_id" class="form-label">
                                                                    {{ __('Pripada property-ju') }}
                                                                </label>
                                                                <select name="property_id"
                                                                        id="property_id"
                                                                        class="form-select">
                                                                    <option value="">{{ __('Bez dodeljivanja') }}</option>
                                                                    @foreach($properties as $property)
                                                                        <option value="{{ $property->id }}"
                                                                            {{ old('property_id', $listing->property_id) == $property->id ? 'selected' : '' }}>
                                                                            {{ $property->name }} (ID: {{ $property->id }})
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                                <small class="form-text text-muted">
                                                                    {{ __('Ovaj oglas će se prikazivati i u okviru izabranog property-ja.') }}
                                                                </small>
                                                            </div>
                                                        </div>
                                                        {{-- Latitude --}}
                                                        <div class="col-md-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="latitude" class="form-label">
                                                                    {{ __('Geografska širina (Latitude)') }}
                                                                </label>
                                                                <input type="number"
                                                                       step="any"
                                                                       class="form-control"
                                                                       name="latitude"
                                                                       id="latitude"
                                                                       placeholder="{{ __('Latitude') }}"
                                                                       value="{{ old('latitude', $listing->latitude) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Longitude --}}
                                                        <div class="col-md-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="longitude" class="form-label">
                                                                    {{ __('Geografska dužina (Longitude)') }}
                                                                </label>
                                                                <input type="number"
                                                                       step="any"
                                                                       class="form-control"
                                                                       name="longitude"
                                                                       id="longitude"
                                                                       placeholder="{{ __('Longitude') }}"
                                                                       value="{{ old('longitude', $listing->longitude) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Mapa --}}
                                                        <div class="col-md-12">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label class="form-label">{{ __('Lokacija na mapi') }}</label>
                                                                <div id="map"
                                                                     style="height: 400px; border: 1px solid #ccc; border-radius: 6px;">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        {{-- Detaljan opis --}}
                                                        <div class="col-lg-12">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="details" class="form-label">
                                                                    {{ __('Detaljan opis nekretnine') }}
                                                                </label>
                                                                <textarea name="details"
                                                                          id="details"
                                                                          class="form-control"
                                                                          cols="30"
                                                                          rows="6"
                                                                          placeholder="{{ __('Unesite detaljan opis...') }}">{{ old('details', $listing->details) }}</textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Specifikacija nekretnine --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3">
                                                    <div class="col-lg-12">
                                                        <h5 class="single-input-title">{{ __('Specifikacija nekretnine') }}</h5>
                                                    </div>
                                                    <div class="form-check mt-4 pt-2">
                                                        <input class="form-check-input"
                                                               type="checkbox"
                                                               name="jacuzzi"
                                                               id="jacuzzi"
                                                               value="1"
                                                               {{ old('jacuzzi', $listing->jacuzzi) ? 'checked' : '' }}>
                                                        <label class="form-check-label" for="jacuzzi">
                                                            {{ __('Jacuzzi') }}
                                                        </label>
                                                    </div>
                                                    <div class="row">
                                                        {{-- Spavaće sobe --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="bed_room" class="form-label">
                                                                    {{ __('Broj spavaćih soba') }}
                                                                </label>
                                                                <input type="number"
                                                                       class="form-control"
                                                                       name="bed_room"
                                                                       id="bed_room"
                                                                       placeholder="{{ __('Npr. 2') }}"
                                                                       value="{{ old('bed_room', $listing->bed_room) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Kupatila --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="bath_room" class="form-label">
                                                                    {{ __('Broj kupatila') }}
                                                                </label>
                                                                <input type="number"
                                                                       class="form-control"
                                                                       name="bath_room"
                                                                       id="bath_room"
                                                                       placeholder="{{ __('Npr. 1') }}"
                                                                       value="{{ old('bath_room', $listing->bath_room) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Kuhinje --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="kitchen_room" class="form-label">
                                                                    {{ __('Broj kuhinja') }}
                                                                </label>
                                                                <input type="number"
                                                                       class="form-control"
                                                                       name="kitchen_room"
                                                                       id="kitchen_room"
                                                                       placeholder="{{ __('Npr. 1') }}"
                                                                       value="{{ old('kitchen_room', $listing->kitchen_room) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Trpezarije --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="dining_room" class="form-label">
                                                                    {{ __('Broj trpezarija') }}
                                                                </label>
                                                                <input type="number"
                                                                       class="form-control"
                                                                       name="dining_room"
                                                                       id="dining_room"
                                                                       placeholder="{{ __('Npr. 1') }}"
                                                                       value="{{ old('dining_room', $listing->dining_room) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Dnevne sobe --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="living_room" class="form-label">
                                                                    {{ __('Broj dnevnih soba') }}
                                                                </label>
                                                                <input type="number"
                                                                       class="form-control"
                                                                       name="living_room"
                                                                       id="living_room"
                                                                       placeholder="{{ __('Npr. 1') }}"
                                                                       value="{{ old('living_room', $listing->living_room) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Ostava --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="storage_room" class="form-label">
                                                                    {{ __('Broj ostava') }}
                                                                </label>
                                                                <input type="number"
                                                                       class="form-control"
                                                                       name="storage_room"
                                                                       id="storage_room"
                                                                       placeholder="{{ __('Npr. 0') }}"
                                                                       value="{{ old('storage_room', $listing->storage_room) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Ostale prostorije --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="other_room" class="form-label">
                                                                    {{ __('Ostale prostorije (opis)') }}
                                                                </label>
                                                                <input type="text"
                                                                       class="form-control"
                                                                       name="other_room"
                                                                       id="other_room"
                                                                       placeholder="{{ __('Npr. Terasa, Vešernica...') }}"
                                                                       value="{{ old('other_room', $listing->other_room) }}">
                                                                <small class="form-text text-muted">
                                                                    {{ __('Odvojite zarezom ako ih je više.') }}
                                                                </small>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Osnovni detalji --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3">
                                                    <div class="col-lg-12">
                                                        <h5 class="single-input-title">{{ __('Osnovni detalji o nekretnini') }}</h5>
                                                    </div>
                                                    <div class="row">
                                                        {{-- Kvadratura/Enterijer --}}
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="interior" class="form-label">
                                                                    {{ __('Kvadratura / Enterijer (opis)') }}
                                                                </label>
                                                                <input type="text"
                                                                       class="form-control"
                                                                       name="interior"
                                                                       id="interior"
                                                                       placeholder="{{ __('Npr. 75m², Kompletno renoviran') }}"
                                                                       value="{{ old('interior', $listing->interior) }}">
                                                            </div>
                                                        </div>
                                                        {{-- Tip -*-
                                                        <div class="col-lg-6">
                                                            <div class="single-upload-input-from mb-3">
                                                                <label for="type" class="form-label">
                                                                    {{ __('Tip nekretnine') }}
                                                                </label>
                                                                <input type="text"
                                                                       class="form-control"
                                                                       name="type"
                                                                       id="type"
                                                                       placeholder="{{ __('Npr. Stan, Kuća, Apartman') }}"
                                                                       value="{{ old('type', $listing->type) }}">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Slike --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3">
                                                    <div class="col-lg-12">
                                                        <label for="images" class="form-label">
                                                            {{ __('Slike nekretnine') }} <span class="text-danger">*</span>
                                                        </label>
                                                        <input type="file"
                                                               name="images[]"
                                                               id="images"
                                                               class="form-control"
                                                               multiple>
                                                        <small class="form-text text-muted">
                                                            {{ __('Možete odabrati više slika odjednom.') }}
                                                        </small>
                                                    </div>
                                                    <div class="col-lg-12 mt-4">
                                                        <label class="form-label">{{ __('Trenutne slike') }}</label>
                                                        <div class="row">
                                                            @foreach($listing->images as $image)
                                                                <div class="col-md-3 mb-3">
                                                                    <div class="card">
                                                                        <img src="{{ asset('storage/' . $image->path) }}"
                                                                             class="card-img-top"
                                                                             alt="Listing Image">
                                                                        <div class="card-body text-center">
                                                                            <button type="button"
                                                                                    class="btn btn-danger btn-sm delete-image"
                                                                                    data-image-id="{{ $image->id }}">
                                                                                {{ __('Obriši') }}
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Sadržaji/Pogodnosti --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3">
                                                    <h5 class="single-input-title">{{ __('Sadržaji / Pogodnosti') }}</h5>
                                                    <div class="amenities-upload-input">
                                                        @php
                                                            $oldAmenities = old('amenities', $listing->amenities ?: []);
                                                        @endphp
                                                        @foreach(getPropertyAmenities() as $key => $amenity)
                                                            <div class="form-check form-check-inline mb-2">
                                                                <input type="checkbox"
                                                                       class="form-check-input"
                                                                       name="amenities[]"
                                                                       id="amenity{{ $key }}"
                                                                       value="{{ $key }}"
                                                                       {{ in_array($key, $oldAmenities) ? 'checked' : '' }}>
                                                                <label class="form-check-label"
                                                                       for="amenity{{ $key }}">{{ __($amenity) }}</label>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Informacije o okolini --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3" id="nearbyInfoSection">
                                                    <div class="d-flex justify-content-between align-items-center mb-3">
                                                        <h5 class="single-input-title">{{ __('Informacije o okolini') }}</h5>
                                                        <button type="button" id="addInfo" class="btn theme-btn btn-sm">
                                                            <i class="fas fa-plus"></i> {{ __('Dodaj još') }}
                                                        </button>
                                                    </div>
                                                    <div id="infoItems">
                                                        @php
                                                            $infoData   = old('info', $listing->info ?? []);
                                                            $hasOldInfo = isset(old('info')['name']);
                                                        @endphp

                                                        @if(count($infoData))
                                                            @foreach($infoData['name'] as $i => $name)
                                                                <div class="nearby-item border rounded p-3 mb-3 row">
                                                                    <input type="hidden"
                                                                           name="info[id][]"
                                                                           value="{{ $infoData['id'][$i] ?? '' }}">
                                                                    <div class="col-lg-6">
                                                                        <label class="form-label">{{ __('Naziv mesta/objekta') }}</label>
                                                                        <input type="text"
                                                                               name="info[name][]"
                                                                               class="form-control"
                                                                               placeholder="{{ __('Npr. prodavnica, škola, park') }}"
                                                                               value="{{ $name }}">
                                                                    </div>
                                                                    <div class="col-lg-6">
                                                                        <label class="form-label">{{ __('Udaljenost') }}</label>
                                                                        <input type="text"
                                                                               name="info[distance][]"
                                                                               class="form-control"
                                                                               placeholder="{{ __('Npr. 500m, 1km, 5 minuta hoda') }}"
                                                                               value="{{ $infoData['distance'][$i] ?? '' }}">
                                                                    </div>
                                                                    <div class="col-lg-6">
                                                                        <label class="form-label">{{ __('Kontakt telefon') }}</label>
                                                                        <input type="text"
                                                                               name="info[contact_number][]"
                                                                               class="form-control"
                                                                               placeholder="{{ __('Kontakt telefon (opciono)') }}"
                                                                               value="{{ $infoData['contact_number'][$i] ?? '' }}">
                                                                    </div>
                                                                    <div class="col-lg-6">
                                                                        <label class="form-label">{{ __('Postavi sliku') }}</label>
                                                                        <input type="file"
                                                                               name="info[image][{{ $i }}]"
                                                                               class="form-control">
                                                                        @if(!empty($infoData['image'][$i]))
                                                                            <div class="mt-2">
                                                                                <img src="{{ asset('storage/' . $infoData['image'][$i]) }}"
                                                                                     style="max-width: 100px;">
                                                                            </div>
                                                                        @endif
                                                                    </div>
                                                                    <div class="col-lg-12">
                                                                        <label class="form-label">{{ __('Detalji') }}</label>
                                                                        <textarea name="info[details][]"
                                                                                  class="form-control"
                                                                                  cols="30"
                                                                                  rows="3"
                                                                                  placeholder="{{ __('Dodatni detalji (opciono)') }}">{{ $infoData['details'][$i] ?? '' }}</textarea>
                                                                    </div>
                                                                    <div class="col-md-12 text-end">
                                                                        <button type="button"
                                                                                class="btn theme-btn-red btn-sm removeInfo"
                                                                                {{ ($i===0 && !$hasOldInfo) ? 'style=display:none;' : '' }}>
                                                                            <i class="far fa-trash-alt"></i>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        @else
                                                            {{-- Prvi prazan blok --}}
                                                            <div class="nearby-item border rounded p-3 mb-3 row">
                                                                <input type="hidden" name="info[id][]" value="">
                                                                <div class="col-lg-6">
                                                                    <label class="form-label">{{ __('Naziv mesta/objekta') }}</label>
                                                                    <input type="text"
                                                                           name="info[name][]"
                                                                           class="form-control"
                                                                           placeholder="{{ __('Npr. prodavnica, škola, park') }}">
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <label class="form-label">{{ __('Udaljenost') }}</label>
                                                                    <input type="text"
                                                                           name="info[distance][]"
                                                                           class="form-control"
                                                                           placeholder="{{ __('Npr. 500m, 1km, 5 minuta hoda') }}">
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <label class="form-label">{{ __('Kontakt telefon') }}</label>
                                                                    <input type="text"
                                                                           name="info[contact_number][]"
                                                                           class="form-control"
                                                                           placeholder="{{ __('Kontakt telefon (opciono)') }}">
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <label class="form-label">{{ __('Postavi sliku') }}</label>
                                                                    <input type="file"
                                                                           name="info[image][0]"
                                                                           class="form-control">
                                                                </div>
                                                                <div class="col-lg-12">
                                                                    <label class="form-label">{{ __('Detalji') }}</label>
                                                                    <textarea name="info[details][]"
                                                                              class="form-control"
                                                                              cols="30"
                                                                              rows="3"
                                                                              placeholder="{{ __('Dodatni detalji (opciono)') }}"></textarea>
                                                                </div>
                                                                <div class="col-md-12 text-end">
                                                                    <button type="button"
                                                                            class="btn theme-btn-red btn-sm removeInfo"
                                                                            style="display:none;">
                                                                        <i class="far fa-trash-alt"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Dugme za čuvanje --}}
                                            <div class="col-lg-12">
                                                <button type="submit"
                                                        class="btn theme-btn py-3 px-4 mt-3">
                                                    {{ __('Ažuriraj nekretninu') }}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>

                                {{-- Sakriveni URL template za brisanje slika --}}
                                <input type="hidden"
                                       id="imageDestroyUrlTemplate"
                                       value="{{ route('owner.listing.image.destroy', ['id' => '__image_id__']) }}">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Skriveni template za "Informacije o okolini" --}}
    <div id="nearbyInfoTemplate" style="display: none;">
        <div class="nearby-item border rounded p-3 mb-3 row">
            <input type="hidden" name="info[id][]" value="">
            <div class="col-lg-6">
                <label class="form-label">{{ __('Naziv mesta/objekta') }}</label>
                <input type="text"
                       name="info[name][]"
                       class="form-control"
                       placeholder="{{ __('Npr. prodavnica, škola, park') }}">
            </div>
            <div class="col-lg-6">
                <label class="form-label">{{ __('Udaljenost') }}</label>
                <input type="text"
                       name="info[distance][]"
                       class="form-control"
                       placeholder="{{ __('Npr. 500m, 1km, 5 minuta hoda') }}">
            </div>
            <div class="col-lg-6">
                <label class="form-label">{{ __('Kontakt telefon') }}</label>
                <input type="text"
                       name="info[contact_number][]"
                       class="form-control"
                       placeholder="{{ __('Kontakt telefon (opciono)') }}">
            </div>
            <div class="col-lg-6">
                <label class="form-label">{{ __('Postavi sliku') }}</label>
                <input type="file"
                       name="info[image][__INDEX__]"
                       class="form-control info-new-image-template">
            </div>
            <div class="col-lg-12">
                <label class="form-label">{{ __('Detalji') }}</label>
                <textarea name="info[details][]"
                          class="form-control"
                          cols="30"
                          rows="3"
                          placeholder="{{ __('Dodatni detalji (opciono)') }}"></textarea>
            </div>
            <div class="col-md-12 text-end">
                <button type="button" class="btn theme-btn-red btn-sm removeInfo">
                    <i class="far fa-trash-alt"></i>
                </button>
            </div>
        </div>
    </div>
@endsection

@push('style')
    <link rel="stylesheet" href="{{ asset('assets/properties/css/properties.css') }}">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
          integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
          crossorigin=""/>
    <style>
        #map { width: 100%; height: 400px; border-radius: 6px; border: 1px solid #dee2e6; }
        .single-upload-from-property { border: 1px solid #e9ecef; padding: 20px; border-radius: 10px; background-color: #f8f9fa; }
        .single-input-title { margin-bottom: 1.5rem; border-bottom: 1px solid #dee2e6; padding-bottom: 0.5rem; }
        .amenities-upload-input .form-check-inline { min-width: 150px; }
        .nearby-item { background-color: #fff; position: relative; }
        .removeInfo { cursor: pointer; }
    </style>
@endpush

@push('script')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
            integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
            crossorigin=""></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // MAP
            const latInput = document.getElementById('latitude');
            const lngInput = document.getElementById('longitude');
            const defaultLat = parseFloat(latInput.value) || 44.7866;
            const defaultLng = parseFloat(lngInput.value) || 20.4489;
            const initialZoom = (latInput.value && lngInput.value) ? 13 : 7;
            const map = L.map('map').setView([defaultLat, defaultLng], initialZoom);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '© OpenStreetMap'
            }).addTo(map);
            const marker = L.marker([defaultLat, defaultLng], { draggable: true }).addTo(map);
            function updateInputs(e) {
                const { lat, lng } = e.latlng;
                latInput.value = lat.toFixed(6);
                lngInput.value = lng.toFixed(6);
            }
            marker.on('dragend', ({ target }) => updateInputs({ latlng: target.getLatLng() }));
            map.on('click', updateInputs);
            latInput.addEventListener('change', () => {
                const lat = parseFloat(latInput.value);
                const lng = parseFloat(lngInput.value);
                if (!isNaN(lat) && !isNaN(lng)) {
                    marker.setLatLng([lat, lng]);
                    map.setView([lat, lng], map.getZoom());
                }
            });
            lngInput.addEventListener('change', () => latInput.dispatchEvent(new Event('change')));
            
            // DODAJ/UKLONI INFO
            let infoIndex = document.querySelectorAll('#infoItems .nearby-item').length;
            document.getElementById('addInfo').addEventListener('click', () => {
                const tpl = document.getElementById('nearbyInfoTemplate').innerHTML
                    .replace(/__INDEX__/g, infoIndex);
                const wrapper = document.createElement('div');
                wrapper.innerHTML = tpl;
                document.getElementById('infoItems').appendChild(wrapper.firstElementChild);
                infoIndex++;
                toggleRemove();
            });
            document.getElementById('infoItems').addEventListener('click', e => {
                if (e.target.closest('.removeInfo')) {
                    const items = document.querySelectorAll('#infoItems .nearby-item');
                    if (items.length > 1) {
                        e.target.closest('.nearby-item').remove();
                    } else {
                        e.target.closest('.nearby-item').querySelectorAll('input, textarea').forEach(i => i.value = '');
                    }
                    toggleRemove();
                }
            });
            function toggleRemove() {
                const items = document.querySelectorAll('#infoItems .nearby-item');
                items.forEach((el, i) => {
                    el.querySelector('.removeInfo').style.display = (i===0 && items.length===1) ? 'none' : 'inline-block';
                });
            }
            toggleRemove();

            // DELETE IMAGE
            document.querySelectorAll('.delete-image').forEach(btn => {
                btn.addEventListener('click', () => {
                    const id = btn.dataset.imageId;
                    if (!confirm('{{ __("Da li ste sigurni da želite da obrišete sliku?") }}')) return;
                    const urlTpl = document.getElementById('imageDestroyUrlTemplate').value;
                    const url = urlTpl.replace('__image_id__', id);
                    fetch(url, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        }
                    })
                    .then(r => r.json())
                    .then(json => {
                        if (json.success) {
                            btn.closest('.col-md-3').remove();
                            alert(json.message);
                        } else {
                            alert(json.message || '{{ __("Došlo je do greške.") }}');
                        }
                    })
                    .catch(() => alert('{{ __("Došlo je do greške prilikom brisanja slike.") }}'));
                });
            });

            // AJAX FORM HANDLER
            window.getShowListingMessage = response => {
                document.querySelectorAll('.is-invalid').forEach(i => i.classList.remove('is-invalid'));
                document.querySelectorAll('.invalid-feedback').forEach(f => f.remove());
                if (response.status) {
                    alert(response.message || '{{ __("Nekretnina uspešno ažurirana!") }}');
                } else {
                    alert(response.message || '{{ __("Došlo je do greške.") }}');
                    if (response.errors) {
                        for (let field in response.errors) {
                            let el = document.querySelector(`[name="${field}"]`);
                            if (el) {
                                el.classList.add('is-invalid');
                                const div = document.createElement('div');
                                div.className = 'invalid-feedback';
                                div.textContent = response.errors[field][0];
                                el.parentNode.appendChild(div);
                            }
                        }
                    }
                }
            };
        });
    </script>
@endpush
