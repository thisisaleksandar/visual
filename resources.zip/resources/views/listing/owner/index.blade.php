{{-- resources/views/owner/listing/index.blade.php --}}
@extends('owner.layouts.app')

@section('content')
<div class="main-content">
  <div class="page-content">
    <div class="container-fluid">
      {{-- Заглавље --}}
      <div class="row">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between border-bottom mb-20">
            <h3 class="mb-sm-0">{{ $pageTitle ?? __('All Listings') }}</h3>
            <div class="page-title-right">
              <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                  <a href="{{ route('owner.dashboard') }}">{{ __('Dashboard') }}</a>
                </li>
                <li class="breadcrumb-item active">{{ __('All Listings') }}</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div class="page-content-wrapper bg-white p-30 radius-20">
        {{-- Дугмад за додавање --}}
        <div class="d-flex justify-content-end mb-4">
          <a href="{{ route('owner.listing.create', ['with_property' => 1]) }}"
             class="btn btn-primary me-2">
            <i class="ri-building-line me-1"></i>{{ __('Add Listing with Property') }}
          </a>
          <a href="{{ route('owner.listing.create') }}" class="btn btn-secondary">
            <i class="ri-file-list-3-line me-1"></i>{{ __('Add Listing without Property') }}
          </a>
        </div>

        {{-- Табела огласа --}}
        <table id="listingsTable" class="table table-bordered">
          <thead>
            <tr>
              <th>{{ __('Property') }}</th>
              <th>{{ __('Name') }}</th>
              <th class="text-end">{{ __('Price') }}</th>
              <th>{{ __('City') }}</th>
              <th class="text-center">{{ __('Status') }}</th>
              <th class="text-center">{{ __('Actions') }}</th>
            </tr>
          </thead>
          <tbody>
            @forelse($listings as $listing)
              <tr>
                <td>{{ optional($listing->property)->name ?? '-' }}</td>
                <td>{{ $listing->name }}</td>
                <td class="text-end">{{ currencyPrice($listing->price) }}</td>
                <td>{{ $listing->city ?? '-' }}</td>
                <td class="text-center">
                  @switch($listing->status)
                    @case(1) {{ __('Active') }} @break
                    @case(2) {{ __('Pending') }} @break
                    @case(3) {{ __('Inactive') }} @break
                    @default {{ __('Unknown') }}
                  @endswitch
                </td>
                <td class="text-center">
                  <a href="{{ route('owner.listing.edit', $listing->id) }}"
                     class="btn btn-sm btn-primary me-1">
                    <i class="ri-edit-line"></i>
                  </a>
                  <form action="{{ route('owner.listing.destroy', $listing->id) }}"
                        method="POST"
                        class="d-inline"
                        onsubmit="return confirm('{{ __('Are you sure you want to delete this listing?') }}');">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-sm btn-danger">
                      <i class="ri-delete-bin-line"></i>
                    </button>
                  </form>
                </td>
              </tr>
            @empty
              <tr>
                <td colspan="6" class="text-center">{{ __('No listings found') }}</td>
              </tr>
            @endforelse
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
@endsection
