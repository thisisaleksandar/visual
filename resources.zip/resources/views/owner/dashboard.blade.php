@extends('owner.layouts.app')

@push('style')
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.css" rel="stylesheet"/>
<style>
    .fc-event {
        cursor: pointer;
        padding: 3px 5px;
        font-size: 0.85em;
        border-radius: 3px;
        border: 1px solid rgba(0,0,0,0.1);
        color: #fff;
    }
    .fc-event-main {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .custom-tooltip {
        position: absolute;
        background-color: #2c3e50;
        color: white;
        padding: 8px 12px;
        border-radius: 5px;
        font-size: 0.9em;
        z-index: 1070;
        opacity: 0;
        transition: opacity 0.15s ease-in-out;
        pointer-events: none;
        box-shadow: 0 3px 8px rgba(0,0,0,0.25);
        max-width: 280px;
        line-height: 1.5;
    }
    .custom-tooltip.show {
        opacity: 0.95;
    }
    .custom-tooltip strong {
        display: block;
        margin-bottom: 5px;
        color: #ecf0f1;
        font-size: 1.05em;
    }
    .custom-tooltip hr {
        border-top-color: #4b5a68;
    }
    .dashboard-feature-item {
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        padding: 20px;
        margin-bottom: 20px;
        text-align: center;
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }
    .dashboard-feature-item:hover {
        transform: translateY(-4px);
        box-shadow: 0 6px 12px rgba(0,0,0,0.1);
    }
    .dashboard-feature-item p {
        margin-bottom: 8px;
        color: #555;
        font-size: 0.95rem;
        font-weight: 500;
    }
    .dashboard-feature-item h2 {
        margin: 0;
        color: #2c3e50;
        font-size: 2.2rem;
        font-weight: 600;
    }
    .page-title-main {
        font-size: 1.75rem;
        font-weight: 600;
        color: #333;
        margin-bottom: 0.25rem;
    }
    .page-title-secondary-text {
        font-size: 0.95rem;
        color: #6c757d;
    }
    .card-title {
        font-weight: 500;
    }
    .table th {
        font-weight: 500;
        font-size: 0.9rem;
    }
    .list-group-item-action:hover, .list-group-item-action:focus {
        background-color: #f8f9fa;
    }
    .tooltip-payment-method {
        padding: 2px 6px;
        border-radius: 3px;
        color: #fff !important;
        display: inline-block;
        font-weight: bold;
    }
</style>
@endpush

@section('content')
<div class="main-content">
  <div class="page-content">
    <div class="container-fluid">
      {{-- Dashboard header --}}
      <div class="row mb-3 align-items-center">
        <div class="col-md-6">
          <h1 class="page-title-main">{{ $pageTitle ?? __('Kontrolna tabla') }}</h1>
          <p class="page-title-secondary-text">{{ __('Dobrodošli nazad') }}, {{ auth()->user()->first_name ?? auth()->user()->name }}!</p>
        </div>
        <div class="col-md-6 text-md-end mt-2 mt-md-0">
          @can('property_create') {{-- Prilagodi permisiju --}}
            <a href="{{ route('owner.property.add') }}" class="btn btn-primary"><i class="ri-add-line me-1"></i> {{ __('Dodaj Nekretninu') }}</a>
          @endcan
        </div>
      </div>

      {{-- Totals --}}
      <div class="row">
        <div class="col-sm-6 col-lg-4">
          <div class="dashboard-feature-item">
            <p><i class="ri-home-4-line me-1"></i>{{ __('Ukupno Nekretnina') }}</p>
            <h2>{{ $totalProperties }}</h2>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4">
          <div class="dashboard-feature-item">
            <p><i class="ri-layout-masonry-line me-1"></i>{{ __('Ukupno Oglasa') }}</p>
            <h2>{{ $totalListings }}</h2>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4">
          <div class="dashboard-feature-item">
            <p><i class="ri-user-3-line me-1"></i>{{ __('Aktivnih Stanara') }}</p>
            <h2>{{ $totalTenants }}</h2>
          </div>
        </div>
      </div>

      {{-- Calendar --}}
      <div class="row mb-4 mt-2">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
                <h4 class="card-title mb-0"><i class="ri-calendar-todo-line me-1"></i>{{ __('Evidencija Plaćanja Stanara') }}</h4>
            </div>
            <div class="card-body">
                <div id="payment-calendar" style="min-height:600px;"></div>
            </div>
          </div>
        </div>
      </div>

      {{-- Properties & Tickets --}}
      <div class="row">
        <div class="col-lg-7 mb-4">
          <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="card-title mb-0"><i class="ri-list-check-2 me-1"></i>{{ __('Moje Nekretnine') }} (Top {{ $properties->count() }})</h4>
                @if($totalProperties > $properties->count())
                    <a href="{{ route('owner.property.own') }}" class="btn btn-sm btn-outline-primary">{{ __('Vidi sve') }}</a>

                @endif
            </div>
            <div class="card-body px-0 py-2">
                <div class="table-responsive">
                    <table class="table table-hover table-nowrap mb-0">
                        <thead>
                        <tr>
                            <th class="ps-3">{{ __('Naziv') }}</th>
                            <th class="text-center">{{ __('Broj Oglasa') }}</th>
                            <th class="text-center">{{ __('Slobodnih Jedinica') }}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($properties as $prop)
                            <tr>
                                <td class="ps-3">
                                    <a href="{{ route('owner.property.show', $prop->id) }}" class="text-dark fw-medium">{{ Str::limit($prop->name, 35) }}</a>
                                </td>
                                <td class="text-center">{{ $prop->listings_count }}</td>
                                <td class="text-center">{{ $prop->listings_count - ($prop->occupied_units_count ?? 0) }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="3" class="text-center py-4">{{ __('Nema podataka o nekretninama.') }}</td></tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
          </div>
        </div>

        {{-- UKLONI OVAJ BLOK AKO NE KORISTIŠ TIKETE --}}
        @if(isset($tickets) && isset($totalUserTickets) && $tickets->count() > 0)
        <div class="col-lg-5 mb-4">
          <div class="card h-100">
             <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="card-title mb-0"><i class="ri-question-answer-line me-1"></i>{{ __('Tiketi') }} (Poslednjih {{ $tickets->count() }})</h4>
                @if($totalUserTickets > $tickets->count())
                     <a href="{{ route('owner.ticket.index') }}" class="btn btn-sm btn-outline-primary">{{ __('Vidi sve') }} ({{ $totalUserTickets }})</a>
                @endif
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    @foreach($tickets as $ticket)
                    <a href="{{ route('owner.ticket.show', $ticket->id) }}" class="list-group-item list-group-item-action">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1 text-truncate" style="max-width: 70%;">{{ $ticket->title }}</h6>
                            <small class="text-muted flex-shrink-0">{{ $ticket->created_at->diffForHumans(null, true, true) }}</small>
                        </div>
                        <p class="mb-1 text-muted small">
                            Status: <span class="badge bg-{{ getTicketStatusBadgeClass($ticket->status ?? 0) }}">{{ getTicketStatusName($ticket->status ?? 0) }}</span>
                        </p>
                    </a>
                    @endforeach
                </div>
            </div>
          </div>
        </div>
        @elseif(isset($tickets) && $tickets->count() == 0 && isset($totalUserTickets) && $totalUserTickets > 0)
        <div class="col-lg-5 mb-4">
          <div class="card h-100">
             <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="card-title mb-0"><i class="ri-question-answer-line me-1"></i>{{ __('Tiketi') }}</h4>
                 <a href="{{ route('owner.ticket.index') }}" class="btn btn-sm btn-outline-primary">{{ __('Vidi sve') }} ({{ $totalUserTickets }})</a>
            </div>
            <div class="card-body">
                 <p class="text-center p-4">{{ __('Nema novih tiketa za prikaz.') }}</p>
            </div>
          </div>
        </div>
        @endif
        {{-- KRAJ BLOKA ZA TIKETE --}}

      </div>
    </div>
  </div>
</div>
<div id="eventTooltip" class="custom-tooltip"></div>
@endsection

@push('script')
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/main.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.0/locales/sr.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
  var calendarEl = document.getElementById('payment-calendar');
  var eventTooltipEl = document.getElementById('eventTooltip');

  if (!calendarEl) {
      console.error("FullCalendar: Element #payment-calendar nije pronađen.");
  }
  if (!eventTooltipEl) {
      console.error("FullCalendar: Element #eventTooltip za tooltip nije pronađen.");
  }

  if (calendarEl && eventTooltipEl && typeof FullCalendar !== 'undefined') {
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'sr',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,listWeek'
        },
        events: @json($calendarEvents),
        editable: false,
        selectable: true,
        dayMaxEvents: 3,
        eventDisplay: 'block',
        aspectRatio: 1.8,

        eventClick: function(info) {
            info.jsEvent.preventDefault();

            var tenantId = info.event.extendedProps.tenant_id;

            if (tenantId) {
                // Konstruisanje URL-a na osnovu tvog primera
                // Prilagodi 'owner/tenant/details' ako je tvoja putanja drugačija
                var baseUrl = "{{ url('owner/tenant/details') }}";
                var tenantDetailUrl = baseUrl + '/' + tenantId + '?tab=profile'; // Dodajemo query parametar
                window.location.href = tenantDetailUrl;
            } else {
                console.warn('Tenant ID nije pronađen za ovaj događaj.');
            }
        },

        eventDidMount: function(info) {
            //
        },
        eventMouseEnter: function(info) {
            if (!eventTooltipEl) return;

            var props = info.event.extendedProps;
            var tooltipContent = `<strong>${props.full_title || info.event.title}</strong>`;

            tooltipContent += `<br>{{ __('Iznos') }}: ${props.invoice_amount || 'N/A'}`;
            tooltipContent += `<br>{{ __('Dospeva') }}: ${props.due_date_formatted || 'N/A'}`;
            tooltipContent += `<hr style="margin: 4px 0; border-top: 1px solid #5a6a78;">`;

            tooltipContent += `{{ __('Pref. način plaćanja') }}: <span class="tooltip-payment-method" style="background-color:${info.event.backgroundColor};">${props.preferred_payment_method_text || 'N/A'}</span>`;
            tooltipContent += `<br>{{ __('Status fakture') }}: ${props.invoice_status_text || 'N/A'}`;

            if (props.invoice_actual_payment_method && props.invoice_status_text === '{{__("Plaćeno")}}') {
                tooltipContent += `<br>{{ __('Plaćeno putem') }}: ${props.invoice_actual_payment_method}`;
            }
            if (props.invoice_actual_payment_status) {
                tooltipContent += `<br>{{ __('Stvarni status plaćanja') }}: ${props.invoice_actual_payment_status}`;
            }

            eventTooltipEl.innerHTML = tooltipContent;
            eventTooltipEl.classList.add('show');

            var x = info.jsEvent.pageX + 15;
            var y = info.jsEvent.pageY + 15;
            var viewportWidth = window.innerWidth;
            var viewportHeight = window.innerHeight;
            var tooltipRect = eventTooltipEl.getBoundingClientRect();

            if (x + tooltipRect.width > viewportWidth - 10) {
                x = info.jsEvent.pageX - tooltipRect.width - 15;
            }
            if (y + tooltipRect.height > viewportHeight - 10) {
                y = info.jsEvent.pageY - tooltipRect.height - 15;
            }
            if (x < 10) x = 10;
            if (y < 10) y = 10;

            eventTooltipEl.style.left = x + 'px';
            eventTooltipEl.style.top = y + 'px';
        },
        eventMouseLeave: function(info) {
            if (eventTooltipEl) {
                eventTooltipEl.classList.remove('show');
            }
        }
    });
    calendar.render();

    window.addEventListener('resize', function() {
        calendar.updateSize();
    });
  }
});

@if(isset($tickets) && isset($totalUserTickets))
function getTicketStatusBadgeClass(status) {
    switch(String(status)) {
        case '0': return 'warning';
        case '1': return 'info';
        case '2': return 'success';
        case '3': return 'danger';
        default: return 'secondary';
    }
}

function getTicketStatusName(status) {
    switch(String(status)) {
        case '0': return '{{ __("Otvoren") }}';
        case '1': return '{{ __("U toku") }}';
        case '2': return '{{ __("Rešen") }}';
        case '3': return '{{ __("Zatvoren") }}';
        default: return '{{ __("Nepoznat") }}';
    }
}
@endif
</script>
@endpush