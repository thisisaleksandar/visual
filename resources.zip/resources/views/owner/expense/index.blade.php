@extends('owner.layouts.app')

@section('content')
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <div class="page-content-wrapper bg-white p-30 radius-20">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between border-bottom mb-20">
                                <div class="page-title-left">
                                    <h3 class="mb-sm-0">{{ $pageTitle }}</h3>
                                </div>
                                <div class="page-title-right">
                                    <ol class="breadcrumb mb-0">
                                        <li class="breadcrumb-item">
                                            <a href="{{ route('owner.dashboard') }}" title="Kontrolna tabla">Kontrolna tabla</a>
                                        </li>
                                        <li class="breadcrumb-item active" aria-current="page">{{ $pageTitle }}</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="property-top-search-bar">
                            <div class="row align-items-center">
                                <div class="col-md-12">
                                    <div class="property-top-search-bar-right text-end">
                                        <button type="button" class="theme-btn mb-25 addExpenses" title="Dodaj novi trošak">
                                            Dodaj novi trošak
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="billing-center-area bg-off-white theme-border radius-4 p-25">
                            <table id="expensesDatatable" class="table responsive theme-border p-20 ">
                                <thead>
                                    <tr>
                                        <th>Naziv</th>
                                        <th>Nekretnina</th>
                                        <th>Tip troška</th>
                                        <th>Odgovornost</th>
                                        <th>Iznos</th>
                                        <th>Akcija</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal: Dodaj trošak -->
    <div class="modal fade" id="addExpensesModal" tabindex="-1" aria-labelledby="addExpensesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="addExpensesModalLabel"><span class="modalTitle">Dodaj trošak</span></h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Zatvori">
                        <span class="iconify" data-icon="akar-icons:cross"></span>
                    </button>
                </div>
                <form class="ajax" action="{{ route('owner.expense.store') }}" method="post" enctype="multipart/form-data" data-handler="getShowMessage">
                    @csrf
                    <div class="modal-body">
                        <div class="modal-inner-form-box border-bottom mb-25">
                            <div class="row">
                                <div class="col-md-12 mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Naziv</label>
                                    <input type="text" name="name" class="form-control name" placeholder="Naziv troška">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Nekretnina</label>
                                    <select class="form-select flex-shrink-0 property_id" name="property_id">
                                        <option value="">--Izaberi nekretninu--</option>
                                        @foreach ($properties as $property)
                                            <option value="{{ $property->id }}" data-units="{{ $property->propertyUnits }}">{{ $property->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-6 mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Jedinica</label>
                                    <select class="form-select flex-shrink-0 property_unit_id unitOption" name="property_unit_id">
                                        <option value="">--Izaberi jedinicu--</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="modal-inner-form-box">
                            <div class="row">
                                <div class="col-md-12 mb-25">
                                    <div class="row justify-content-between expence-type-add-new-box">
                                        <div class="col">
                                            <label class="label-text-title color-heading font-medium mb-2">Tip troška</label>
                                        </div>
                                        <div class="col text-end">
                                            <button type="button" class="expence-type-add-new-box-btn theme-secondary-link" data-bs-toggle="modal" data-bs-target="#addTypeModal">
                                                + Dodaj novi tip
                                            </button>
                                        </div>
                                    </div>
                                    <select class="form-select flex-shrink-0 expense_type_id" id="typesOption" name="expense_type_id">
                                        <option value="">--Izaberi tip--</option>
                                        @foreach ($expenseTypes as $expenseType)
                                            <option value="{{ $expenseType->id }}">{{ $expenseType->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-12 mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Opis</label>
                                    <textarea class="form-control description" name="description" placeholder="Opis troška"></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Ukupan iznos</label>
                                    <input type="number" step="any" name="total_amount" class="form-control total_amount" placeholder="Ukupan iznos">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-auto mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Odgovornost</label>
                                    <div>
                                        <div class="form-group custom-checkbox d-inline me-3">
                                            <input type="checkbox" value="1" name="responsibilities[0]" id="responseTenant">
                                            <label class="fw-normal" for="responseTenant">Stanari</label>
                                        </div>
                                        <div class="form-group custom-checkbox d-inline me-3">
                                            <input type="checkbox" value="2" name="responsibilities[1]" id="responseOwner">
                                            <label class="fw-normal" for="responseOwner">Vlasnik nekretnine</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <label class="label-text-title color-heading font-medium mb-2">Otpremi dokument</label>
                                    <input type="file" name="file" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-start">
                        <a href="javascript:void(0)" class="theme-btn-back me-3" data-bs-dismiss="modal" title="Nazad">Nazad</a>
                        <button type="submit" class="theme-btn me-3" title="Sačuvaj trošak">Sačuvaj trošak</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal: Izmeni trošak -->
    <div class="modal fade" id="editExpensesModal" tabindex="-1" aria-labelledby="editExpensesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="editExpensesModalLabel"><span class="modalTitle">Izmeni trošak</span></h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Zatvori"><span class="iconify" data-icon="akar-icons:cross"></span></button>
                </div>
                <form class="ajax" action="{{ route('owner.expense.store') }}" method="post" enctype="multipart/form-data" data-handler="getShowMessage">
                    @csrf
                    <input type="hidden" class="id" name="id">
                    <div class="modal-body">
                        <div class="modal-inner-form-box border-bottom mb-25">
                            <div class="row">
                                <div class="col-md-12 mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Naziv</label>
                                    <input type="text" name="name" class="form-control name" placeholder="Naziv troška">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Nekretnina</label>
                                    <select class="form-select flex-shrink-0 property_id" name="property_id">
                                        <option value="">--Izaberi nekretninu--</option>
                                        @foreach ($properties as $property)
                                            <option value="{{ $property->id }}" data-units="{{ $property->propertyUnits }}">{{ $property->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-6 mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Jedinica</label>
                                    <select class="form-select flex-shrink-0 property_unit_id unitOption" name="property_unit_id">
                                        <option value="">--Izaberi jedinicu--</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="modal-inner-form-box">
                            <div class="row">
                                <div class="col-md-12 mb-25">
                                    <div class="row justify-content-between expence-type-add-new-box">
                                        <div class="col">
                                            <label class="label-text-title color-heading font-medium mb-2">Tip troška</label>
                                        </div>
                                    </div>
                                    <select class="form-select flex-shrink-0 expense_type_id" id="typesOption" name="expense_type_id">
                                        <option value="">--Izaberi tip--</option>
                                        @foreach ($expenseTypes as $expenseType)
                                            <option value="{{ $expenseType->id }}">{{ $expenseType->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-12 mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Opis</label>
                                    <textarea class="form-control description" name="description" placeholder="Opis troška"></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Ukupan iznos</label>
                                    <input type="number" step="any" name="total_amount" class="form-control total_amount" placeholder="Ukupan iznos">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-auto mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Odgovornost</label>
                                    <div>
                                        <div class="form-group custom-checkbox d-inline me-3">
                                            <input type="checkbox" value="1" name="responsibilities[0]" id="responseTenantEdit">
                                            <label class="fw-normal" for="responseTenantEdit">Stanari</label>
                                        </div>
                                        <div class="form-group custom-checkbox d-inline me-3">
                                            <input type="checkbox" value="2" name="responsibilities[1]" id="responseOwnerEdit">
                                            <label class="fw-normal" for="responseOwnerEdit">Vlasnik nekretnine</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <label class="label-text-title color-heading font-medium mb-2">Otpremi dokument</label>
                                    <input type="file" name="file" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-start">
                        <a href="javascript:void(0)" class="theme-btn-back me-3" data-bs-dismiss="modal" title="Nazad">Nazad</a>
                        <button type="submit" class="theme-btn me-3" title="Sačuvaj trošak">Sačuvaj trošak</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal: Dodaj tip troška -->
    <div class="modal fade" id="addTypeModal" tabindex="-1" aria-labelledby="addTypeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="addTypeModalLabel">Dodaj novi tip troška</h4>
                    <a type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Zatvori">
                        <span class="iconify" data-icon="akar-icons:cross"></span>
                    </a>
                </div>
                <form class="ajax" action="{{ route('owner.setting.expense-type.store') }}"
"
" method="POST" data-handler="typeStoreDataRes">
                    @csrf
                    <div class="modal-body">
                        <div class="modal-inner-form-box">
                            <div class="row">
                                <div class="col-md-12 mb-25">
                                    <label class="label-text-title color-heading font-medium mb-2">Naziv tipa troška</label>
                                    <input type="text" name="type_name" class="form-control" placeholder="Naziv tipa">
                                </div>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" class="modalType" value="created">
                    <div class="modal-footer justify-content-start">
                        <a href="javascript:void(0)" class="theme-btn-back me-3" data-bs-dismiss="modal" title="Nazad">Nazad</a>
                        <button type="submit" class="theme-btn me-3" title="Sačuvaj">Sačuvaj</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <input type="hidden" id="expenseIndexRoute" value="{{ route('owner.expense.index') }}">
@endsection

@push('style')
    @include('common.layouts.datatable-style')
@endpush

@push('script')
    @include('common.layouts.datatable-script')
    <script src="{{ asset('assets/js/custom/expense.js') }}"></script>
@endpush
