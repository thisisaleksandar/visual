<div class="vertical-menu">
    <div data-simplebar class="h-100">
        <div id="sidebar-menu">
            <ul class="metismenu list-unstyled" id="side-menu">

                <li>
                    <a href="{{ route('owner.dashboard') }}">
                        <i class="ri-dashboard-line"></i>
                        <span>{{ __('Dashboard') }}</span>
                    </a>
                </li>

                @can('Manage Property')
                    <li>
                        <a href="javascript: void(0);" class="has-arrow">
                            <i class="ri-building-line"></i>
                            <span>{{ __('Properties') }}</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            {{-- ISPRAVLJENA IMENA RUTA ZA PROPERTY --}}
                            <li><a href="{{ route('owner.property.all') }}">{{ __('All Property') }}</a></li>
                            <li class="{{ request()->routeIs('owner.listing.*') ? 'active' : '' }}">
                                <a href="{{ route('owner.listing.index') }}">{{ __('All Listings') }}</a>
                            </li>
                            <li><a href="{{ route('owner.property.own') }}">{{ __('Own Property') }}</a></li>
                            {{-- <li><a href="{{ route('owner.property.lease') }}">{{ __('Lease Property') }}</a></li> --}}
                        </ul>
                    </li>
                @endcan

                @can('Uredi korisnike')
                    <li>
                        {{-- Ruta za rent-users.index je deo resource kontrolera, ime je korektno --}}
                        <a href="{{ route('owner.rent-users.index') }}">
                            <i class="ri-user-line"></i>
                            <span>Korisnici</span>
                        </a>
                    </li>
                @endcan

                @can('Manage Tenant')
                    <li>
                        <a href="javascript: void(0);" class="has-arrow">
                            <i class="ri-user-3-line"></i>
                            <span>{{ __('Tenants') }}</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            {{-- Ove rute za tenant.index sa parametrima su verovatno OK ako ih tako obrađujete u kontroleru --}}
                            <li><a href="{{ route('owner.tenant.index', ['type' => 'all']) }}">{{ __('All Tenants') }}</a></li>
                            <li><a href="{{ route('owner.tenant.index', ['type' => 'history']) }}">{{ __('Tenant History') }}</a></li>
                        </ul>
                    </li>
                @endcan

                @can('Manage Billing')
                    <li>
                        <a href="javascript: void(0);" class="has-arrow">
                            <i class="ri-wallet-line"></i>
                            <span>{{ __('Billing Center') }}</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="{{ route('owner.invoice.index') }}">{{ __('All Invoices') }}</a></li>
                            <li><a href="{{ route('owner.invoice.recurring-setting.index') }}">{{ __('Recurring Setting') }}</a></li>
                        </ul>
                    </li>
                @endcan

                @can('Manage Expenses')
                    <li>
                        <a href="{{ route('owner.expense.index') }}">
                            <i class="ri-file-list-line"></i>
                            <span>{{ __('Expenses') }}</span>
                        </a>
                    </li>
                @endcan

                {{-- @can('Manage Information')
                    <li>
                        <a href="{{ route('owner.information.index') }}">
                            <i class="ri-folder-info-line"></i>
                            <span>{{ __('Information') }}</span>
                        </a>
                    </li>
                @endcan --}}

                @if (isAddonInstalled('PROTYLISTING') > 0 && getOption('LISTING_STATUS', 0) == ACTIVE)
                    @can('Manage Listing')
                        <li>
                            <a href="javascript: void(0);" class="has-arrow">
                                <i class="ri-file-list-3-line"></i>
                                <span>{{ __('My Listing') }}</span>
                            </a>
                            <ul class="sub-menu" aria-expanded="false">
                                <li><a href="{{ route('owner.listing.create') }}">{{ __('Upload List') }}</a></li>
                                <li><a href="{{ route('owner.listing.index') }}">{{ __('All List') }}</a></li>
                                {{-- Pretpostavljam da 'owner.listing.contact' ruta postoji i da je ispravno imenovana --}}
                                {{-- Ako ste i nju preimenovali (npr. u contact.list ili samo contact), ažurirajte --}}
                                <li><a href="{{ route('owner.listing.contact') }}">{{ __('Contact List') }}</a></li>
                            </ul>
                        </li>
                    @endcan
                @endif

                {{-- @can('Manage Maintains')
                    <li>
                        <a href="javascript: void(0);" class="has-arrow">
                            <i class="ri-tools-line"></i>
                            <span>{{ __('Maintains') }}</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="{{ route('owner.maintainer.index') }}">{{ __('Maintainers') }}</a></li>
                            <li><a href="{{ route('owner.maintenance-request.index') }}">{{ __('Maintenance Request') }}</a></li>
                        </ul>
                    </li>
                @endcan --}}

                {{-- @if (isAddonInstalled('PROTYSAAS') < 1 || ownerCurrentPackage(getOwnerUserId())?->ticket_support == ACTIVE)
                    @can('Manage Ticket')
                        <li>
                            <a href="{{ route('owner.ticket.index') }}">
                                <i class="ri-bookmark-2-line"></i>
                                <span>{{ __('Tickets') }}</span>
                            </a>
                        </li>
                    @endcan
                @endif --}}

                {{-- @if (isAddonInstalled('PROTYSAAS') < 1 || ownerCurrentPackage(getOwnerUserId())?->notice_support == ACTIVE)
                    @can('Manage Noticeboard')
                        <li>
                            <a href="{{ route('owner.noticeboard.index') }}"> // Proverite da li ste noticeboard.index preimenovali
                                <i class="ri-artboard-line"></i>
                                <span>{{ __('Notice Board') }}</span>
                            </a>
                        </li>
                    @endcan
                @endif --}}

                @can('Manage Report')
                    <li>
                        <a href="javascript: void(0);" class="has-arrow">
                            <i class="ri-folder-chart-line"></i>
                            <span>{{ __('Report') }}</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            {{-- Ove rute za reportove su specifične i verovatno su ispravne ako tako stoje u fajlu sa rutama --}}
                            <li><a href="{{ route('owner.reports.earning') }}">{{ __('Earning') }}</a></li>
                            <li><a href="{{ route('owner.reports.loss-profit.by.month') }}">{{ __('Loss / Profit By Month') }}</a></li>
                            <li><a href="{{ route('owner.reports.expenses') }}">{{ __('Expenses') }}</a></li>
                            <li><a href="{{ route('owner.reports.occupancy') }}">{{ __('Occupancy') }}</a></li>
                            <li><a href="{{ route('owner.reports.maintenance') }}">{{ __('Maintenance') }}</a></li>
                            <li><a href="{{ route('owner.reports.tenant') }}">{{ __('Tenant') }}</a></li>
                        </ul>
                    </li>
                @endcan

                @can('Manage Settings')
                    <li>
                        {{-- Ova ruta vodi na gateway.index unutar setting grupe, ime je ispravno --}}
                        <a href="{{ route('owner.setting.gateway.index') }}">
                            <i class="ri-settings-3-line"></i>
                            <span>{{ __('Settings') }}</span>
                        </a>
                    </li>
                @endcan

                {{-- @can('Manage Team')
                    <li>
                        <a href="javascript: void(0);" class="has-arrow">
                            <i class="ri-team-line"></i>
                            <span>{{ __('Manage Staff') }}</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="{{ route('owner.role-permission.role-list') }}">{{ __('Role & Permission') }}</a></li>
                            <li><a href="{{ route('owner.team-member.index') }}">{{ __('Staff Users') }}</a></li>
                        </ul>
                    </li>
                @endcan --}}

                <li>
                    <a href="javascript: void(0);" class="has-arrow">
                        <i class="ri-account-circle-line"></i>
                        <span>{{ __('Profile') }}</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        {{-- Pretpostavka da rute 'profile' i 'change-password' postoje globalno ili unutar 'owner.' grupe --}}
                        <li><a href="{{ route('profile') }}">{{ __('My Profile') }}</a></li>
                        <li><a href="{{ route('change-password') }}">{{ __('Change Password') }}</a></li>
                    </ul>
                </li>

                {{-- @if (isAddonInstalled('PROTYSAAS') > 1)
                    @can('Manage Subscription')
                        <li>
                            <a href="{{ route('owner.subscription.index') }}"> // Proverite da li ste owner.subscription.index preimenovali
                                <i class="ri-exchange-dollar-fill"></i>
                                <span>{{ __('My Subscription') }}</span>
                            </a>
                        </li>
                    @endcan
                @endif --}}

            </ul>
        </div>
    </div>
</div>