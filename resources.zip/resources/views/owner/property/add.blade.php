{{-- resources/views/owner/property/add.blade.php --}}

@extends('owner.layouts.app')

@section('content')
<div class="main-content">
  <div class="page-content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between border-bottom mb-20">
                <div class="page-title-left">
                    <h3 class="mb-sm-0">{{ __('Dodaj Nekretninu i Oglas') }}</h3>
                </div>
                <div class="page-title-right">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="{{ route('owner.dashboard') }}" title="{{ __('Kontrolna tabla') }}">{{ __('Kontrolna tabla') }}</a></li>
                        <li class="breadcrumb-item" aria-current="page"><a href="{{ route('owner.listing.index') }}">{{ __('Moji oglasi') }}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{ __('Dodaj Novi') }}</li>
                    </ol>
                </div>
            </div>
        </div>
      </div>

      <div class="page-content-wrapper bg-white p-30 radius-20">

        {{-- KORAK 1: Forma za kreiranje Property-ja --}}
        <div id="propertyCreateSection">
            <h4 class="mb-3">{{ __('Korak 1: Kreiraj Nekretninu') }}</h4>
            <form class="mb-4" {{-- Uklonjena klasa 'ajax' ako se handler vezuje direktno na ID --}}
                  id="propertyCreateForm"
                action="{{ route('owner.property.information.store') }}"

                  method="post"> {{-- data-handler više nije potreban ovde --}}
              @csrf
              <input type="hidden" name="property_type" value="1">
              <input type="hidden" name="own_number_of_unit" value="1" /> {{-- Dodato na osnovu prethodnog zahteva --}}

              <div class="form-card add-property-box bg-off-white theme-border radius-4 p-20">
                <div class="row">
                  <div class="col-md-12 mb-3">
                    <label class="form-label" for="own_property_name">{{ __('Naziv nekretnine') }} <span class="text-danger">*</span></label>
                    <input type="text"
                           id="own_property_name"
                           name="own_property_name"
                           class="form-control"
                           placeholder="{{ __('Unesite naziv nekretnine') }}"
                           value="{{ old('own_property_name') }}"
                           required>
                  </div>
                  <div class="col-md-12 mb-3">
                    <label for="property_description_step1" class="form-label">{{ __('Osnovni opis nekretnine (opciono)') }}</label>
                    <textarea name="own_description" id="property_description_step1" class="form-control" placeholder="{{ __('Kratak opis...') }}" rows="3">{{ old('own_description') }}</textarea>
                  </div>
                </div>
                <button type="submit" class="btn theme-btn" id="savePropertyButton">
                  <span class="spinner-border spinner-border-sm me-2 d-none" role="status" aria-hidden="true"></span>
                  {{ __('Sačuvaj Nekretninu i Nastavi na Oglas') }}
                </button>
              </div>
            </form>
        </div>

        {{-- KORAK 2: Forma za kreiranje Listing-a (Oglasa) - INICIJALNO SKRIVENA --}}
        <div id="listingCreateSection" style="display: none;">
            <hr class="my-4">
            <h4 class="mb-3">{{ __('Korak 2: Dodaj Oglas za Nekretninu ') }}<span id="createdPropertyName" class="text-primary"></span></h4>
            <form {{-- Uklonjena klasa 'ajax' --}}
                  id="listingCreateForm"
                  action="{{ route('owner.listing.store') }}"
                  method="POST"
                  enctype="multipart/form-data"> {{-- data-handler više nije potreban ovde --}}
              @csrf
              <input type="hidden" name="property_id" id="listing_property_id" value="">

              <div class="upload-from-area">
                <div class="row">
                  {{-- SEKCIJA: Detalji Oglasa --}}
                  <div class="col-lg-12">
                    <div class="single-upload-from-property p-3 theme-border bg-off-white radius-4 mb-4">
                      <h5 class="single-input-title">{{ __('Detalji Oglasa') }}</h5>
                      <div class="row">
                        <div class="col-lg-6">
                          <div class="single-upload-input-from mb-3">
                            <label for="name" class="form-label">{{ __('Naziv oglasa') }} <span class="text-danger">*</span></label>
                            <input type="text" id="name" name="name" class="form-control" placeholder="{{ __('Naslov oglasa') }}" value="{{ old('name') }}" required>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="single-upload-input-from mb-3">
                            <label for="price" class="form-label">{{ __('Cena po danu') }} <span class="text-danger">*</span></label>
                            <input type="number" step="any" id="price" name="price" class="form-control" placeholder="{{ __('Unesite cenu') }}" value="{{ old('price') }}" required>
                            <input type="hidden" name="price_duration_type" value="daily">
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="single-upload-input-from mb-3">
                            <label for="status" class="form-label">{{ __('Status') }} <span class="text-danger">*</span></label>
                            <select id="status" name="status" class="form-select" required>
                              <option value="1" {{ old('status',1)==1?'selected':'' }}>{{ __('Aktivan') }}</option>
                              <option value="2" {{ old('status')==2?'selected':'' }}>{{ __('Deaktiviran') }}</option>
                              <option value="3" {{ old('status')==3?'selected':'' }}>{{ __('Izdat') }}</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="single-upload-input-from mb-3">
                            <div class="form-check mt-4 pt-2">
                              <input class="form-check-input" type="checkbox" id="is_instant" name="is_instant" value="1" {{ old('is_instant')?'checked':'' }}>
                              <label class="form-check-label" for="is_instant">{{ __('Dostupno odmah') }}</label>
                            </div>
                          </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="single-upload-input-from mb-3">
                                <label for="city" class="form-label">{{ __('Grad') }}</label>
                                <input type="text" id="city" name="city" class="form-control" placeholder="{{ __('Grad') }}" value="{{ old('city') }}">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="single-upload-input-from mb-3">
                                <label for="zip_code" class="form-label">{{ __('Poštanski broj') }}</label>
                                <input type="text" id="zip_code" name="zip_code" class="form-control" placeholder="{{ __('Poštanski broj') }}" value="{{ old('zip_code') }}">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="single-upload-input-from mb-3">
                                <label for="address" class="form-label">{{ __('Adresa') }}</label>
                                <input type="text" id="address" name="address" class="form-control" placeholder="{{ __('Adresa') }}" value="{{ old('address') }}">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="single-upload-input-from mb-3">
                                <label for="latitude" class="form-label">{{ __('Geografska širina (Latitude)') }}</label>
                                <input type="number" step="any" name="latitude" value="{{ old('latitude') }}" class="form-control" id="latitude" placeholder="{{ __('Latitude') }}">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="single-upload-input-from mb-3">
                                <label for="longitude" class="form-label">{{ __('Geografska dužina (Longitude)') }}</label>
                                <input type="number" step="any" name="longitude" value="{{ old('longitude') }}" class="form-control" id="longitude" placeholder="{{ __('Longitude') }}">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="single-upload-input-from mb-3">
                                <label class="form-label">{{ __('Lokacija na mapi') }}</label>
                                <div id="map" style="height: 300px; border: 1px solid #ccc; border-radius: 6px;"></div>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {{-- SEKCIJA: Specifikacija Nekretnine --}}
                  <div class="col-lg-12">
                    <div class="single-upload-from-property p-3 theme-border bg-off-white radius-4 mb-4">
                      <h5 class="single-input-title">{{ __('Specifikacija nekretnine') }}</h5>
                      <div class="row">
                        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label for="bed_room" class="form-label">{{ __('Broj spavaćih soba') }}</label><input type="number" id="bed_room" name="bed_room" class="form-control" placeholder="{{ __('Npr. 2') }}" value="{{ old('bed_room') }}"></div></div>
                        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label for="bath_room" class="form-label">{{ __('Broj kupatila') }}</label><input type="number" id="bath_room" name="bath_room" class="form-control" placeholder="{{ __('Npr. 1') }}" value="{{ old('bath_room') }}"></div></div>
                        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label for="kitchen_room" class="form-label">{{ __('Broj kuhinja') }}</label><input type="number" id="kitchen_room" name="kitchen_room" class="form-control" placeholder="{{ __('Npr. 1') }}" value="{{ old('kitchen_room') }}"></div></div>
                        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label for="dining_room" class="form-label">{{ __('Broj trpezarija') }}</label><input type="number" name="dining_room" id="dining_room" class="form-control" placeholder="{{ __('Npr. 1') }}" value="{{ old('dining_room') }}"></div></div>
                        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label for="living_room" class="form-label">{{ __('Broj dnevnih soba') }}</label><input type="number" id="living_room" name="living_room" class="form-control" placeholder="{{ __('Npr. 1') }}" value="{{ old('living_room') }}"></div></div>
                        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label for="storage_room" class="form-label">{{ __('Broj ostava') }}</label><input type="number" name="storage_room" id="storage_room" class="form-control" placeholder="{{ __('Npr. 0') }}" value="{{ old('storage_room') }}"></div></div>
                        <div class="col-lg-12"><div class="single-upload-input-from mb-3"><label for="other_room" class="form-label">{{ __('Ostale prostorije (opis)') }}</label><input type="text" id="other_room" name="other_room" class="form-control" placeholder="{{ __('Npr. Terasa, Vešernica, Ostava...') }}" value="{{ old('other_room') }}"><small class="form-text text-muted">{{ __('Odvojite zarezom ako ih je više.') }}</small></div></div>
                        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label for="interior" class="form-label">{{ __('Kvadratura / Enterijer (opis)') }}</label><input type="text" name="interior" id="interior" class="form-control" placeholder="{{ __('Npr. 75m², Kompletno renoviran') }}" value="{{ old('interior') }}"></div></div>
                        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label for="type" class="form-label">{{ __('Tip nekretnine (oglas)') }}</label><input type="text" name="type" id="type" class="form-control" placeholder="{{ __('Npr. Stan, Kuća, Apartman') }}" value="{{ old('type') }}"></div></div>
                        <div class="col-lg-12"><div class="form-check mt-3 mb-3"><input class="form-check-input" type="checkbox" name="jacuzzi" id="jacuzzi" value="1" {{ old('jacuzzi') ? 'checked' : '' }}><label class="form-check-label" for="jacuzzi">{{ __('Jacuzzi') }}</label></div></div>
                      </div>
                    </div>
                  </div>

                  {{-- SEKCIJA: Slike Oglasa --}}
                  <div class="col-lg-12">
                    <div class="single-upload-from-property p-3 theme-border bg-off-white radius-4 mb-4">
                        <h5 class="single-input-title">{{ __('Slike Oglasa') }}</h5>
                        <div class="row">
                            <div class="col-lg-12"><div class="single-upload-input-from mb-3"><label for="images" class="form-label">{{ __('Slike za oglas') }} <span class="text-danger">*</span></label><input type="file" id="images" name="images[]" class="form-control" multiple required><small class="form-text text-muted">{{ __('Možete odabrati više slika odjednom.') }}</small></div></div>
                        </div>
                    </div>
                  </div>

                  {{-- SEKCIJA: Sadržaji / Pogodnosti --}}
                  <div class="col-lg-12">
                    <div class="single-upload-from-property p-3 theme-border bg-off-white radius-4 mb-4">
                      <h5 class="single-input-title">{{ __('Sadržaji / Pogodnosti') }}</h5>
                      <div class="row"><div class="col-lg-12"><div class="amenities-upload-input">
                        @php $selectedAmenities = old('amenities', []); @endphp
                        @foreach (getPropertyAmenities() as $key => $amenity)
                          <div class="single-interior form-check form-check-inline mb-2"><input type="checkbox" class="form-check-input" name="amenities[]" id="amenity{{ $key }}" value="{{ $key }}" {{ in_array((string)$key, $selectedAmenities, true) ? 'checked' : '' }}><label class="form-check-label" for="amenity{{ $key }}">{{ __($amenity) }}</label></div>
                        @endforeach
                      </div></div></div>
                    </div>
                  </div>

                  {{-- SEKCIJA: Informacije o okolini --}}
                  <div class="col-lg-12">
                    <div class="single-upload-from-property p-3 theme-border bg-off-white radius-4 mb-4" id="nearbyInfoSection">
                      <div class="col-lg-12 d-flex justify-content-between align-items-center mb-3"><h5 class="single-input-title mb-0">{{ __('Informacije o okolini') }}</h5><button type="button" class="btn theme-btn btn-sm" id="addInfo"><i class="fas fa-plus"></i> {{ __('Dodaj još') }}</button></div>
                      <div id="infoItems">
                            @php
                                $infoDataForLoop = [];
                                $hasOldInfo = !empty(old('info')) && isset(old('info')['name']) && is_array(old('info')['name']);

                                if ($hasOldInfo) {
                                    if(isset(old('info')['name']) && is_array(old('info')['name'])) {
                                        foreach(old('info')['name'] as $idx => $nameVal) {
                                            $infoDataForLoop[] = [
                                                'id' => old('info')['id'][$idx] ?? '', 'name' => $nameVal,
                                                'distance' => old('info')['distance'][$idx] ?? '',
                                                'contact_number' => old('info')['contact_number'][$idx] ?? '',
                                                'details' => old('info')['details'][$idx] ?? '', 'image_url' => null
                                            ];
                                        }
                                    }
                                }
                                if (empty($infoDataForLoop)) {
                                    $infoDataForLoop[] = ['id' => '', 'name' => '', 'distance' => '', 'contact_number' => '', 'details' => '', 'image_url' => null];
                                }
                            @endphp
                            @foreach ($infoDataForLoop as $index => $itemData)
                                <div class="row border rounded p-3 mb-3 nearby-item">
                                    <input type="hidden" name="info[id][]" value="{{ $itemData['id'] ?? '' }}">
                                    <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label class="form-label">{{ __('Naziv mesta/objekta') }}</label><input type="text" name="info[name][]" class="form-control info-name" placeholder="{{ __('Npr. prodavnica, škola, park') }}" value="{{ $itemData['name'] ?? '' }}"></div></div>
                                    <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label class="form-label">{{ __('Udaljenost') }}</label><input type="text" name="info[distance][]" class="form-control" placeholder="{{ __('Npr. 500m, 1km, 5 minuta hoda') }}" value="{{ $itemData['distance'] ?? '' }}"></div></div>
                                    <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label class="form-label">{{ __('Kontakt telefon') }}</label><input type="text" name="info[contact_number][]" class="form-control" placeholder="{{ __('Kontakt telefon (opciono)') }}" value="{{ $itemData['contact_number'] ?? '' }}"></div></div>
                                    <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label class="form-label">{{ __('Postavi sliku') }}</label><input type="file" name="info[image][{{ $index }}]" class="form-control"></div></div>
                                    <div class="col-lg-12"><div class="single-upload-input-from mb-3"><label class="form-label">{{ __('Detalji') }}</label><textarea name="info[details][]" class="form-control" placeholder="{{ __('Dodatni detalji (opciono)') }}" cols="30" rows="3">{{ $itemData['details'] ?? '' }}</textarea></div></div>
                                    <div class="col-md-12 d-flex justify-content-end"><button type="button" class="btn theme-btn-red btn-sm removeInfo" title="{{ __('Ukloni stavku') }}" style="{{ count($infoDataForLoop) <= 1 && !$hasOldInfo ? 'display: none;' : '' }}"><i class="far fa-trash-alt"></i></button></div>
                                </div>
                            @endforeach
                      </div>
                    </div>
                  </div>

                  {{-- SEKCIJA: Prednosti --}}
                  <div class="col-lg-12">
                    <div class="single-upload-from-property p-3 theme-border bg-off-white radius-4 mb-4">
                      <h5 class="single-input-title">{{ __('Prednosti') }}</h5>
                      <div class="row"><div class="col-lg-12"><div class="amenities-upload-input">
                        @php $selectedAdvantages = old('advantage', []); @endphp
                        @foreach (getPropertyAdvantages() as $key => $advantage)
                          <div class="single-interior form-check form-check-inline mb-2"><input type="checkbox" class="form-check-input" name="advantage[]" value="{{ $key }}" id="advantage{{ $key }}" {{ in_array((string)$key, $selectedAdvantages, true) ? 'checked' : '' }}><label class="form-check-label" for="advantage{{ $key }}">{{ __($advantage) }}</label></div>
                        @endforeach
                      </div></div></div>
                    </div>
                  </div>

                  {{-- Dugme za čuvanje Oglasa --}}
                  <div class="col-lg-12 text-end">
                    <button type="submit" class="btn theme-btn py-3 px-4" id="saveListingButton">
                        <span class="spinner-border spinner-border-sm me-2 d-none" role="status" aria-hidden="true"></span>
                        {{ __('Sačuvaj Oglas') }}
                    </button>
                  </div>
                </div>
              </div>
            </form>
        </div>
      </div>
    </div>
  </div>
</div>
<input type="hidden" value="{{ route('owner.listing.index') }}" id="listingIndexRoute">

<div id="nearbyInfoTemplate" style="display: none;">
    <div class="row border rounded p-3 mb-3 nearby-item">
         <input type="hidden" name="info[id][]" value="">
        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label class="form-label">{{ __('Naziv mesta/objekta') }}</label><input type="text" name="info[name][]" class="form-control info-name" placeholder="{{ __('Npr. prodavnica, škola, park') }}"></div></div>
        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label class="form-label">{{ __('Udaljenost') }}</label><input type="text" name="info[distance][]" class="form-control" placeholder="{{ __('Npr. 500m, 1km, 5 minuta hoda') }}"></div></div>
        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label class="form-label">{{ __('Kontakt telefon') }}</label><input type="text" name="info[contact_number][]" class="form-control" placeholder="{{ __('Kontakt telefon (opciono)') }}"></div></div>
        <div class="col-lg-6"><div class="single-upload-input-from mb-3"><label class="form-label">{{ __('Postavi sliku') }}</label><input type="file" name="info_new_image_template[]" class="form-control info-new-image-template"></div></div>
        <div class="col-lg-12"><div class="single-upload-input-from mb-3"><label class="form-label">{{ __('Detalji') }}</label><textarea name="info[details][]" class="form-control" placeholder="{{ __('Dodatni detalji (opciono)') }}" cols="30" rows="3"></textarea></div></div>
        <div class="col-md-12 d-flex justify-content-end"><button type="button" class="btn theme-btn-red btn-sm removeInfo" title="{{ __('Ukloni stavku') }}"><i class="far fa-trash-alt"></i></button></div>
    </div>
</div>
@endsection

{{-- JEDAN @push('style') blok --}}
@push('style')
    <link rel="stylesheet" href="{{ asset('assets/properties/css/properties.css') }}">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/>
    <style>
        #map { width: 100%; height: 300px; border-radius: 6px; border: 1px solid #dee2e6; }
        .single-upload-from-property { border: 1px solid #e9ecef; padding: 20px; border-radius: 10px; background-color: #f8f9fa; }
        .single-input-title { margin-bottom: 1.5rem; border-bottom: 1px solid #dee2e6; padding-bottom: 0.5rem; font-size: 1.1rem; font-weight: 500; }
        .amenities-upload-input .form-check-inline { min-width: 150px; margin-right: 1rem; }
        .nearby-item { background-color: #fff; position: relative; }
        .removeInfo { cursor: pointer; }
        .theme-border { border: 1px solid #dee2e6; }
        .bg-off-white { background-color: #f8f9faff; }
        .radius-4 { border-radius: 0.25rem; }
        .radius-20 { border-radius: 1.25rem; }
        .p-20 { padding: 20px; }
        .p-30 { padding: 30px; }
        .mb-20 { margin-bottom: 20px; }
        .select2-container--bootstrap-5 .select2-selection--single { height: calc(1.5em + .75rem + 2px) !important; padding: .375rem .75rem !important; }
        .select2-container--bootstrap-5 .select2-selection--single .select2-selection__rendered { line-height: 1.5 !important; }
        .select2-container--bootstrap-5 .select2-selection--single .select2-selection__arrow { height: calc(1.5em + .75rem) !important; }
    </style>
@endpush

{{-- JEDAN @push('script') blok --}}
@push('script')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
    <script>
        // Funkcije i globalne promenljive koje koriste obe forme/listeneri
        function toggleButtonSpinner(buttonElement, show) {
            const spinner = buttonElement.querySelector('.spinner-border');
            if (spinner) {
                if (show) {
                    spinner.classList.remove('d-none');
                    buttonElement.disabled = true;
                } else {
                    spinner.classList.add('d-none');
                    buttonElement.disabled = false;
                }
            }
        }

        window.handlePropertyCreateResponse = function(response) {
            const propertyCreateForm = document.getElementById('propertyCreateForm');
            const savePropertyButton = document.getElementById('savePropertyButton');
            toggleButtonSpinner(savePropertyButton, false);

            propertyCreateForm.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
            propertyCreateForm.querySelectorAll('.invalid-feedback').forEach(el => el.remove());

            if (response.status === true || response.success === true) {
                if (typeof toastr !== 'undefined') toastr.success(response.message || "{{ __('Nekretnina uspešno sačuvana!') }}");
                else alert(response.message || "{{ __('Nekretnina uspešno sačuvana!') }}");

                const propertyId = response.data?.property?.id || response.data?.id || response.property_id || response.data?.property_id;
                const propertyName = response.data?.property?.name || document.getElementById('own_property_name').value;

                if (propertyId) {
                    document.getElementById('listing_property_id').value = propertyId;
                    if(document.getElementById('createdPropertyName')) document.getElementById('createdPropertyName').textContent = `"${propertyName}" (ID: ${propertyId})`;
                    document.getElementById('propertyCreateSection').style.display = 'none';
                    document.getElementById('listingCreateSection').style.display = 'block';
                    if (window.initializeLeafletMap) window.initializeLeafletMap();
                } else {
                    console.error('Backend nije vratio ID nekretnine.', response);
                    if (typeof toastr !== 'undefined') toastr.error("Greška: ID nekretnine nije dobijen od servera.");
                    else alert("Greška: ID nekretnine nije dobijen od servera.");
                }
            } else {
                if (typeof toastr !== 'undefined') toastr.error(response.message || "{{ __('Greška prilikom čuvanja nekretnine.') }}");
                else alert(response.message || "{{ __('Greška prilikom čuvanja nekretnine.') }}");
                if (response.errors) {
                    for (const field in response.errors) {
                        const inputField = propertyCreateForm.querySelector(`[name="${field}"]`);
                        if (inputField) {
                            inputField.classList.add('is-invalid');
                            const errorDiv = document.createElement('div');
                            errorDiv.classList.add('invalid-feedback'); errorDiv.style.display = 'block';
                            errorDiv.textContent = response.errors[field][0];
                            inputField.parentNode.appendChild(errorDiv);
                        }
                    }
                }
            }
        };

        window.getShowListingMessage = function(response) {
            const listingCreateForm = document.getElementById('listingCreateForm');
            const saveListingButton = document.getElementById('saveListingButton');
            toggleButtonSpinner(saveListingButton, false);

            listingCreateForm.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
            listingCreateForm.querySelectorAll('.invalid-feedback').forEach(el => el.remove());

            if (response.status === true || response.success === true) {
                if (typeof toastr !== 'undefined') toastr.success(response.message || "{{ __('Oglas uspešno sačuvan!') }}");
                else alert(response.message || "{{ __('Oglas uspešno sačuvan!') }}");

                const listingIndexRoute = document.getElementById('listingIndexRoute');
                if (response.data?.listing_show_route) window.location.href = response.data.listing_show_route;
                else if (listingIndexRoute && listingIndexRoute.value) window.location.href = listingIndexRoute.value;
                else { // Fallback - reset forme ako nema preusmeravanja
                    listingCreateForm.querySelectorAll('input[type="text"]:not([name="property_id"]), input[type="number"]:not([name="property_id"]), input[type="file"], textarea').forEach(input => input.value = '');
                    listingCreateForm.querySelectorAll('input[type="checkbox"]').forEach(checkbox => checkbox.checked = false);
                    const statusSelect = document.getElementById('status');
                    if (statusSelect) statusSelect.value = '1';
                    const infoItemsContainer = document.getElementById('infoItems');
                    if (infoItemsContainer) {
                        const nearbyItems = infoItemsContainer.querySelectorAll('.nearby-item');
                        nearbyItems.forEach((item, index) => { if (index > 0) item.remove(); });
                        if (nearbyItems.length > 0) {
                            const firstItemInputs = nearbyItems[0].querySelectorAll('input[type="text"]:not([name^="info[id]"]), input[type="file"], textarea');
                            firstItemInputs.forEach(input => input.value = '');
                            if (nearbyItems[0].querySelector('input[type="file"]')) nearbyItems[0].querySelector('input[type="file"]').value = null;
                            if (nearbyItems[0].querySelector('input[name="info[id][]"]')) nearbyItems[0].querySelector('input[name="info[id][]"]').value = '';
                        }
                    }
                    if (window.toggleRemoveButtons) window.toggleRemoveButtons();
                    if (window.resetLeafletMapToDefault) window.resetLeafletMapToDefault(document.getElementById('listing_property_id').value);
                }
            } else {
                if (typeof toastr !== 'undefined') toastr.error(response.message || "{{ __('Greška prilikom čuvanja oglasa.') }}");
                else alert(response.message || "{{ __('Greška prilikom čuvanja oglasa.') }}");
                if (response.errors) {
                    for (const field in response.errors) {
                        const errorMessages = response.errors[field];
                        let inputField;
                        if (field.startsWith('info.')) {
                            const parts = field.split('.');
                            const baseName = parts[0]; let index, actualField;
                            if (parts[1] === 'image') { index = parseInt(parts[2], 10); actualField = 'image'; }
                            else { index = parseInt(parts[1], 10); actualField = parts[2]; }
                            const infoItemDivs = document.querySelectorAll(`#infoItems .nearby-item`);
                            if (infoItemDivs[index]) {
                                if (actualField === 'image') inputField = infoItemDivs[index].querySelector(`input[name="info[image][${index}]"]`);
                                else inputField = infoItemDivs[index].querySelector(`[name="info[${actualField}][]"]`);
                            }
                        } else inputField = listingCreateForm.querySelector(`[name="${field}"], [name="${field}[]"]`);
                        if (inputField) {
                            inputField.classList.add('is-invalid');
                            const errorDiv = document.createElement('div');
                            errorDiv.classList.add('invalid-feedback'); errorDiv.style.display = 'block';
                            errorDiv.textContent = errorMessages[0];
                            let parentNode = inputField.parentNode;
                            if (parentNode.classList.contains('single-upload-input-from') || parentNode.classList.contains('form-check') || parentNode.classList.contains('single-interior')) parentNode.appendChild(errorDiv);
                            else if (inputField.nextSibling) parentNode.insertBefore(errorDiv, inputField.nextSibling);
                            else parentNode.appendChild(errorDiv);
                        } else console.warn(`Polje za grešku "${field}" nije pronađeno u DOM-u za listing formu.`);
                    }
                }
            }
        };

        document.addEventListener('DOMContentLoaded', function() {
            const addInfoButton = document.getElementById('addInfo');
            const infoItemsContainer = document.getElementById('infoItems');
            const nearbyInfoTemplate = document.getElementById('nearbyInfoTemplate');

            let phpInfoDataFromBlade = @json($infoDataForLoop);
            let infoItemCounter = Math.max(1, phpInfoDataFromBlade.length);

            window.toggleRemoveButtons = () => {
                const items = infoItemsContainer.querySelectorAll('.nearby-item');
                items.forEach((item) => {
                    const removeBtn = item.querySelector('.removeInfo');
                    if (removeBtn) removeBtn.style.display = items.length === 1 ? 'none' : 'inline-block';
                });
            };

            if (addInfoButton && infoItemsContainer && nearbyInfoTemplate) {
                addInfoButton.addEventListener('click', function() {
                    const newItemHtml = nearbyInfoTemplate.innerHTML;
                    const newItemWrapper = document.createElement('div');
                    newItemWrapper.innerHTML = newItemHtml;
                    const actualItem = newItemWrapper.firstElementChild;
                    const fileInput = actualItem.querySelector('input[type="file"].info-new-image-template');
                    if (fileInput) { fileInput.name = `info[image][${infoItemCounter}]`; fileInput.classList.remove('info-new-image-template');}
                    const idInput = actualItem.querySelector('input[name="info[id][]"]');
                    if(idInput) idInput.value = '';
                    infoItemsContainer.appendChild(actualItem);
                    infoItemCounter++;
                    toggleRemoveButtons();
                });
            }
            if (infoItemsContainer) {
                infoItemsContainer.addEventListener('click', function(event) {
                    const removeButton = event.target.closest('.removeInfo');
                    if (removeButton) {
                        const itemToRemove = removeButton.closest('.nearby-item');
                        if (itemToRemove && infoItemsContainer.querySelectorAll('.nearby-item').length > 1) itemToRemove.remove();
                        else if (itemToRemove) {
                            const inputs = itemToRemove.querySelectorAll('input[type="text"]:not([name^="info[id]"]), input[type="file"], textarea');
                            inputs.forEach(input => input.value = '');
                            if (itemToRemove.querySelector('input[type="file"]')) itemToRemove.querySelector('input[type="file"]').value = null;
                            if (itemToRemove.querySelector('input[name="info[id][]"]')) itemToRemove.querySelector('input[name="info[id][]"]').value = '';
                        }
                        toggleRemoveButtons();
                    }
                });
            }
            if(infoItemsContainer && infoItemsContainer.children.length > 0) { // Osiguraj da se pozove samo ako ima itema
                 toggleRemoveButtons();
            }


            window.leafletMapInstance = null;
            window.leafletMarkerInstance = null;
            window.initializeLeafletMap = function(lat = null, lng = null) {
                if (window.leafletMapInstance) {
                    const newLat = lat || 44.7866; const newLng = lng || 20.4489;
                    window.leafletMarkerInstance.setLatLng([newLat, newLng]);
                    window.leafletMapInstance.setView([newLat, newLng], (lat && lng) ? 13 : 7);
                    return;
                }
                const latInput = document.getElementById('latitude'); const lngInput = document.getElementById('longitude');
                const defaultLat = lat || (latInput && latInput.value ? parseFloat(latInput.value) : 44.7866);
                const defaultLng = lng || (lngInput && lngInput.value ? parseFloat(lngInput.value) : 20.4489);
                const initialZoom = (latInput && latInput.value && lngInput && lngInput.value && parseFloat(latInput.value) !== 0 && parseFloat(lngInput.value) !== 0) ? 13 : 7;
                const mapDiv = document.getElementById('map');
                if(!mapDiv) { console.error("Map div not found"); return; }
                window.leafletMapInstance = L.map(mapDiv).setView([defaultLat, defaultLng], initialZoom);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(window.leafletMapInstance);
                window.leafletMarkerInstance = L.marker([defaultLat, defaultLng], { draggable: true }).addTo(window.leafletMapInstance);
                window.leafletMarkerInstance.on('dragend', function (e) {
                    const position = window.leafletMarkerInstance.getLatLng();
                    if (latInput) latInput.value = position.lat.toFixed(6); if (lngInput) lngInput.value = position.lng.toFixed(6);
                });
                window.leafletMapInstance.on('click', function (e) {
                    window.leafletMarkerInstance.setLatLng(e.latlng);
                    if (latInput) latInput.value = e.latlng.lat.toFixed(6); if (lngInput) lngInput.value = e.latlng.lng.toFixed(6);
                });
                if (latInput) latInput.addEventListener('input', function() { updateMapFromInputs(window.leafletMapInstance, window.leafletMarkerInstance, latInput, lngInput); });
                if (lngInput) lngInput.addEventListener('input', function() { updateMapFromInputs(window.leafletMapInstance, window.leafletMarkerInstance, latInput, lngInput); });
            };
            window.updateMapFromInputs = function(map, marker, latIn, lngIn) {
                const latVal = latIn ? parseFloat(latIn.value) : NaN; const lngVal = lngIn ? parseFloat(lngIn.value) : NaN;
                if (!isNaN(latVal) && !isNaN(lngVal) && map && marker) {
                    const newLatLng = L.latLng(latVal, lngVal); marker.setLatLng(newLatLng);
                    map.setView(newLatLng, map.getZoom() < 10 ? 13 : map.getZoom());
                }
            }
            window.resetLeafletMapToDefault = function(currentPropertyId = null) {
                const latInput = document.getElementById('latitude'); const lngInput = document.getElementById('longitude');
                if (latInput) latInput.value = ''; if (lngInput) lngInput.value = '';
                if (window.leafletMapInstance && window.leafletMarkerInstance) {
                    window.leafletMarkerInstance.setLatLng([44.7866, 20.4489]);
                    window.leafletMapInstance.setView([44.7866, 20.4489], 7);
                }
            };

            // Uklanjanje grešaka validacije na unos/promenu
            const formsForValidation = [document.getElementById('propertyCreateForm'), document.getElementById('listingCreateForm')];
            formsForValidation.forEach(form => {
                if (form) {
                    const handleInputChange = function(event){
                        if(event.target.classList.contains('is-invalid')){
                            event.target.classList.remove('is-invalid');
                            let parent = event.target.parentNode;
                            if(parent.classList.contains('input-group') || parent.closest('.input-group')) {
                                parent = parent.closest('.single-upload-input-from') || parent.closest('.form-check') || parent;
                            }
                            const errorFeedback = parent.querySelector('.invalid-feedback');
                            if(errorFeedback) errorFeedback.remove();
                        }
                    };
                    form.addEventListener('input', handleInputChange);
                    form.addEventListener('change', handleInputChange);
                }
            });


            // Vezivanje SUBMIT listenera direktno na forme po ID-ju
            const propertyCreateFormEl = document.getElementById('propertyCreateForm');
            if (propertyCreateFormEl) {
                propertyCreateFormEl.addEventListener('submit', function(e){
                    e.preventDefault();
                    toggleButtonSpinner(document.getElementById('savePropertyButton'), true);
                    const formData = new FormData(this);
                    fetch(this.action, { method: 'POST', body: formData, headers: {'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '', 'Accept': 'application/json'} })
                        .then(response => response.json())
                        .then(data => window.handlePropertyCreateResponse(data))
                        .catch(error => {
                            console.error('Fetch error (Property Create):', error);
                            toggleButtonSpinner(document.getElementById('savePropertyButton'), false);
                            if (typeof toastr !== 'undefined') toastr.error("Došlo je do mrežne greške prilikom čuvanja nekretnine."); else alert("Došlo je do mrežne greške prilikom čuvanja nekretnine.");
                        });
                });
            }

            const listingCreateFormEl = document.getElementById('listingCreateForm');
            if (listingCreateFormEl) {
                listingCreateFormEl.addEventListener('submit', function(e){
                    e.preventDefault();
                    toggleButtonSpinner(document.getElementById('saveListingButton'), true);
                    const formData = new FormData(this);
                    fetch(this.action, { method: 'POST', body: formData, headers: {'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '', 'Accept': 'application/json'} })
                        .then(response => response.json())
                        .then(data => window.getShowListingMessage(data))
                        .catch(error => {
                            console.error('Fetch error (Listing Create):', error);
                            toggleButtonSpinner(document.getElementById('saveListingButton'), false);
                            if (typeof toastr !== 'undefined') toastr.error("Došlo je do mrežne greške prilikom čuvanja oglasa."); else alert("Došlo je do mrežne greške prilikom čuvanja oglasa.");
                        });
                });
            }
        });
    </script>
@endpush