{{-- resources/views/owner/property/all-property-list.blade.php --}}

@extends('owner.layouts.app')

@section('content')
<div class="main-content">
  <div class="page-content">
    <div class="container-fluid">
      {{-- Naslov i breadcrumb --}}
      <div class="row mb-4">
        <div class="col-12">
          <div class="page-title-box d-sm-flex align-items-center justify-content-between">
            <h4 class="mb-sm-0">{{ __('Sve nekretnine') }}</h4>
            <div class="page-title-right">
              <ol class="breadcrumb m-0">
                <li class="breadcrumb-item"><a href="{{ route('owner.dashboard') }}">{{ __('Kontrolna tabla') }}</a></li>
                <li class="breadcrumb-item active">{{ __('Sve nekretnine') }}</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      {{-- Dugme za dodavanje nove nekretnine --}}
      <div class="row mb-3">
        <div class="col-12">
          {{-- Pretpostavljam da je ruta za dodavanje 'owner.property.create' na osnovu konvencije iz vašeg fajla sa rutama --}}
          <a href="{{ route('owner.property.create') }}" class="btn btn-primary">
            <i class="ri-add-line me-1"></i> {{ __('Dodaj novu nekretninu') }}
          </a>
        </div>
      </div>

      {{-- Tabela nekretnina --}}
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <table id="allPropertyTable" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>{{ __('Naziv') }}</th>
                    <th>{{ __('Adresa') }}</th>
                    <th class="text-center">{{ __('Broj oglasa') }}</th>
                    <th class="text-center">{{ __('Oglasi') }}</th>
                    <th class="text-center">{{ __('Akcije') }}</th>
                  </tr>
                </thead>
                <tbody>
                  @forelse($properties as $property) {{-- Korišćenje @forelse za slučaj da nema nekretnina --}}
                    <tr>
                      <td>{{ $property->name }}</td>
                      <td>{{ $property->propertyDetail?->address ?? ($property->address ?? '-') }}</td> {{-- Dodao sam fallback ako adresa nije u propertyDetail --}}
                      <td class="text-center">
                        {{-- Ovo može biti optimizovano ako se broj oglasa učitava sa relacijom (eager loading) --}}
                        {{ $property->listings_count ?? \App\Models\Listing::where('property_id', $property->id)->count() }}
                      </td>
                      <td class="text-center">
                        {{-- Prikaži oglase za ovu nekretninu (link ka property show stranici) --}}
                        <a href="{{ route('owner.property.show', $property->id) }}"
                           class="btn btn-sm btn-info me-1" title="{{ __('Prikaži detalje i oglase nekretnine') }}">
                          {{ __('Detalji') }}
                        </a>
                        {{-- Dodaj oglas vezan za ovu nekretninu --}}
                        <a href="{{ route('owner.listing.create', ['property_id' => $property->id]) }}"
                           class="btn btn-sm btn-success me-1" title="{{ __('Dodaj novi oglas za ovu nekretninu') }}">
                          <i class="ri-add-line"></i> {{ __('Oglas') }}
                        </a>
                        {{-- Dugme "Dodaj oglas bez nekretnine" je možda bolje na vrhu stranice sa oglasima, a ne za svaki property red --}}
                        {{-- Ako ostaje: --}}
                        {{-- <a href="{{ route('owner.listing.create') }}"
                           class="btn btn-sm btn-warning" title="{{ __('Dodaj oglas koji nije vezan ni za jednu nekretninu') }}">
                          {{ __('Nezavisni oglas') }}
                        </a> --}}
                      </td>
                      <td class="text-center">
                        <a href="{{ route('owner.property.edit', $property->id) }}"
                           class="btn btn-sm btn-primary me-1" title="{{ __('Uredi ovu nekretninu') }}">
                          {{ __('Uredi') }}
                        </a>
                        {{-- ISPRAVLJEN POZIV RUTE OVDE --}}
                        <button onclick="deleteItem('{{ route('owner.property.destroy', $property->id) }}', 'allPropertyTable')"
                                class="btn btn-sm btn-danger" title="{{ __('Obriši ovu nekretninu') }}">
                          {{ __('Obriši') }}
                        </button>
                      </td>
                    </tr>
                  @empty
                    <tr>
                        <td colspan="5" class="text-center">{{ __('Nema dostupnih nekretnina.') }}</td>
                    </tr>
                  @endforelse
                </tbody>
              </table>
            </div> <!-- end card-body -->
          </div> <!-- end card -->
        </div> <!-- end col -->
      </div> <!-- end row -->
    </div> <!-- end container-fluid -->
  </div> <!-- end page-content -->
</div> <!-- end main-content -->

{{-- Pretpostavljam da imate deleteItem JavaScript funkciju definisanu negde globalno ili je uključujete --}}
{{-- Ako nije, evo osnovnog primera koji bi trebalo prilagoditi vašem AJAX handler-u za brisanje --}}
@push('script')
  <script>
    // Osnovna inicijalizacija DataTables ako je koristite
    $(function() {
      if ($.fn.DataTable) {
        $('#allPropertyTable').DataTable({
            // Ovde možete dodati konfiguraciju za DataTable ako je potrebno
            // npr. "language": { "url": "//cdn.datatables.net/plug-ins/1.10.25/i18n/Serbian.json" }
        });
      }
    });

    // Primer deleteItem funkcije - PRILAGODITE OVO VAŠEM SISTEMU
    // Ova funkcija bi trebalo da šalje DELETE AJAX zahtev
    function deleteItem(url, tableId) {
      if (confirm("{{ __('Da li ste sigurni da želite da obrišete ovu stavku?') }}")) {
        $.ajax({
          url: url,
          type: 'POST', // Koristi POST za slanje _method
          data: {
            _method: 'DELETE',
            _token: "{{ csrf_token() }}" // CSRF token je neophodan
          },
          success: function(response) {
            if (response.success) {
              alert(response.message || "{{ __('Stavka uspešno obrisana.') }}");
              // Ponovno učitavanje DataTables ili cele stranice
              if (typeof $('#' + tableId).DataTable() !== 'undefined' && $.fn.DataTable.isDataTable('#' + tableId)) {
                $('#' + tableId).DataTable().ajax.reload(); // Ako koristite server-side DataTables
              } else {
                window.location.reload(); // Jednostavni refresh stranice
              }
            } else {
              alert(response.message || "{{ __('Došlo je do greške prilikom brisanja.') }}");
            }
          },
          error: function(xhr) {
            // Bolje rukovanje greškama
            let errorMessage = "{{ __('Došlo je do greške na serveru.') }}";
            if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMessage = xhr.responseJSON.message;
            } else if (xhr.responseText) {
                try {
                    let err = JSON.parse(xhr.responseText);
                    if (err.message) errorMessage = err.message;
                } catch (e) { /* Zanemari grešku parsiranja */ }
            }
            alert(errorMessage + ' (Status: ' + xhr.status + ')');
          }
        });
      }
    }
  </script>
@endpush
@endsection