{{-- resources/views/owner/property/partial/render-property-information.blade.php --}}
<form class="ajax"
      action="{{ route('owner.property.property-information.store') }}"
      method="post"
      data-handler="stepChangeProperty">
    @csrf

    <input type="hidden"
           name="property_id"
           id="ajax_property_id"
           value="{{ $property->id ?? '' }}">

    {{-- Dodajemo i property_type kao hidden ako se ne menja u ovom koraku, a potreban je za store metodu --}}
    {{-- Ili ga prikazujemo kao select ako se može menjati --}}
    {{-- Ako je `property_type` bio deo forme `add.blade.php` (kao što jeste bio), onda ga treba slati i odavde --}}
    {{-- da bi `propertyInformationStore` metoda u servisu znala koji set inputa da očekuje (own_ vs lease_) --}}
    {{-- ako ta logika i dalje postoji u servisu. Ako je servis sada pojednostavljen da uvek koristi 'name', 'description' itd., --}}
    {{-- onda ovo možda nije presudno ali je dobro imati ga. --}}
    <input type="hidden" name="property_type" value="{{ old('property_type', $property->property_type ?? (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1)) }}">


    <div class="form-card add-property-box bg-off-white theme-border radius-4 p-20 mb-20">
        <h4 class="mb-3">{{ __('Informacije o Nekretnini') }}</h4>
        <div class="row">
            {{-- Naziv nekretnine --}}
            <div class="col-md-6 mb-3">
                <label class="form-label" for="property_info_name_edit">{{ __('Naziv nekretnine') }} <span class="text-danger">*</span></label>
                <input type="text"
                       id="property_info_name_edit"
                       {{-- Ovo je ključno: ime inputa mora odgovarati onome što store metoda očekuje KADA JE property_type poznat --}}
                       {{-- Ako propertyInformationStore i dalje proverava $request->property_type za $request->own_property_name vs $request->lease_property_name --}}
                       {{-- onda ovde moramo poslati ili 'own_property_name' ili 'lease_property_name' u zavisnosti od $property->property_type --}}
                       {{-- ILI, bolje, propertyInformationStore treba da bude agnosticna po pitanju 'own_'/'lease_' prefiksa kada je property_id prisutan (edit mode) --}}
                       {{-- i da uvek čita 'name', 'description', 'number_of_unit' --}}
                       name="{{ ($property->property_type ?? (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1)) == (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1) ? 'own_property_name' : 'lease_property_name' }}"
                       class="form-control"
                       placeholder="{{ __('Unesite naziv nekretnine') }}"
                       value="{{ old(($property->property_type ?? (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1)) == (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1) ? 'own_property_name' : 'lease_property_name', $property->name ?? '') }}"
                       required>
                {{-- Alternativa ako propertyInformationStore UVEK očekuje 'name' za edit: --}}
                {{-- name="name" --}}
                {{-- value="{{ old('name', $property->name ?? '') }}" --}}
            </div>

            {{-- Vlasnik (Rent User) --}}
            <div class="col-md-6 mb-3">
                <label class="form-label" for="property_info_rent_user_id_edit">{{ __('Vlasnik nekretnine') }} <span class="text-danger">*</span></label>
                <select name="rent_user_id" id="property_info_rent_user_id_edit" class="form-select select2" required>
                    <option value="">{{ __('-- Izaberite vlasnika --') }}</option>
                    @if(isset($rentUsers) && $rentUsers->count() > 0)
                        @foreach($rentUsers as $user)
                            <option value="{{ $user->id }}"
                              {{ old('rent_user_id', $property->rent_user_id ?? '') == $user->id ? 'selected' : '' }}>
                              {{ $user->first_name }} {{ $user->last_name }} {{ $user->contact_number ? '(' . $user->contact_number . ')' : '' }}
                            </option>
                        @endforeach
                    @else
                         <option value="" disabled>{{ __('Nema dostupnih vlasnika. Molimo dodajte prvo vlasnika.') }}</option>
                    @endif
                </select>
            </div>

            {{-- Tip Nekretnine (ako se može menjati u ovom koraku) --}}
            {{-- Ako se ne menja, može biti samo prikaz ili hidden input ako je potrebno za logiku --}}
            <div class="col-md-6 mb-3">
                <label class="form-label" for="property_info_type_edit">{{ __('Tip nekretnine') }} <span class="text-danger">*</span></label>
                <select name="property_type" id="property_info_type_edit" class="form-select" required>
                    @if(defined('PROPERTY_TYPE_OWN') && defined('PROPERTY_TYPE_LEASE'))
                        <option value="{{ PROPERTY_TYPE_OWN }}" {{ old('property_type', $property->property_type ?? '') == PROPERTY_TYPE_OWN ? 'selected' : '' }}>
                            {{ __('Sopstvena nekretnina') }}
                        </option>
                        <option value="{{ PROPERTY_TYPE_LEASE }}" {{ old('property_type', $property->property_type ?? '') == PROPERTY_TYPE_LEASE ? 'selected' : '' }}>
                            {{ __('Nekretnina u zakupu') }}
                        </option>
                    @else
                        <option value="1" {{ old('property_type', $property->property_type ?? '') == 1 ? 'selected' : '' }}>{{ __('Tip 1 (Sopstvena)') }}</option>
                        <option value="2" {{ old('property_type', $property->property_type ?? '') == 2 ? 'selected' : '' }}>{{ __('Tip 2 (Zakup)') }}</option>
                    @endif
                </select>
            </div>

            {{-- Broj Jedinica --}}
            <div class="col-md-6 mb-3">
                <label class="form-label" for="property_info_number_of_unit_edit">{{ __('Broj jedinica') }} <span class="text-danger">*</span></label>
                <input type="number"
                       id="property_info_number_of_unit_edit"
                        {{-- Slično kao za naziv, ime inputa treba da odgovara onome što store metoda očekuje --}}
                       name="{{ ($property->property_type ?? (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1)) == (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1) ? 'own_number_of_unit' : 'lease_number_of_unit' }}"
                       class="form-control"
                       placeholder="{{ __('Unesite broj jedinica') }}"
                       value="{{ old(($property->property_type ?? (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1)) == (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1) ? 'own_number_of_unit' : 'lease_number_of_unit', $property->number_of_unit ?? 1) }}"
                       min="1"
                       required>
                {{-- Alternativa ako propertyInformationStore UVEK očekuje 'number_of_unit' za edit: --}}
                {{-- name="number_of_unit" --}}
                {{-- value="{{ old('number_of_unit', $property->number_of_unit ?? 1) }}" --}}
            </div>

            {{-- Opis Nekretnine --}}
            <div class="col-md-12 mb-3">
                <label class="form-label" for="property_info_description_edit">{{ __('Opis nekretnine') }}</label>
                <textarea {{-- Slično kao za naziv, ime textarea treba da odgovara onome što store metoda očekuje --}}
                          name="{{ ($property->property_type ?? (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1)) == (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1) ? 'own_description' : 'lease_description' }}"
                          id="property_info_description_edit"
                          class="form-control"
                          rows="4"
                          placeholder="{{ __('Unesite detaljan opis nekretnine...') }}">{{ old(($property->property_type ?? (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1)) == (defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1) ? 'own_description' : 'lease_description', $property->description ?? '') }}</textarea>
                {{-- Alternativa ako propertyInformationStore UVEK očekuje 'description' za edit: --}}
                {{-- name="description" --}}
                {{-- {{ old('description', $property->description ?? '') }} --}}
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-end">
        <button type="submit" class="btn theme-btn">
            <span class="spinner-border spinner-border-sm me-2 d-none" role="status" aria-hidden="true"></span>
            {{-- Tekst dugmeta može zavisiti od toga da li je add ili edit (iako je ovo partial za edit) --}}
            {{ __('Ažuriraj i idi na Lokaciju') }}
        </button>
    </div>
</form>

@pushOnce('script') {{-- Koristimo @pushOnce da se skripta doda samo jednom čak i ako se partial renderuje više puta --}}
<script>
    $(document).ready(function() {
        if (jQuery().select2 && $('.select2').length) { // Provera da li select2 postoji na stranici
            $('.select2').each(function() {
                $(this).select2({
                    theme: 'bootstrap-5',
                    placeholder: $(this).attr('placeholder') || "{{ __('-- Izaberite --') }}",
                    allowClear: true,
                    dropdownParent: $(this).closest('.form-card') // Bolje za modale ili kompleksnije layout-e
                });
            });
        }

        // Event listener za promenu property_type ako utiče na imena drugih polja
        const propertyTypeSelect = document.getElementById('property_info_type_edit');
        const propertyNameInput = document.getElementById('property_info_name_edit');
        const propertyUnitsInput = document.getElementById('property_info_number_of_unit_edit');
        const propertyDescriptionTextarea = document.getElementById('property_info_description_edit');

        function updateFieldNames(selectedType) {
            const isOwnType = selectedType == "{{ defined('PROPERTY_TYPE_OWN') ? PROPERTY_TYPE_OWN : 1 }}"; // Proverite vrednost za OWN

            if (propertyNameInput) {
                propertyNameInput.name = isOwnType ? 'own_property_name' : 'lease_property_name';
            }
            if (propertyUnitsInput) {
                propertyUnitsInput.name = isOwnType ? 'own_number_of_unit' : 'lease_number_of_unit';
            }
            if (propertyDescriptionTextarea) {
                propertyDescriptionTextarea.name = isOwnType ? 'own_description' : 'lease_description';
            }
        }

        if (propertyTypeSelect) {
            // Inicijalno postavljanje imena polja na osnovu trenutnog tipa
            updateFieldNames(propertyTypeSelect.value);

            propertyTypeSelect.addEventListener('change', function() {
                updateFieldNames(this.value);
            });
        }
    });
</script>
@endPushOnce