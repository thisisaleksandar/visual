{{-- resources/views/owner/property/partial/render-unit.blade.php --}}
@extends('owner.layouts.app')

@section('content')
    <div class="main-content">
        <div class="page-content">
            <div class="upload-property">
                <div class="container-fluid">
                    <div class="page-content-wrapper bg-white p-30 radius-20">
                        <div class="row">
                            <div class="col-12">
                                <div
                                    class="page-title-box d-sm-flex align-items-center justify-content-between border-bottom mb-20">
                                    <div class="page-title-left">
                                        <h3 class="mb-sm-0">{{ $pageTitle }}</h3>
                                    </div>
                                    <div class="page-title-right">
                                        <ol class="breadcrumb mb-0">
                                            <li class="breadcrumb-item">
                                                <a href="{{ route('owner.dashboard') }}"
                                                   title="{{ __('Kontrolna tabla') }}">{{ __('Kontrolna tabla') }}</a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">{{ __('Moji oglasi') }}</li>
                                            <li class="breadcrumb-item active" aria-current="page">{{ $pageTitle }}</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <form class="ajax"
                                      action="{{ route('owner.listing.store') }}"
                                      method="POST"
                                      enctype="multipart/form-data"
                                      data-handler="getShowListingMessage">
                                    @csrf

                                    {{-- Sva polja za Listing --}}
                                    <div class="upload-from-area">
                                        <div class="row">
                                            {{-- Informacije o nekretnini --}}
                                            <div class="col-lg-12">
                                                <div class="single-upload-from-property mb-3">
                                                    <h5 class="single-input-title">
                                                        {{ __('Informacije o nekretnini') }}
                                                    </h5>
                                                    <div class="row">
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="name" class="form-label">
                                                                {{ __('Naziv') }} <span class="text-danger">*</span>
                                                            </label>
                                                            <input type="text" class="form-control"
                                                                   name="name"
                                                                   id="name"
                                                                   placeholder="{{ __('Naziv') }}"
                                                                   value="{{ old('name') }}"
                                                                   required>
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="price" class="form-label">
                                                                {{ __('Cena po danu') }} <span class="text-danger">*</span>
                                                            </label>
                                                            <input type="number" step="any" class="form-control"
                                                                   name="price"
                                                                   id="price"
                                                                   placeholder="{{ __('Unesite cenu') }}"
                                                                   value="{{ old('price') }}"
                                                                   required>
                                                            <input type="hidden" name="price_duration_type" value="daily">
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="status" class="form-label">
                                                                {{ __('Status') }} <span class="text-danger">*</span>
                                                            </label>
                                                            <select name="status" id="status" class="form-select" required>
                                                                <option value="1" {{ old('status',1)==1?'selected':'' }}>
                                                                    {{ __('Aktivan') }}
                                                                </option>
                                                                <option value="2" {{ old('status')==2?'selected':'' }}>
                                                                    {{ __('Deaktiviran') }}
                                                                </option>
                                                                <option value="3" {{ old('status')==3?'selected':'' }}>
                                                                    {{ __('Izdat') }}
                                                                </option>
                                                            </select>
                                                        </div>
                                                        <div class="col-lg-6 mb-3 d-flex align-items-center">
                                                            <div class="form-check mt-2">
                                                                <input class="form-check-input" type="checkbox"
                                                                       name="is_instant"
                                                                       id="is_instant"
                                                                       value="1"
                                                                       {{ old('is_instant')==1?'checked':'' }}>
                                                                <label class="form-check-label" for="is_instant">
                                                                    {{ __('Dostupno odmah') }}
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="city" class="form-label">
                                                                {{ __('Grad') }}
                                                            </label>
                                                            <input type="text" class="form-control"
                                                                   name="city"
                                                                   id="city"
                                                                   placeholder="{{ __('Grad') }}"
                                                                   value="{{ old('city') }}">
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="zip_code" class="form-label">
                                                                {{ __('Poštanski broj') }}
                                                            </label>
                                                            <input type="text" class="form-control"
                                                                   name="zip_code"
                                                                   id="zip_code"
                                                                   placeholder="{{ __('Poštanski broj') }}"
                                                                   value="{{ old('zip_code') }}">
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="address" class="form-label">
                                                                {{ __('Adresa') }}
                                                            </label>
                                                            <input type="text" class="form-control"
                                                                   name="address"
                                                                   id="address"
                                                                   placeholder="{{ __('Adresa') }}"
                                                                   value="{{ old('address') }}">
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="rent_user_id" class="form-label">
                                                                {{ __('Zakupodavac') }} <span class="text-danger">*</span>
                                                            </label>
                                                            <select name="rent_user_id"
                                                                    id="rent_user_id"
                                                                    class="form-select"
                                                                    required>
                                                                <option value="">
                                                                    {{ __('Izaberite zakupodavca') }}
                                                                </option>
                                                                @foreach($rentUsers as $u)
                                                                    <option value="{{ $u->id }}"
                                                                        {{ old('rent_user_id')==$u->id?'selected':'' }}>
                                                                        {{ $u->first_name }}
                                                                        {{ $u->last_name }}
                                                                        @if($u->contact_number)
                                                                            - {{ $u->contact_number }}
                                                                        @endif
                                                                    </option>
                                                                @endforeach
                                                            </select>
                                                            <small class="form-text text-muted">
                                                                {{ __('Izaberite zakupodavca kojem pripada oglas.') }}
                                                            </small>
                                                        </div>

                                                        {{-- Pripada property-ju --}}
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="property_id" class="form-label">
                                                                {{ __('Pripada property-ju') }}
                                                            </label>
                                                            <select name="property_id"
                                                                    id="property_id"
                                                                    class="form-select">
                                                                <option value="">{{ __('Bez dodeljivanja') }}</option>
                                                                @foreach($properties as $p)
                                                                    <option value="{{ $p->id }}"
                                                                        {{ old('property_id')==$p->id?'selected':'' }}>
                                                                        {{ $p->name }} (ID: {{ $p->id }})
                                                                    </option>
                                                                @endforeach
                                                            </select>
                                                            <small class="form-text text-muted">
                                                                {{ __('Ovaj oglas će se prikazivati i u okviru izabranog property-ja.') }}
                                                            </small>
                                                        </div>

                                                        {{-- Geolokacija & opis --}}
                                                        <div class="col-md-6 mb-3">
                                                            <label for="latitude" class="form-label">
                                                                {{ __('Latitude') }}
                                                            </label>
                                                            <input type="number" step="any" class="form-control"
                                                                   name="latitude"
                                                                   id="latitude"
                                                                   placeholder="{{ __('Latitude') }}"
                                                                   value="{{ old('latitude') }}">
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <label for="longitude" class="form-label">
                                                                {{ __('Longitude') }}
                                                            </label>
                                                            <input type="number" step="any" class="form-control"
                                                                   name="longitude"
                                                                   id="longitude"
                                                                   placeholder="{{ __('Longitude') }}"
                                                                   value="{{ old('longitude') }}">
                                                        </div>
                                                        <div class="col-md-12 mb-3">
                                                            <label class="form-label">
                                                                {{ __('Lokacija na mapi') }}
                                                            </label>
                                                            <div id="map" style="height:400px;border:1px solid #ccc;border-radius:6px;"></div>
                                                        </div>
                                                        <div class="col-lg-12 mb-3">
                                                            <label for="details" class="form-label">
                                                                {{ __('Detaljan opis nekretnine') }}
                                                            </label>
                                                            <textarea name="details"
                                                                      id="details"
                                                                      class="form-control"
                                                                      rows="6"
                                                                      placeholder="{{ __('Unesite detaljan opis...') }}">{{ old('details') }}</textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Specifikacija nekretnine --}}
                                            <div class="col-lg-12 mb-3">
                                                <div class="single-upload-from-property">
                                                    <h5 class="single-input-title">
                                                        {{ __('Specifikacija nekretnine') }}
                                                    </h5>
                                                    <div class="form-check mb-3">
                                                        <input class="form-check-input"
                                                               type="checkbox"
                                                               name="jacuzzi"
                                                               id="jacuzzi"
                                                               value="1"
                                                               {{ old('jacuzzi')?'checked':'' }}>
                                                        <label class="form-check-label" for="jacuzzi">
                                                            {{ __('Jacuzzi') }}
                                                        </label>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="bed_room" class="form-label">
                                                                {{ __('Broj spavaćih soba') }}
                                                            </label>
                                                            <input type="number" class="form-control"
                                                                   name="bed_room"
                                                                   id="bed_room"
                                                                   placeholder="{{ __('Npr. 2') }}"
                                                                   value="{{ old('bed_room') }}">
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="bath_room" class="form-label">
                                                                {{ __('Broj kupatila') }}
                                                            </label>
                                                            <input type="number" class="form-control"
                                                                   name="bath_room"
                                                                   id="bath_room"
                                                                   placeholder="{{ __('Npr. 1') }}"
                                                                   value="{{ old('bath_room') }}">
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="kitchen_room" class="form-label">
                                                                {{ __('Broj kuhinja') }}
                                                            </label>
                                                            <input type="number" class="form-control"
                                                                   name="kitchen_room"
                                                                   id="kitchen_room"
                                                                   placeholder="{{ __('Npr. 1') }}"
                                                                   value="{{ old('kitchen_room') }}">
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="dining_room" class="form-label">
                                                                {{ __('Broj trpezarija') }}
                                                            </label>
                                                            <input type="number" class="form-control"
                                                                   name="dining_room"
                                                                   id="dining_room"
                                                                   placeholder="{{ __('Npr. 1') }}"
                                                                   value="{{ old('dining_room') }}">
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="living_room" class="form-label">
                                                                {{ __('Broj dnevnih soba') }}
                                                            </label>
                                                            <input type="number" class="form-control"
                                                                   name="living_room"
                                                                   id="living_room"
                                                                   placeholder="{{ __('Npr. 1') }}"
                                                                   value="{{ old('living_room') }}">
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="storage_room" class="form-label">
                                                                {{ __('Broj ostava') }}
                                                            </label>
                                                            <input type="number" class="form-control"
                                                                   name="storage_room"
                                                                   id="storage_room"
                                                                   placeholder="{{ __('Npr. 0') }}"
                                                                   value="{{ old('storage_room') }}">
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="other_room" class="form-label">
                                                                {{ __('Ostale prostorije') }}
                                                            </label>
                                                            <input type="text" class="form-control"
                                                                   name="other_room"
                                                                   id="other_room"
                                                                   placeholder="{{ __('Npr. Terasa, Vešernica...') }}"
                                                                   value="{{ old('other_room') }}">
                                                            <small class="form-text text-muted">
                                                                {{ __('Odvojite zarezom ako ih je više.') }}
                                                            </small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Osnovni detalji (Enterijer, Tip, Slike) --}}
                                            <div class="col-lg-12 mb-3">
                                                <div class="single-upload-from-property">
                                                    <h5 class="single-input-title">
                                                        {{ __('Osnovni detalji o nekretnini') }}
                                                    </h5>
                                                    <div class="row">
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="interior" class="form-label">
                                                                {{ __('Kvadratura / Enterijer') }}
                                                            </label>
                                                            <input type="text" class="form-control"
                                                                   name="interior"
                                                                   id="interior"
                                                                   placeholder="{{ __('Npr. 75m², renoviran') }}"
                                                                   value="{{ old('interior') }}">
                                                        </div>
                                                        <div class="col-lg-6 mb-3">
                                                            <label for="type" class="form-label">
                                                                {{ __('Tip nekretnine') }}
                                                            </label>
                                                            <input type="text" class="form-control"
                                                                   name="type"
                                                                   id="type"
                                                                   placeholder="{{ __('Npr. Stan, Apartman') }}"
                                                                   value="{{ old('type') }}">
                                                        </div>
                                                        <div class="col-lg-12 mb-3">
                                                            <label for="images" class="form-label">
                                                                {{ __('Slike nekretnine') }} <span class="text-danger">*</span>
                                                            </label>
                                                            <input type="file" class="form-control"
                                                                   id="images"
                                                                   name="images[]"
                                                                   multiple
                                                                   required>
                                                            <small class="form-text text-muted">
                                                                {{ __('Možete odabrati više slika.') }}
                                                            </small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Sadržaji / Pogodnosti --}}
                                            <div class="col-lg-12 mb-3">
                                                <div class="single-upload-from-property">
                                                    <h5 class="single-input-title">
                                                        {{ __('Sadržaji / Pogodnosti') }}
                                                    </h5>
                                                    <div class="amenities-upload-input">
                                                        @foreach(getPropertyAmenities() as $key=>$amenity)
                                                            <div class="form-check form-check-inline mb-2">
                                                                <input type="checkbox"
                                                                       class="form-check-input"
                                                                       name="amenities[]"
                                                                       id="amenity{{ $key }}"
                                                                       value="{{ $key }}"
                                                                       {{ in_array((string)$key,old('amenities',[]),true)?'checked':'' }}>
                                                                <label class="form-check-label" for="amenity{{ $key }}">
                                                                    {{ __($amenity) }}
                                                                </label>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Informacije o okolini --}}
                                            <div class="col-lg-12 mb-3" id="nearbyInfoSection">
                                                <div class="d-flex justify-content-between align-items-center mb-3">
                                                    <h5 class="single-input-title mb-0">
                                                        {{ __('Informacije o okolini') }}
                                                    </h5>
                                                    <button type="button" class="btn theme-btn btn-sm" id="addInfo">
                                                        <i class="fas fa-plus"></i> {{ __('Dodaj još') }}
                                                    </button>
                                                </div>
                                                <div id="infoItems">
                                                    @php
                                                        $infoData = old('info', [['id'=>'','name'=>'','distance'=>'','contact_number'=>'','details'=>'']]);
                                                        $hasOld = !empty(old('info.name'));
                                                    @endphp
                                                    @foreach($infoData as $i => $item)
                                                        <div class="row border rounded p-3 mb-3 nearby-item">
                                                            <input type="hidden" name="info[id][]" value="{{ $item['id'] }}">
                                                            <div class="col-lg-6 mb-3">
                                                                <label class="form-label">{{ __('Naziv') }}</label>
                                                                <input type="text" class="form-control" name="info[name][]" value="{{ $item['name'] }}">
                                                            </div>
                                                            <div class="col-lg-6 mb-3">
                                                                <label class="form-label">{{ __('Udaljenost') }}</label>
                                                                <input type="text" class="form-control" name="info[distance][]" value="{{ $item['distance'] }}">
                                                            </div>
                                                            <div class="col-lg-6 mb-3">
                                                                <label class="form-label">{{ __('Kontakt') }}</label>
                                                                <input type="text" class="form-control" name="info[contact_number][]" value="{{ $item['contact_number'] }}">
                                                            </div>
                                                            <div class="col-lg-6 mb-3">
                                                                <label class="form-label">{{ __('Slika') }}</label>
                                                                <input type="file" class="form-control" name="info[image][{{ $i }}]">
                                                            </div>
                                                            <div class="col-lg-12 mb-3">
                                                                <label class="form-label">{{ __('Detalji') }}</label>
                                                                <textarea class="form-control" name="info[details][]" rows="2">{{ $item['details'] }}</textarea>
                                                            </div>
                                                            <div class="col-12 text-end">
                                                                <button type="button" class="btn theme-btn-red btn-sm removeInfo" {{ $i===0&&!$hasOld ? 'style=display:none' : '' }}>
                                                                    <i class="far fa-trash-alt"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </div>

                                            {{-- Prednosti --}}
                                            <div class="col-lg-12 mb-3">
                                                <div class="single-upload-from-property">
                                                    <h5 class="single-input-title">{{ __('Prednosti') }}</h5>
                                                    <div class="amenities-upload-input">
                                                        @foreach(getPropertyAdvantages() as $key=>$adv)
                                                            <div class="form-check form-check-inline mb-2">
                                                                <input type="checkbox" class="form-check-input" name="advantage[]" value="{{ $key }}" id="advantage{{ $key }}" {{ in_array((string)$key,old('advantage',[]),true)?'checked':'' }}>
                                                                <label class="form-check-label" for="advantage{{ $key }}">{{ __($adv) }}</label>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>
                                            </div>

                                            {{-- Dugme za čuvanje --}}
                                            <div class="col-lg-12 text-end">
                                                <button type="submit" class="btn theme-btn py-3 px-4 mt-3">
                                                    {{ __('Sačuvaj nekretninu') }}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>

                                {{-- Hidden route for JS --}}
                                <input type="hidden" id="listingRoute" value="{{ route('owner.listing.index') }}">

                                {{-- Template za novo Info polje --}}
                                <div id="nearbyInfoTemplate" style="display:none">
                                    <div class="row border rounded p-3 mb-3 nearby-item">
                                        <input type="hidden" name="info[id][]" value="">
                                        <!-- isto kao iznad, samo bez vrednosti -->
                                        <!-- … -->
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@push('style')
    <link rel="stylesheet" href="{{ asset('assets/properties/css/properties.css') }}">
    <link rel="stylesheet"
          href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
          integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
          crossorigin=""/>
    <style>
        #map { width:100%; height:400px; border:1px solid #dee2e6; border-radius:6px; }
        .single-upload-from-property { border:1px solid #e9ecef; padding:20px; border-radius:10px; background:#f8f9fa; }
    </style>
@endpush

@push('script')
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
            integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo="
            crossorigin=""></script>
    <script>
    document.addEventListener('DOMContentLoaded', function(){
        // JS za mapu, add/remove info i ajax handler …
        // (kopiraj ceo <script> iz Listing blade-a)
    });
    </script>
@endpush
