{{-- resources/views/owner/property/show.blade.php --}}
@extends('owner.layouts.app')

@section('content')
  <div class="main-content">
    <div class="page-content">
      <div class="container-fluid">

        {{-- … postojeći breadcrumb, naslov, statistike nekretnine … --}}

+       {{-- DUGMAD ZA KREIRANJE NOVOG OGLASA --}}
+       <div class="mb-4 d-flex">
+         <a href="{{ route('owner.listing.create', ['property_id' => $property->id]) }}"
+            class="btn btn-primary me-2">
+           {{ __('Dodaj Oglas sa nekretninom') }}
+         </a>
+         <a href="{{ route('owner.listing.create') }}"
+            class="btn btn-secondary">
+           {{ __('Dodaj Oglas bez nekretnine') }}
+         </a>
+       </div>

        {{-- LISTINGI VEZANI ZA OVAJ PROPERTY --}}
+       @isset($listings)
         <h4>{{ __('Oglasi za ovu nekretninu') }}</h4>
         <table class="table">
           <thead>
             <tr>
               <th>{{ __('Naziv') }}</th>
               <th class="text-end">{{ __('Cena') }}</th>
               <th>{{ __('Grad') }}</th>
               <th class="text-end">{{ __('Status') }}</th>
               <th class="text-center">{{ __('Akcije') }}</th>
             </tr>
           </thead>
           <tbody>
             @forelse($listings as $listing)
               <tr>
                 <td>{{ $listing->name }}</td>
                 <td class="text-end">{{ currencyPrice($listing->price) }}</td>
                 <td>{{ $listing->city ?? '-' }}</td>
                 <td class="text-end">
                   @if($listing->status == 1) {{ __('Aktivan') }}
                   @elseif($listing->status == 2) {{ __('Na čekanju') }}
                   @elseif($listing->status == 3) {{ __('Neaktivan') }}
                   @endif
                 </td>
                 <td class="text-center">
                   <a href="{{ route('owner.listing.edit', $listing->id) }}" class="btn btn-sm btn-primary">
                     {{ __('Uredi') }}
                   </a>
                 </td>
               </tr>
             @empty
               <tr>
                 <td colspan="5" class="text-center">{{ __('Nema oglasa za ovu nekretninu') }}</td>
               </tr>
             @endforelse
           </tbody>
         </table>
+       @endisset

        {{-- LISTINGI KOJI NISU POVEZANI NI SA JEDNOM NEKRETNINOM --}}
+       @isset($unassigned)
+       <h4 class="mt-5">{{ __('Oglasi bez nekretnine') }}</h4>
+       <table class="table">
+         <thead>
+           <tr>
+             <th>{{ __('Naziv') }}</th>
+             <th class="text-end">{{ __('Cena') }}</th>
+             <th>{{ __('Grad') }}</th>
+             <th class="text-end">{{ __('Status') }}</th>
+             <th class="text-center">{{ __('Akcije') }}</th>
+           </tr>
+         </thead>
+         <tbody>
+           @forelse($unassigned as $listing)
+             <tr>
+               <td>{{ $listing->name }}</td>
+               <td class="text-end">{{ currencyPrice($listing->price) }}</td>
+               <td>{{ $listing->city ?? '-' }}</td>
+               <td class="text-end">
+                 @if($listing->status == 1) {{ __('Aktivan') }}
+                 @elseif($listing->status == 2) {{ __('Na čekanju') }}
+                 @elseif($listing->status == 3) {{ __('Neaktivan') }}
+                 @endif
+               </td>
+               <td class="text-center">
+                 <a href="{{ route('owner.listing.edit', $listing->id) }}" class="btn btn-sm btn-primary">
+                   {{ __('Uredi') }}
+                 </a>
+               </td>
+             </tr>
+           @empty
+             <tr>
+               <td colspan="5" class="text-center">{{ __('Nema oglasa bez nekretnine') }}</td>
+             </tr>
+           @endforelse
+         </tbody>
+       </table>
+       @endisset

        {{-- … ostatak stranice (npr. izveštaji, etc.) … --}}
      </div>
    </div>
  </div>
@endsection
