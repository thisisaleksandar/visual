@extends('owner.layouts.app')

@section('content')
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="page-content-wrapper bg-white p-30 radius-20">
                <div class="d-flex justify-content-between align-items-center mb-20">
                    <h3>Dodaj rent korisnika</h3>
                    <a href="{{ route('owner.rent-users.index') }}" class="theme-btn">Nazad</a>
                </div>

                <form action="{{ route('owner.rent-users.store') }}" method="POST">
                    @csrf
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Ime*</label>
                            <input type="text" name="first_name" value="{{ old('first_name') }}" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Prezime*</label>
                            <input type="text" name="last_name" value="{{ old('last_name') }}" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email*</label>
                            <input type="email" name="email" value="{{ old('email') }}" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Telefon</label>
                            <input type="text" name="contact_number" value="{{ old('contact_number') }}" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Adresa</label>
                            <input type="text" name="address" value="{{ old('address') }}" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Grad</label>
                            <input type="text" name="city" value="{{ old('city') }}" class="form-control">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status plaćanja</label>
                            <select name="payment_status" class="form-select">
                                <option value="na_cekanju" {{ old('payment_status') == 'na_cekanju' ? 'selected' : '' }}>Na čekanju</option>
                                <option value="placeno" {{ old('payment_status') == 'placeno' ? 'selected' : '' }}>Plaćeno</option>
                            </select>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status korisnika</label>
                            <select name="status" class="form-select">
                                <option value="neaktivan" {{ old('status') == 'neaktivan' ? 'selected' : '' }}>Neaktivan</option>
                                <option value="aktivan" {{ old('status', 'neaktivan') == 'aktivan' ? 'selected' : '' }}>Aktivan</option>
                            </select>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Broj računa</label>
                            <input type="text" name="account_number" value="{{ old('account_number') }}" class="form-control">
                        </div>

                        <div class="col-md-12 mb-3">
                            <label class="form-label">Tip klijenta</label>
                            <select name="is_company" id="is_company" class="form-select">
                                <option value="0" {{ old('is_company') == '0' ? 'selected' : '' }}>Fizičko lice</option>
                                <option value="1" {{ old('is_company') == '1' ? 'selected' : '' }}>Kompanija</option>
                            </select>
                        </div>

                        <div class="col-md-6 mb-3" id="jmbg_block">
                            <label class="form-label">JMBG</label>
                            <input type="text" name="jmbg" value="{{ old('jmbg') }}" class="form-control">
                        </div>

                        <div class="col-md-6 mb-3 d-none" id="firma_block">
                            <label class="form-label">PIB</label>
                            <input type="text" name="pib" value="{{ old('pib') }}" class="form-control">
                            <label class="form-label mt-2">Matični broj</label>
                            <input type="text" name="maticni_broj" value="{{ old('maticni_broj') }}" class="form-control">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label">Procenat provizije</label>
                            <input type="number" step="0.01" name="commission_percentage" value="{{ old('commission_percentage') }}" class="form-control">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-check">
                                <input type="checkbox" name="is_fixed_commission" value="1" class="form-check-input" {{ old('is_fixed_commission') ? 'checked' : '' }}>
                                Fiksna provizija
                            </label>
                            <label class="form-label mt-2">Fiksni procenat (%)</label>
                            <input type="number" step="0.01" name="fixed_commission_percentage" value="{{ old('fixed_commission_percentage', 15) }}" class="form-control">
                        </div>

                      <div class="col-12 mt-4">
    <button type="submit" class="theme-btn">Sačuvaj</button>
    <a href="{{ route('owner.rent-users.index') }}" class="theme-btn btn-light ms-2">Otkaži</a>
</div>


                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('script')
<script>
document.addEventListener('DOMContentLoaded', () => {
    const typeSelect = document.getElementById('is_company');
    const firmaBlock = document.getElementById('firma_block');
    const jmbgBlock = document.getElementById('jmbg_block');

    function toggleClientType() {
        if (typeSelect.value === "1") {
            firmaBlock.classList.remove('d-none');
            jmbgBlock.classList.add('d-none');
        } else {
            firmaBlock.classList.add('d-none');
            jmbgBlock.classList.remove('d-none');
        }
    }

    typeSelect.addEventListener('change', toggleClientType);
    toggleClientType(); // inicijalni poziv
});
</script>
@endpush
