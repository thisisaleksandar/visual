@extends('owner.layouts.app')

@section('content')
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="page-content-wrapper bg-white p-30 radius-20">
                <div class="d-flex justify-content-between align-items-center mb-20">
                    <h3>Izmena rent korisnika</h3>
                    <a href="{{ route('owner.rent-users.index') }}" class="theme-btn">Nazad</a>
                </div>

                <form action="{{ route('owner.rent-users.update', $rentUser->id) }}" method="POST">
                    @csrf
                    @method('PUT')

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Ime</label>
                            <input type="text" name="first_name" value="{{ old('first_name', $rentUser->first_name) }}" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Prezime</label>
                            <input type="text" name="last_name" value="{{ old('last_name', $rentUser->last_name) }}" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" value="{{ old('email', $rentUser->email) }}" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Telefon</label>
                            <input type="text" name="contact_number" value="{{ old('contact_number', $rentUser->contact_number) }}" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Adresa</label>
                            <input type="text" name="address" value="{{ old('address', $rentUser->address) }}" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Grad</label>
                            <input type="text" name="city" value="{{ old('city', $rentUser->city) }}" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="1" {{ $rentUser->status ? 'selected' : '' }}>Aktivan</option>
                                <option value="0" {{ !$rentUser->status ? 'selected' : '' }}>Neaktivan</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Broj računa</label>
                            <input type="text" name="account_number" value="{{ old('account_number', $rentUser->account_number) }}" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">JMBG</label>
                            <input type="text" name="jmbg" value="{{ old('jmbg', $rentUser->jmbg) }}" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">PIB</label>
                            <input type="text" name="pib" value="{{ old('pib', $rentUser->pib) }}" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Matični broj</label>
                            <input type="text" name="maticni_broj" value="{{ old('maticni_broj', $rentUser->maticni_broj) }}" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tip klijenta</label>
                            <select name="is_company" class="form-select">
                                <option value="0" {{ !$rentUser->is_company ? 'selected' : '' }}>Fizičko lice</option>
                                <option value="1" {{ $rentUser->is_company ? 'selected' : '' }}>Kompanija</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Procenat provizije</label>
                            <input type="number" name="commission_percentage" value="{{ old('commission_percentage', $rentUser->commission_percentage) }}" step="0.01" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Fiksna provizija</label>
                            <input type="checkbox" name="is_fixed_commission" value="1" {{ $rentUser->is_fixed_commission ? 'checked' : '' }}>
                            <label class="form-label">Unesi fiksni procenat</label>
                            <input type="number" name="fixed_commission_percentage" value="{{ old('fixed_commission_percentage', $rentUser->fixed_commission_percentage ?? 15) }}" step="0.01" class="form-control">
                        </div>
                        <div class="col-12 mt-3">
                            <button type="submit" class="theme-btn">Sačuvaj izmene</button>
                            <a href="{{ route('owner.rent-users.index') }}" class="btn btn-secondary">Otkaži</a>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
@endsection
