@extends('owner.layouts.app')

@section('content')
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            <div class="page-content-wrapper bg-white p-30 radius-20">
                <div class="d-flex justify-content-between align-items-center mb-20">
                    <h3>Rent korisnici</h3>
                    <a href="{{ route('owner.rent-users.create') }}" class="theme-btn">
                        Dodaj rent korisnika
                    </a>
                </div>

                <div class="bg-off-white theme-border radius-4 p-25 table-responsive">
                    <table class="table table-striped dt-responsive nowrap" id="rentUsersTable">
                        <thead>
                            <tr>
                                <th>RB</th>
                                <th>ID</th>
                                <th>Ime</th>
                                <th>Prezime</th>
                                <th>Email</th>
                                <th>Telefon</th>
                                <th>Status</th>
                                <th>Adresa</th>
                                <th>Grad</th>
                                <th>Provizija</th>
                                <th>Tip klijenta</th>
                                <th>JMBG / PIB / MB</th>
                                <th>Broj oglasa</th>
                                <th>Broj računa</th>
                                <th>Akcije</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($rentUsers as $user)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td><span class="text-muted">#{{ $user->id }}</span></td>
                                <td>{{ $user->first_name ?? '-' }}</td>
                                <td>{{ $user->last_name ?? '-' }}</td>
                                <td>{{ $user->email ?? '-' }}</td>
                                <td>{{ $user->contact_number ?? '-' }}</td>
                                <td>
                                    @if($user->payment_status === 'placeno')
                                        <span class="badge bg-success">Plaćeno</span>
                                    @else
                                        <span class="badge bg-danger">Na čekanju</span>
                                    @endif
                                    <br>
                                    <small class="text-muted">{{ $user->status === 'aktivan' ? 'Aktivan' : 'Neaktivan' }}</small>
                                </td>
                                <td>{{ $user->address ?? '-' }}</td>
                                <td>{{ $user->city ?? '-' }}</td>
                                <td>
                                    @if($user->is_fixed_commission)
                                        Fiksna ({{ $user->fixed_commission_percentage ?? 15 }}%)
                                    @else
                                        {{ $user->commission_percentage ? number_format($user->commission_percentage, 2) . '%' : '-' }}
                                    @endif
                                </td>
                                <td>{{ $user->is_company ? 'Kompanija' : 'Fizičko lice' }}</td>
                                <td>
                                    @if($user->is_company)
                                        PIB: {{ $user->pib ?? '-' }}<br>
                                        MB: {{ $user->maticni_broj ?? '-' }}
                                    @else
                                        JMBG: {{ $user->jmbg ?? '-' }}
                                    @endif
                                </td>
                                <td>
                                    {{ ($user->listings_count ?? 0) + ($user->properties_count ?? 0) }}
                                </td>
                                <td>{{ $user->account_number ?? '-' }}</td>
                                <td class="text-end">
                                    <div class="d-inline-flex gap-2">
                                        <a href="{{ route('owner.rent-users.edit', $user->id) }}" class="theme-btn btn-sm text-info">
                                            Uredi
                                        </a>
                                        <form action="{{ route('owner.rent-users.destroy', $user->id) }}"
                                              method="POST"
                                              onsubmit="return confirm('Da li ste sigurni da želite da obrišete ovog korisnika?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="theme-btn btn-sm text-danger">
                                                Obriši
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="15" class="text-center">Nema unetih korisnika.</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>

                    @if($rentUsers->hasPages())
                    <div class="mt-3">
                        {{ $rentUsers->links() }}
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
