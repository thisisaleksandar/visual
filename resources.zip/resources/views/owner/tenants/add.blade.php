@extends('owner.layouts.app')

@section('content')
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <div class="page-content-wrapper bg-white p-30 radius-20">
                    {{-- Page Title & Breadcrumb --}}
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between border-bottom mb-20">
                                <div class="page-title-left">
                                    <h3 class="mb-sm-0">{{ $pageTitle ?? (isset($tenant) ? __('Izmeni Stanara') : __('Dodaj Stanara')) }}</h3>
                                </div>
                                <div class="page-title-right">
                                    <ol class="breadcrumb mb-0">
                                        <li class="breadcrumb-item"><a href="{{ route('owner.dashboard') }}" title="{{ __('Kontrolna tabla') }}">{{ __('Kontrolna tabla') }}</a></li>
                                        <li class="breadcrumb-item"><a href="{{ route('owner.tenant.index') }}">{{ __('Stanari') }}</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">{{ $pageTitle ?? (isset($tenant) ? __('Izmeni Stanara') : __('Dodaj Stanara')) }}</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="all-property-area">
                        <div class="add-tenants-area">
                            <div class="row">
                                <div class="col-12">
                                    <form class="ajax" action="{{ (isset($tenant) && $tenant->exists) ? route('owner.tenant.update', $tenant) : route('owner.tenant.store') }}" method="POST" enctype="multipart/form-data" data-handler="getRedirectResponse">
                                        @csrf
                                        @if(isset($tenant))
                                            @method('PUT')
                                        @endif
                                        <input type="hidden" name="id" value="{{ $tenant->id ?? '' }}">
                                        @if(isset($tenant) && isset($tenant->user_id))
                                            <input type="hidden" name="user_id" value="{{ $tenant->user_id }}">
                                        @endif

                                        {{-- Informacije o Stanaru --}}
                                        <div class="form-card add-property-box bg-light theme-border radius-4 p-20 mb-30 shadow-sm">
                                            <div class="add-property-title border-bottom pb-20 mb-20 d-flex justify-content-between align-items-center">
                                                <h4>{{ __('Informacije o Stanaru') }}</h4>
                                                <div>
                                                    <label for="tenant_status_select" class="form-label mb-0 me-2" style="vertical-align: middle;">{{ __('Status Stanara:') }}</label>
                                                    <span id="tenant_status_indicator" class="rounded-pill me-1" style="width: 18px; height: 18px; display: inline-block; vertical-align: middle; background-color: #6c757d;"></span>
                                                    <span id="tenant_status_text" class="fw-medium" style="vertical-align: middle;">{{ __('Skica') }}</span>
                                                </div>
                                            </div>

                                            <div class="p-3 bg-white radius-4">
                                                <h5 class="mb-3 text-primary border-bottom pb-2">{{ __('Lične Informacije') }}</h5>
                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Ime') }} <span class="text-danger">*</span></label>
                                                        <input type="text" name="first_name" class="form-control @error('first_name') is-invalid @enderror" placeholder="{{ __('Unesite ime') }}" value="{{ old('first_name', $tenant->user->first_name ?? ($tenant->first_name ?? '')) }}" required>
                                                        @error('first_name') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Prezime') }} <span class="text-danger">*</span></label>
                                                        <input type="text" name="last_name" class="form-control @error('last_name') is-invalid @enderror" placeholder="{{ __('Unesite prezime') }}" value="{{ old('last_name', $tenant->user->last_name ?? ($tenant->last_name ?? '')) }}" required>
                                                        @error('last_name') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Email') }} <span class="text-danger">*</span></label>
                                                        <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" placeholder="{{ __('npr. stanar@primer.com') }}" value="{{ old('email', $tenant->user->email ?? ($tenant->email ?? '')) }}" required>
                                                        @error('email') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Kontakt Telefon') }} <span class="text-danger">*</span></label>
                                                        <input type="text" name="contact_number" class="form-control @error('contact_number') is-invalid @enderror" placeholder="{{ __('npr. 06X XXX XXXX') }}" value="{{ old('contact_number', $tenant->user->contact_number ?? ($tenant->contact_number ?? '')) }}" required>
                                                        @error('contact_number') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                </div>
                                                 <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Starost') }}</label>
                                                        <input type="number" name="age" class="form-control @error('age') is-invalid @enderror" placeholder="{{ __('Unesite starost') }}" value="{{ old('age', $tenant->age ?? '') }}">
                                                        @error('age') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label for="tenant_status_select" class="form-label">{{ __('Status') }} <span class="text-danger">*</span></label>
                                                        <select class="form-select @error('status') is-invalid @enderror" id="tenant_status_select" name="status" required>
                                                            <option value="{{ TENANT_STATUS_DRAFT }}" data-indicator-class="bg-secondary" {{ old('status', $tenant->status ?? TENANT_STATUS_DRAFT) == TENANT_STATUS_DRAFT ? 'selected' : '' }}>{{ __('Skica') }}</option>
                                                            <option value="4" data-indicator-class="bg-info" {{ old('status', $tenant->status ?? '') == 4 ? 'selected' : '' }}>{{ __('Čeka Odobrenje') }}</option>
                                                            <option value="{{ TENANT_STATUS_ACTIVE }}" data-indicator-class="bg-success" {{ old('status', $tenant->status ?? '') == TENANT_STATUS_ACTIVE ? 'selected' : '' }}>{{ __('Aktivan') }}</option>
                                                            <option value="{{ TENANT_STATUS_INACTIVE }}" data-indicator-class="bg-warning" {{ old('status', $tenant->status ?? '') == TENANT_STATUS_INACTIVE ? 'selected' : '' }}>{{ __('Neaktivan') }}</option>
                                                        </select>
                                                        @error('status') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                </div>

                                                <h5 class="mt-4 mb-3 text-primary border-bottom pb-2">{{ __('Stalna Adresa') }}</h5>
                                                <div class="row">
                                                    <div class="col-md-12 mb-3">
                                                        <label class="form-label">{{ __('Adresa') }} <span class="text-danger">*</span></label>
                                                        <input type="text" name="permanent_address" class="form-control @error('permanent_address') is-invalid @enderror" placeholder="{{ __('Unesite ulicu i broj') }}" value="{{ old('permanent_address', $tenant->details->permanent_address ?? ($tenant->permanent_address ?? '')) }}" required>
                                                        @error('permanent_address') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Grad') }} <span class="text-danger">*</span></label>
                                                        <input type="text" name="permanent_city_id" class="form-control @error('permanent_city_id') is-invalid @enderror" placeholder="{{ __('Unesite grad') }}" value="{{ old('permanent_city_id', $tenant->details->permanent_city_id ?? ($tenant->permanent_city_id ?? '')) }}" required>
                                                         @error('permanent_city_id') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Poštanski Broj') }} <span class="text-danger">*</span></label>
                                                        <input type="text" name="permanent_zip_code" class="form-control @error('permanent_zip_code') is-invalid @enderror" placeholder="{{ __('Unesite poštanski broj') }}" value="{{ old('permanent_zip_code', $tenant->details->permanent_zip_code ?? ($tenant->permanent_zip_code ?? '')) }}" required>
                                                        @error('permanent_zip_code') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {{-- Detalji Zakupa i Plaćanja --}}
                                        <div class="form-card add-property-box bg-light theme-border radius-4 p-20 shadow-sm">
                                            <div class="add-property-title border-bottom pb-20 mb-20">
                                                <h4>{{ __('Detalji Zakupa i Plaćanja') }}</h4>
                                            </div>
                                            <div class="p-3 bg-white radius-4">
                                                <h5 class="mb-3 text-primary border-bottom pb-2">{{ __('Izbor Nekretnine i Oglasa') }}</h5>
                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Nekretnina') }} <span class="text-danger">*</span></label>
                                                        <select class="form-select property_id @error('property_id') is-invalid @enderror" name="property_id" required>
                                                            <option value="">--{{ __('Izaberi Nekretninu') }}--</option>
                                                            @if(isset($properties))
                                                                @foreach ($properties as $property)
                                                                    <option value="{{ $property->id }}" {{ old('property_id', $tenant->property_id ?? '') == $property->id ? 'selected' : '' }}>{{ $property->name }}</option>
                                                                @endforeach
                                                            @endif
                                                        </select>
                                                        @error('property_id') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Oglas za Zakup') }} <span class="text-danger">*</span></label>
                                                        <select class="form-select @error('listing_id') is-invalid @enderror" name="listing_id" id="listing_id_select" required>
                                                            <option value="">--{{ __('Prvo Izaberi Nekretninu') }}--</option>
                                                            @if(isset($listingsForSelectedProperty) && $listingsForSelectedProperty->count() > 0)
                                                                @foreach($listingsForSelectedProperty as $listing_item)
                                                                    <option value="{{ $listing_item->id }}" data-price="{{ $listing_item->price ?? 0 }}" data-duration-type="{{ $listing_item->price_duration_type ?? '' }}" {{ old('listing_id', $tenant->listing_id ?? '') == $listing_item->id ? 'selected' : '' }}>{{ $listing_item->name }}</option>
                                                                @endforeach
                                                            @elseif(isset($tenant) && isset($tenant->listing_id) && $tenant->listing)
                                                                 <option value="{{ $tenant->listing_id }}" data-price="{{ $tenant->listing->price ?? 0 }}" data-duration-type="{{ $tenant->listing->price_duration_type ?? '' }}" selected>{{ $tenant->listing->name }}</option>
                                                            @endif
                                                        </select>
                                                        @error('listing_id') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                </div>

                                                <h5 class="mt-4 mb-3 text-primary border-bottom pb-2">{{ __('Period Zakupa') }}</h5>
                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Datum Početka Zakupa') }}</label>
                                                        <div class="custom-datepicker">
                                                            <div class="custom-datepicker-inner position-relative">
                                                                <input type="text" class="datepicker form-control @error('lease_start_date') is-invalid @enderror" autocomplete="off" placeholder="dd.mm.yyyy" name="lease_start_date" value="{{ old('lease_start_date', isset($tenant->lease_start_date) ? \Carbon\Carbon::parse($tenant->lease_start_date)->format('d.m.Y') : '') }}">
                                                                <i class="ri-calendar-2-line"></i>
                                                            </div>
                                                            @error('lease_start_date') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Datum Završetka Zakupa') }}</label>
                                                        <div class="custom-datepicker">
                                                            <div class="custom-datepicker-inner position-relative">
                                                                <input type="text" class="datepicker form-control @error('lease_end_date') is-invalid @enderror" autocomplete="off" placeholder="dd.mm.yyyy" name="lease_end_date" value="{{ old('lease_end_date', isset($tenant->lease_end_date) ? \Carbon\Carbon::parse($tenant->lease_end_date)->format('d.m.Y') : '') }}">
                                                                <i class="ri-calendar-2-line"></i>
                                                            </div>
                                                             @error('lease_end_date') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                                        </div>
                                                    </div>
                                                </div>

                                                <h5 class="mt-4 mb-3 text-primary border-bottom pb-2">{{ __('Finansijske Informacije') }}</h5>
                                                <div class="row">
                                                    <div class="col-md-6 mb-3">
                                                        <label class="form-label">{{ __('Mesečna Kirija') }} <span class="text-danger">*</span></label>
                                                        <div class="input-group">
                                                            <input type="number" step="any" class="form-control @error('general_rent') is-invalid @enderror" id="general_rent" placeholder="{{ __('Iznos kirije') }}" value="{{ old('general_rent', $tenant->general_rent ?? '') }}" name="general_rent" required>
                                                            <span class="input-group-text">{{ getOption('currency_symbol', 'EUR') }}</span>
                                                        </div>
                                                        <small id="price_per_day_info" class="form-text text-muted mt-1" style="display: none;"></small>
                                                         @error('general_rent') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                                    </div>
                                                    <div class="col-md-6 mb-3">
                                                        <label for="preferred_payment_method" class="form-label">{{ __('Preferirani Način Plaćanja') }}</label>
                                                        <select class="form-select @error('preferred_payment_method') is-invalid @enderror" id="preferred_payment_method" name="preferred_payment_method">
                                                            <option value="">-- {{ __('Izaberite način') }} --</option>
                                                            <option value="wu" {{ old('preferred_payment_method', $tenant->preferred_payment_method ?? '') == 'wu' ? 'selected' : '' }}>{{ __('Western Union (WU)') }}</option>
                                                            <option value="postnet" {{ old('preferred_payment_method', $tenant->preferred_payment_method ?? '') == 'postnet' ? 'selected' : '' }}>{{ __('PostNet') }}</option>
                                                            <option value="bank_transfer" {{ old('preferred_payment_method', $tenant->preferred_payment_method ?? '') == 'bank_transfer' ? 'selected' : '' }}>{{ __('Na račun u banci') }}</option>
                                                            <option value="cash" {{ old('preferred_payment_method', $tenant->preferred_payment_method ?? '') == 'cash' ? 'selected' : '' }}>{{ __('Gotovina') }}</option>
                                                            <option value="manual" {{ old('preferred_payment_method', $tenant->preferred_payment_method ?? '') == 'manual' ? 'selected' : '' }}>{{ __('Ručni unos/Ostalo') }}</option>
                                                        </select>
                                                        @error('preferred_payment_method') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6 mb-3"> {{-- Prethodno col-md-6 col-lg-4 align-self-end --}}
                                                        <label class="form-label">{{ __('Ukupno za Period Zakupa') }}</label>
                                                        <div class="input-group">
                                                            <input type="number" step="any" class="form-control @error('total_rent_for_period') is-invalid @enderror" id="total_rent_for_period" name="total_rent_for_period" placeholder="0.00" value="{{ old('total_rent_for_period', $tenant->total_rent_for_period ?? '') }}">
                                                            <span class="input-group-text">{{ getOption('currency_symbol', 'EUR') }}</span>
                                                        </div>
                                                        @error('total_rent_for_period') <div class="text-danger mt-1">{{ $message }}</div> @enderror
                                                    </div>
                                                    {{-- Prazan div da popuni ostatak reda ako je potrebno, ili dodajte drugo polje ovde --}}
                                                    <div class="col-md-6 mb-3"></div>
                                                </div>

                                                <h5 class="mt-4 mb-3 text-primary border-bottom pb-2">{{ __('Status Plaćanja Kirije') }}</h5>
                                                <div class="row align-items-center">
                                                    <div class="col-lg-6 mb-3">
                                                        <label for="payment_type" class="form-label">{{ __('Izaberite Status') }}</label>
                                                        <div class="input-group">
                                                            <select class="form-select @error('payment_type') is-invalid @enderror" id="payment_type" name="payment_type">
                                                                <option value="">{{ __('--Izaberi Status Plaćanja--') }}</option>
                                                                <option value="paid_upfront" data-indicator-class="bg-primary" {{ old('payment_type', $tenant->payment_type ?? '') == 'paid_upfront' ? 'selected' : '' }}>{{ __('Plaćeno Unapred (Inicijalno)') }}</option>
                                                                <option value="advance" data-indicator-class="bg-warning" {{ old('payment_type', $tenant->payment_type ?? '') == 'advance' ? 'selected' : '' }}>{{ __('Avansno Plaćanje') }}</option>
                                                                <option value="immediate" data-indicator-class="bg-danger" {{ old('payment_type', $tenant->payment_type ?? '') == 'immediate' ? 'selected' : '' }}>{{ __('Plaća se Odmah') }}</option>
                                                                <option value="fully_settled" data-indicator-class="bg-success" {{ old('payment_type', $tenant->payment_type ?? '') == 'fully_settled' ? 'selected' : '' }}>{{ __('Izmireno (Sve Plaćeno)') }}</option>
                                                            </select>
                                                            <span class="input-group-text" id="payment_type_indicator_wrapper" style="padding: .375rem .5rem;">
                                                                <span id="payment_type_indicator" class="rounded-pill" style="width: 18px; height: 18px; display: inline-block; vertical-align: middle; background-color: #adb5bd;"></span>
                                                            </span>
                                                        </div>
                                                        @error('payment_type') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div id="payment_details_container">
                                                            {{-- Detalji za "Plaćeno Unapred" --}}
                                                            <div id="details_paid_upfront" class="payment-details-group mt-2" style="{{ old('payment_type', $tenant->payment_type ?? '') == 'paid_upfront' ? '' : 'display: none;' }}">
                                                                <div class="mb-2">
                                                                    <label for="paid_upfront_amount" class="form-label form-label-sm">{{ __('Uplaćen Iznos Unapred') }}</label>
                                                                    <input type="number" step="any" class="form-control form-control-sm @error('paid_upfront_amount') is-invalid @enderror" id="paid_upfront_amount" name="paid_upfront_amount" value="{{ old('paid_upfront_amount', $tenant->paid_upfront_amount ?? '') }}" placeholder="{{ __('Iznos') }}">
                                                                     @error('paid_upfront_amount') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                                </div>
                                                                <div class="mb-2">
                                                                    <label for="paid_upfront_date" class="form-label form-label-sm">{{ __('Datum Uplate Unapred') }}</label>
                                                                    <input type="text" class="datepicker-payment form-control form-control-sm @error('paid_upfront_date') is-invalid @enderror" autocomplete="off" placeholder="dd.mm.yyyy" name="paid_upfront_date" value="{{ old('paid_upfront_date', isset($tenant->paid_upfront_date) ? \Carbon\Carbon::parse($tenant->paid_upfront_date)->format('d.m.Y') : '') }}">
                                                                     @error('paid_upfront_date') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                                </div>
                                                            </div>
                                                            {{-- Detalji za "Avansno Plaćanje" --}}
                                                            <div id="details_advance" class="payment-details-group mt-2" style="{{ old('payment_type', $tenant->payment_type ?? '') == 'advance' ? '' : 'display: none;' }}">
                                                                <div class="mb-2">
                                                                    <label for="advance_amount" class="form-label form-label-sm">{{ __('Iznos Avansa') }}</label>
                                                                    <input type="number" step="any" class="form-control form-control-sm @error('advance_amount') is-invalid @enderror" id="advance_amount" name="advance_amount" value="{{ old('advance_amount', $tenant->advance_amount ?? '') }}" placeholder="{{ __('Iznos') }}">
                                                                    @error('advance_amount') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                                </div>
                                                                <div class="mb-2">
                                                                    <label for="advance_due_date" class="form-label form-label-sm">{{ __('Rok za Uplatu Ostatka') }}</label>
                                                                    <input type="text" class="datepicker-payment form-control form-control-sm @error('advance_due_date') is-invalid @enderror" autocomplete="off" placeholder="dd.mm.yyyy" id="advance_due_date" name="advance_due_date" value="{{ old('advance_due_date',  isset($tenant->advance_due_date) ? \Carbon\Carbon::parse($tenant->advance_due_date)->format('d.m.Y') : '') }}">
                                                                    @error('advance_due_date') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                                </div>
                                                                <div class="mb-2">
                                                                    <label for="advance_notes" class="form-label form-label-sm">{{ __('Napomene za Avans') }}</label>
                                                                    <textarea class="form-control form-control-sm @error('advance_notes') is-invalid @enderror" id="advance_notes" name="advance_notes" rows="2">{{ old('advance_notes', $tenant->advance_notes ?? '') }}</textarea>
                                                                    @error('advance_notes') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                                </div>
                                                            </div>
                                                            {{-- Detalji za "Plaća se Odmah" --}}
                                                            <div id="details_immediate" class="payment-details-group mt-2" style="{{ old('payment_type', $tenant->payment_type ?? '') == 'immediate' ? '' : 'display: none;' }}">
                                                                 <div class="mb-2">
                                                                    <label for="immediate_payment_notes" class="form-label form-label-sm">{{ __('Napomene') }}</label>
                                                                    <textarea class="form-control form-control-sm @error('immediate_payment_notes') is-invalid @enderror" id="immediate_payment_notes" name="immediate_payment_notes" rows="2">{{ old('immediate_payment_notes', $tenant->immediate_payment_notes ?? '') }}</textarea>
                                                                    @error('immediate_payment_notes') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                                </div>
                                                            </div>
                                                            {{-- Detalji za "Izmireno" --}}
                                                            <div id="details_fully_settled" class="payment-details-group mt-2" style="{{ old('payment_type', $tenant->payment_type ?? '') == 'fully_settled' ? '' : 'display: none;' }}">
                                                                <div class="mb-2">
                                                                    <label for="fully_settled_date" class="form-label form-label-sm">{{ __('Datum Potvrde Izmirenja') }}</label>
                                                                    <input type="text" class="datepicker-payment form-control form-control-sm @error('fully_settled_date') is-invalid @enderror" autocomplete="off" placeholder="dd.mm.yyyy" id="fully_settled_date" name="fully_settled_date" value="{{ old('fully_settled_date', isset($tenant->fully_settled_date) ? \Carbon\Carbon::parse($tenant->fully_settled_date)->format('d.m.Y') : '') }}">
                                                                    @error('fully_settled_date') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                                </div>
                                                                <div class="mb-2">
                                                                    <label for="fully_settled_notes" class="form-label form-label-sm">{{ __('Napomene o Izmirenju') }}</label>
                                                                    <textarea class="form-control form-control-sm @error('fully_settled_notes') is-invalid @enderror" id="fully_settled_notes" name="fully_settled_notes" rows="2">{{ old('fully_settled_notes', $tenant->fully_settled_notes ?? '') }}</textarea>
                                                                    @error('fully_settled_notes') <div class="invalid-feedback">{{ $message }}</div> @enderror
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-end mt-4">
                                            <button type="submit" class="btn btn-primary btn-lg px-4">{{ isset($tenant) ? __('Sačuvaj Izmene') : __('Sačuvaj Stanara') }} <i class="ri-check-line align-middle"></i></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{-- Hidden Inputs for Routes --}}
    <input type="hidden" id="getStateListRoute" value="{{ route('owner.location.state.list') }}">
    <input type="hidden" id="getCityListRoute" value="{{ route('owner.location.city.list') }}">
    <input type="hidden" id="propertyShowRoute" value="{{ route('owner.property.show', 0) }}">
    <input type="hidden" id="tenantListRoute" value="{{ route('owner.tenant.index') }}">
    <input type="hidden" id="getPropertyListingsRoute" value="{{ route('owner.listing.getPropertyListings') }}">
@endsection

@push('style')
<link rel="stylesheet" href="{{ asset('assets/libs/dropify/css/dropify.min.css') }}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
<style>
    #payment_type_indicator.bg-primary,
    #tenant_status_indicator.bg-primary { background-color: #0d6efd !important; }
    #payment_type_indicator.bg-warning,
    #tenant_status_indicator.bg-warning { background-color: #ffc107 !important; }
    #payment_type_indicator.bg-danger,
    #tenant_status_indicator.bg-danger  { background-color: #dc3545 !important; }
    #payment_type_indicator.bg-success,
    #tenant_status_indicator.bg-success { background-color: #198754 !important; }
    #payment_type_indicator.bg-secondary,
    #tenant_status_indicator.bg-secondary { background-color: #6c757d !important; }
    #tenant_status_indicator.bg-info { background-color: #0dcaf0 !important; }

    .form-label { margin-bottom: .3rem; font-weight: 500; }
    .form-label-sm { font-size: 0.8rem; margin-bottom: .2rem; }
    .form-card { box-shadow: 0 0.5rem 1rem rgba(0,0,0,.05); }
    .theme-border { border: 1px solid #e9ecef; }
    .bg-light { background-color: #f8f9fa !important; }
    .pb-20 { padding-bottom: 1.2rem !important; }
    .mb-20 { margin-bottom: 1.2rem !important; }
    .radius-4 { border-radius: .25rem; }
    .text-primary { color: #007bff !important; }
</style>
@endpush
@push('script')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
@if(file_exists(public_path('assets/libs/bootstrap-datepicker/locales/bootstrap-datepicker.sr-latin.min.js')))
    <script src="{{ asset('assets/libs/bootstrap-datepicker/locales/bootstrap-datepicker.sr-latin.min.js') }}" charset="UTF-8"></script>
@elseif(file_exists(public_path('assets/libs/bootstrap-datepicker/locales/bootstrap-datepicker.sr.min.js')))
    <script src="{{ asset('assets/libs/bootstrap-datepicker/locales/bootstrap-datepicker.sr.min.js') }}" charset="UTF-8"></script>
@endif
<script src="{{ asset('assets/libs/dropify/js/dropify.min.js') }}"></script>
<script src="{{ asset('assets/libs/moment/moment.min.js') }}"></script>
@if(file_exists(public_path('assets/libs/moment/locale/sr.js')))
    <script src="{{ asset('assets/libs/moment/locale/sr.js') }}"></script>
    <script>moment.locale('sr');</script>
@endif

<script>
$(document).ready(function() {
    var propertySelect = $('.property_id');
    var listingSelect = $('#listing_id_select');
    var generalRentInput = $('#general_rent');
    var pricePerDayInfo = $('#price_per_day_info');
    var isRentManuallyChanged = false;

    if ("{{ old('general_rent', $tenant->general_rent ?? '') }}" !== '') { // Provera i sa $tenant->general_rent
        isRentManuallyChanged = true;
    }

    const PRICE_DURATION_TYPE_DAILY = {{ defined('PRICE_DURATION_TYPE_DAILY') ? PRICE_DURATION_TYPE_DAILY : 1 }};
    const PRICE_DURATION_TYPE_MONTHLY = {{ defined('PRICE_DURATION_TYPE_MONTHLY') ? PRICE_DURATION_TYPE_MONTHLY : 2 }};

    function loadListingsForTenant(propertyId, selectedListingId = null, callback) {
        if (!propertyId) {
            listingSelect.html('<option value="">--{{ __('Prvo Izaberi Nekretninu') }}--</option>').val("").trigger('change');
            pricePerDayInfo.hide().text('');
            if (typeof callback === 'function') callback();
            return;
        }
        var route = $('#getPropertyListingsRoute').val();
        listingSelect.prop('disabled', true).html('<option value="">--{{ __('Učitavanje oglasa...') }}--</option>');
        pricePerDayInfo.hide().text('');

        $.ajax({
            url: route, type: 'GET', data: { 'property_id': propertyId }, dataType: 'json',
            success: function(response) {
                var optionsHtml = '<option value="">--{{ __('Izaberi Oglas') }}--</option>';
                var listings = response.data || response;
                var autoSelectedPrice = null;
                var autoSelectedDurationType = null;

                if (listings && listings.length > 0) {
                    $.each(listings, function(index, listing) {
                        var isSelected = (selectedListingId && String(listing.id) === String(selectedListingId));
                        optionsHtml += '<option value="' + listing.id + '" data-price="' + (listing.price || 0) + '" data-duration-type="' + (listing.price_duration_type || '') + '" ' + (isSelected ? 'selected' : '') + '>' + listing.name + '</option>';
                        if (isSelected) {
                            autoSelectedPrice = listing.price || 0;
                            autoSelectedDurationType = listing.price_duration_type || '';
                        }
                    });
                    listingSelect.html(optionsHtml).prop('disabled', false);

                    if (selectedListingId) {
                        listingSelect.val(selectedListingId);
                        if(autoSelectedPrice !== null && (!isRentManuallyChanged || generalRentInput.val() === '' || generalRentInput.val() === '0' || generalRentInput.val() === '0.00')) {
                            generalRentInput.val(autoSelectedPrice);
                        }
                        updatePricePerDayInfo(autoSelectedPrice, autoSelectedDurationType);
                    } else if (listings.length === 1 && !$('input[name="id"]').val()) {
                         listingSelect.val(listings[0].id).trigger('change');
                    } else {
                        listingSelect.trigger('change');
                    }
                } else {
                     optionsHtml = '<option value="" disabled>--{{ __('Nema oglasa za ovu nekretninu') }}--</option>';
                     listingSelect.html(optionsHtml).prop('disabled', false).trigger('change');
                     if (!isRentManuallyChanged) generalRentInput.val('');
                     pricePerDayInfo.hide().text('');
                }
                if (typeof callback === 'function') { setTimeout(callback, 50); }
            },
            error: function() {
                listingSelect.html('<option value="">--{{ __('Greška pri učitavanju') }}--</option>').prop('disabled', false);
                if (typeof callback === 'function') callback();
            }
        });
    }

    function updatePricePerDayInfo(price, durationType) {
        var currencySymbol = "{{ getOption('currency_symbol', 'EUR') }}";
        pricePerDayInfo.hide().text('');
        if (price && String(durationType) === String(PRICE_DURATION_TYPE_DAILY)) {
            pricePerDayInfo.text('{{ __("Cena po danu:") }} ' + parseFloat(price).toFixed(2) + ' ' + currencySymbol).show();
        } else if (price && String(durationType) === String(PRICE_DURATION_TYPE_MONTHLY)) {
            var dailyApprox = parseFloat(price) / 30;
            pricePerDayInfo.text('{{ __("Približna cena po danu:") }} ' + dailyApprox.toFixed(2) + ' ' + currencySymbol).show();
        }
    }

    propertySelect.on('change', function() {
        // Čuvamo da li je korisnik ručno menjao pre promene property-ja
        // Ako nije, resetovaćemo flag. Ako jeste, ostavićemo ga.
        var previousRent = generalRentInput.val();
        if (previousRent === '' || previousRent === '0' || previousRent === '0.00') {
            isRentManuallyChanged = false;
        }
        loadListingsForTenant($(this).val(), null);
    });

    listingSelect.on('change', function() {
        var selectedOption = $(this).find('option:selected');
        var price = selectedOption.data('price');
        var durationTypeLocal = selectedOption.data('duration-type');

        if (!isRentManuallyChanged || generalRentInput.val() === '' || generalRentInput.val() === '0' || generalRentInput.val() === '0.00') {
            if (price !== undefined && price !== null && $(this).val() !== '') {
                generalRentInput.val(price);
            } else if ($(this).val() === '') {
                 generalRentInput.val('');
            }
        }
        updatePricePerDayInfo(price, durationTypeLocal);
    });

    generalRentInput.on('input', function(){
        isRentManuallyChanged = true;
    });

    var initialPropertyId = propertySelect.val();
    var oldListingId = "{{ old('listing_id', $tenant->listing_id ?? '') }}";

    if (initialPropertyId) {
        loadListingsForTenant(initialPropertyId, oldListingId);
    } else {
        listingSelect.html('<option value="">--{{ __('Prvo Izaberi Nekretninu') }}--</option>');
    }

    var tenantStatusSelect = $('#tenant_status_select');
    var tenantStatusIndicator = $('#tenant_status_indicator');
    var tenantStatusText = $('#tenant_status_text');
    function updateTenantStatusIndicator() {
        var selectedOption = tenantStatusSelect.find('option:selected');
        var indicatorClass = selectedOption.data('indicator-class') || 'bg-secondary';
        var statusText = selectedOption.text();
        tenantStatusIndicator.removeClass('bg-primary bg-warning bg-danger bg-secondary bg-success bg-info').addClass(indicatorClass);
        tenantStatusText.text(statusText);
    }
    updateTenantStatusIndicator();
    tenantStatusSelect.on('change', updateTenantStatusIndicator);

    var paymentTypeSelect = $('#payment_type');
    var paymentIndicator = $('#payment_type_indicator');
    var allDetailGroups = $('.payment-details-group');
    function togglePaymentDetails() {
        var selectedValue = paymentTypeSelect.val();
        var selectedOption = paymentTypeSelect.find('option:selected');
        var indicatorClass = selectedOption.data('indicator-class') || 'bg-secondary';
        paymentIndicator.removeClass('bg-primary bg-warning bg-danger bg-success bg-secondary').addClass(indicatorClass);
        allDetailGroups.hide();
        if (selectedValue) {
            $('#details_' + selectedValue).show();
        }
    }
    togglePaymentDetails();
    paymentTypeSelect.on('change', togglePaymentDetails);


    if($(".datepicker, .datepicker-payment").length) {
        var datepickerOptions = {
            format: "dd.mm.yyyy",
            autoclose: true,
            todayHighlight: true,
        };
        var lang = '{{ app()->getLocale() }}';
        if(lang === 'sr-latin' && typeof $.fn.datepicker.languages !== 'undefined' && $.fn.datepicker.languages['sr-latin']){
            datepickerOptions.language = 'sr-latin';
        } else if (lang === 'sr' && typeof $.fn.datepicker.languages !== 'undefined' && $.fn.datepicker.languages['sr']) {
             datepickerOptions.language = 'sr';
        }

        $('.datepicker, .datepicker-payment').datepicker(datepickerOptions).on('changeDate', function(){
            $(this).trigger('change');
        });
    }

    if($('.dropify').length){ $('.dropify').dropify(); }

    $(document).on('submit', 'form.ajax', function(e){
        e.preventDefault();
        var $form = $(this);
        var action = $form.attr('action');
        var method = $form.attr('method');
        var formData = new FormData(this);
        var isEdit = formData.get('id') ? true : false;
        var submitButtonInitialText = isEdit ? '{{__("Sačuvaj Izmene")}} <i class="ri-check-line align-middle"></i>' : '{{__("Sačuvaj Stanara")}} <i class="ri-check-line align-middle"></i>';
        var submitButtonSavingText = isEdit ? '{{__("Čuvanje izmena...")}}' : '{{__("Čuvanje stanara...")}}';


        $form.find('button[type=submit]').prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> ' + submitButtonSavingText);

        $form.find('.is-invalid').removeClass('is-invalid');
        $form.find('.invalid-feedback').remove();
        $form.find('.text-danger.mt-1').remove();

        $.ajax({
            url: action,
            type: method,
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                $form.find('button[type=submit]').prop('disabled', false).html(submitButtonInitialText);

                if (response.success) {
                    // Ovde bi trebalo koristiti neku bolju notifikaciju od alert-a (npr. Toastr)
                    alert(response.message || (isEdit ? '{{__("Stanar uspešno izmenjen!")}}' : '{{__("Stanar uspešno sačuvan!")}}'));
                    if (response.redirect) {
                         window.location.href = response.redirect;
                    } else {
                         window.location.href = "{{ route('owner.tenant.index') }}";
                    }
                } else {
                    alert(response.message || '{{__("Došlo je do greške prilikom snimanja!")}}');
                }
            },
            error: function(xhr) {
                $form.find('button[type=submit]').prop('disabled', false).html(submitButtonInitialText);

                if (xhr.status === 422 && xhr.responseJSON && xhr.responseJSON.errors) {
                    var errors = xhr.responseJSON.errors;
                    var errorMessages = '{{__("Molimo ispravite sledeće greške:")}}\n';
                    $.each(errors, function(key, value) {
                        errorMessages += '- ' + value[0] + '\n';
                        var field = $form.find('[name="' + key + '"]');
                        if(field.length === 0 && key.includes('.')) { // Za nizove tipa some_array.index.field
                            var baseName = key.substring(0, key.indexOf('['));
                            field = $form.find('[name^="' + baseName + '"]:eq(0)'); // Uzmi prvi element niza kao referencu
                        }

                        field.addClass('is-invalid');
                        var errorContainer = field.closest('.mb-3, .mb-2').find('.invalid-feedback');
                        if (field.parent().hasClass('input-group') && errorContainer.length === 0) {
                             field.parent().after('<div class="text-danger mt-1" style="font-size: .875em;">' + value[0] + '</div>');
                        } else if (errorContainer.length > 0) {
                            errorContainer.text(value[0]).show();
                        } else {
                             field.after('<div class="invalid-feedback d-block">' + value[0] + '</div>');
                        }
                    });
                    // Možda ne želite alert ako već prikazujete greške ispod polja
                    // alert(errorMessages);
                } else {
                    let msg = xhr.responseJSON && xhr.responseJSON.message ? xhr.responseJSON.message : '{{__("Došlo je do greške na serveru!")}}';
                    alert(msg + ' (Status: ' + xhr.status + ')');
                }
            }
        });
    });

});
</script>
@endpush