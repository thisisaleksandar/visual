@extends('owner.layouts.app')

@section('content')
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <!-- Page Content Wrapper Start -->
                <div class="page-content-wrapper bg-white p-30 radius-20">
                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div
                                class="page-title-box d-sm-flex align-items-center justify-content-between border-bottom mb-20">
                                <div class="page-title-left">
                                    {{-- Pretpostavka: $tenant->user->first_name i last_name postoje --}}
                                    <h3 class="mb-sm-0">{{ $pageTitle }} - {{ $tenant->user->first_name ?? '' }} {{ $tenant->user->last_name ?? __('Stanar') }}</h3>
                                </div>
                                <div class="page-title-right">
                                    <ol class="breadcrumb mb-0">
                                        <li class="breadcrumb-item"><a href="{{ route('owner.dashboard') }}"
                                                title="Dashboard">{{ __('Dashboard') }}</a></li>
                                        <li class="breadcrumb-item"><a href="{{ route('owner.tenant.index') }}"
                                                title="{{ __('Tenants') }}">{{ __('Tenants') }}</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">{{ $pageTitle }}</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <!-- Tenants Details Layout Wrap Area row Start -->
                    <div class="tenants-details-layout-wrap position-relative">
                        <div class="row">
                            <!-- Account settings Left Side Start-->
                            <div class="col-md-12 col-lg-12 col-xl-4 col-xxl-3">
                                <div class="account-settings-leftside bg-white theme-border radius-4 p-20 mb-25">
                                    <div class="tenants-details-leftsidebar-wrap d-flex">
                                        {{-- Osiguraj da $tenant objekat bude prosleđen u sidenav ako je potreban tamo --}}
                                        @include('owner.tenants.details.sidenav', ['tenant' => $tenant])
                                    </div>
                                </div>
                            </div>
                            <!-- Account settings Left Side End-->

                            <!-- Account settings Area Right Side Start-->
                            <div class="col-md-12 col-lg-12 col-xl-8 col-xxl-9">
                                <div class="account-settings-rightside bg-off-white theme-border radius-4 p-25">
                                    <!-- Tenants Home Details Start -->
                                    <div class="tenants-home-details-information">
                                        <!-- Account Settings Content Box Start -->
                                        <div class="account-settings-content-box">
                                            {{-- START: Osnovne informacije o stanaru --}}
                                            <div class="add-property-title border-bottom pb-15 mb-20">
                                                <h4>{{ __('Osnovne Informacije o Stanaru') }}</h4>
                                            </div>
                                            <div class="row mb-25">
                                                <div class="col-md-6 col-lg-4 mb-3">
                                                    <p class="label-text-title color-heading font-medium mb-1">{{ __('Ime i Prezime') }}</p>
                                                    <p>{{ $tenant->user->first_name ?? 'N/A' }} {{ $tenant->user->last_name ?? '' }}</p>
                                                </div>
                                                <div class="col-md-6 col-lg-4 mb-3">
                                                    <p class="label-text-title color-heading font-medium mb-1">{{ __('Email') }}</p>
                                                    <p>{{ $tenant->user->email ?? 'N/A' }}</p>
                                                </div>
                                                <div class="col-md-6 col-lg-4 mb-3">
                                                    <p class="label-text-title color-heading font-medium mb-1">{{ __('Kontakt Telefon') }}</p>
                                                    <p>{{ $tenant->user->contact_number ?? 'N/A' }}</p>
                                                </div>
                                                <div class="col-md-6 col-lg-4 mb-3">
                                                    <p class="label-text-title color-heading font-medium mb-1">{{ __('Starost') }}</p>
                                                    <p>{{ $tenant->age ?? 'N/A' }}</p>
                                                </div>
                                                <div class="col-md-6 col-lg-4 mb-3">
                                                    <p class="label-text-title color-heading font-medium mb-1">{{ __('Status Stanara') }}</p>
                                                    <p>
                                                        @if ($tenant->status == TENANT_STATUS_ACTIVE)
                                                            <span class="status-btn status-btn-green font-13">{{ __('Aktivan') }}</span>
                                                        @elseif ($tenant->status == TENANT_STATUS_INACTIVE)
                                                            <span class="status-btn status-btn-orange font-13">{{ __('Neaktivan') }}</span>
                                                        @else
                                                            <span class="status-btn status-btn-gray font-13">{{ __('Skica') }}</span>
                                                        @endif
                                                    </p>
                                                </div>
                                                <div class="col-md-6 col-lg-4 mb-3">
                                                    <p class="label-text-title color-heading font-medium mb-1">{{ __('Preferirani Način Plaćanja') }}</p>
                                                    <p class="fw-medium">
                                                        @if($tenant->preferred_payment_method == 'wu')
                                                            {{ __('Western Union (WU)') }}
                                                        @elseif($tenant->preferred_payment_method == 'postnet')
                                                            {{ __('PostNet') }}
                                                        @elseif($tenant->preferred_payment_method == 'bank_transfer')
                                                            {{ __('Na račun u banci') }}
                                                        @elseif($tenant->preferred_payment_method == 'cash')
                                                            {{ __('Gotovina') }}
                                                        @elseif($tenant->preferred_payment_method == 'manual')
                                                            {{ __('Ručni unos/Ostalo') }}
                                                        @else
                                                            {{ __('Nije navedeno') }}
                                                        @endif
                                                    </p>
                                                </div>
                                                {{-- Dodaj ovde prikaz za stalnu adresu ako je potrebno --}}
                                                {{-- <div class="col-md-12 mb-3">
                                                    <p class="label-text-title color-heading font-medium mb-1">{{ __('Stalna Adresa') }}</p>
                                                    <p>{{ $tenant->permanent_address ?? 'N/A' }}, {{ $tenant->permanent_city_id ?? 'N/A' }} {{ $tenant->permanent_zip_code ?? '' }}</p>
                                                </div> --}}
                                            </div>
                                            {{-- END: Osnovne informacije o stanaru --}}


                                            <div class="account-settings-info-box">
                                                <!-- Property Item Start -->
                                                <div class="col-md-12"> {{-- Uklonjene suvišne klase za kolone ovde --}}
                                                    <div
                                                        class="property-item tenants-details-home-details-property-item bg-off-white border-bottom radius-10 radius-b-l-0 radius-b-r-0 mb-25">
                                                        @if($tenant->property) {{-- Provera da li nekretnina postoji --}}
                                                            <a href="{{ route('owner.property.show', $tenant->property->id) }}" {{-- Link ka detaljima nekretnine --}}
                                                                class="property-item-img-wrap d-block position-relative overflow-hidden radius-10">
                                                                <div class="property-item-img">
                                                                    {{-- Pretpostavka: Property model ima thumbnail_image accessor ili direktno polje --}}
                                                                    <img src="{{ $tenant->property->thumbnail_image_url ?? asset('assets/images/no-property-img.jpg') }}"
                                                                        alt="{{ $tenant->property->name ?? '' }}" class="fit-image">
                                                                </div>
                                                            </a>
                                                            <div class="property-item-content p-25 px-0">
                                                                <div class="tenants-details-property-info-left">
                                                                    <h3 class="property-item-title">
                                                                        <a href="{{ route('owner.property.show', $tenant->property->id) }}"
                                                                            class="color-heading link-hover-effect">{{ $tenant->property->name ?? __('Nekretnina nije dodeljena') }}</a>
                                                                    </h3>
                                                                    @if($tenant->property->address) {{-- Provera za adresu --}}
                                                                    <div class="property-item-address d-flex mt-15">
                                                                        <div class="flex-shrink-0 font-13">
                                                                            <i class="ri-map-pin-2-fill"></i>
                                                                        </div>
                                                                        <div class="flex-grow-1 ms-1">
                                                                            {{-- Pretpostavka: Property model ima adresu --}}
                                                                            <p>{{ $tenant->property->address->address ?? '' }}</p>
                                                                        </div>
                                                                    </div>
                                                                    @endif
                                                                    <div
                                                                        class="property-item-info mt-15 bg-white theme-border py-3 px-2 radius-4">
                                                                        <div class="row">
                                                                            <div class="col-sm-6 col-md-6">
                                                                                <div class="property-info-item property-info-item-left font-14">
                                                                                    <i class="ri-home-5-fill me-1 "></i>
                                                                                    {{-- Pretpostavka: Tenant ima relaciju ka Unit modelu ili unit_name polje --}}
                                                                                    {{ $tenant->unit->unit_name ?? ($tenant->unit_name ?? __('Jedinica nije dodeljena')) }}
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-sm-6 col-md-6">
                                                                                <div class="property-info-item property-info-item-right font-14">
                                                                                    <i class="ri-checkbox-circle-fill me-1 "></i>
                                                                                    @if ($tenant->status == TENANT_STATUS_ACTIVE)
                                                                                        {{ __('Trenutni Stanar') }}
                                                                                    @else
                                                                                        {{ __('Neaktivan Stanar') }}
                                                                                    @endif
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="tenants-details-home-details-lease-date mt-15">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <h6><span
                                                                                        class="theme-text-color me-2">{{ __('Datum Početka Zakupa') }}:</span>{{ $tenant->lease_start_date ? \Carbon\Carbon::parse($tenant->lease_start_date)->format(getOption('date_format', 'd.m.Y')) : 'N/A' }}
                                                                                </h6>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <h6><span
                                                                                        class="theme-text-color me-2">{{ __('Datum Završetka Zakupa') }}:</span>{{ $tenant->lease_end_date ? \Carbon\Carbon::parse($tenant->lease_end_date)->format(getOption('date_format', 'd.m.Y')) : __('Neograničeno') }}
                                                                                </h6>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        @else
                                                            <p class="p-25">{{ __('Stanaru nije dodeljena nekretnina.') }}</p>
                                                        @endif
                                                    </div>
                                                </div>
                                                <!-- Property Item End -->

                                                <!-- Tenants Details Home Details Edit Rent Information Start -->
                                                <div class="add-property-title border-bottom pb-15 mb-20 mt-25">
                                                    <h4>{{ __('Informacije o Kiriji') }}</h4>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6 col-lg-4 col-xl-4 col-xxl-4 mb-25">
                                                        <label
                                                            class="label-text-title color-heading font-medium mb-2">{{ __('Mesečna Kirija') }}</label>
                                                        <div class="input-group custom-input-group">
                                                            <input type="text" class="form-control"
                                                                value="{{ number_format($tenant->general_rent ?? 0, 2) }} {{ getOption('currency_symbol') }}" readonly>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-lg-4 col-xl-4 col-xxl-4 mb-25">
                                                        <label
                                                            class="label-text-title color-heading font-medium mb-2">{{ __('Depozit') }}</label>
                                                        <div class="input-group custom-input-group">
                                                            <input type="text" class="form-control"
                                                                value="{{ $tenant->security_deposit_type == TYPE_FIXED ? (number_format($tenant->security_deposit ?? 0, 2) . ' ' . getOption('currency_symbol')) : ($tenant->security_deposit ?? 0) . '%' }}"
                                                                readonly>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-lg-4 col-xl-4 col-xxl-4 mb-25">
                                                        <label
                                                            class="label-text-title color-heading font-medium mb-2">{{ __('Kazna za Kašnjenje') }}</label>
                                                        <div class="input-group custom-input-group">
                                                            <input type="text" class="form-control"
                                                                value="{{ $tenant->late_fee_type == TYPE_FIXED ? (number_format($tenant->late_fee ?? 0, 2) . ' ' . getOption('currency_symbol')) : ($tenant->late_fee ?? 0) . '%' }}" readonly>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-lg-4 col-xl-4 col-xxl-4 mb-25">
                                                        <label
                                                            class="label-text-title color-heading font-medium mb-2">{{ __('Priznanica za Incident') }}</label>
                                                        <div class="input-group custom-input-group">
                                                            <input type="text" class="form-control"
                                                                value="{{ number_format($tenant->incident_receipt ?? 0, 2) }} {{ getOption('currency_symbol') }}" readonly>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6 col-lg-4 mb-25">
                                                        <label
                                                            class="label-text-title color-heading font-medium mb-2">{{ __('Plaćanje dospeva dana') }}</label>
                                                            <input type="text" class="form-control"
                                                                value="{{ $tenant->due_date ? $tenant->due_date . '.' : 'N/A' }}" readonly>
                                                    </div>
                                                </div>
                                                <!-- Tenants Details Home Details Edit Rent Information End -->

                                                {{-- START: Lista Faktura za Stanara --}}
                                                <div class="add-property-title border-bottom pb-15 mb-20 mt-25">
                                                    <h4>{{ __('Istorija Faktura') }}</h4>
                                                </div>
                                                <div class="all-invoice-area">
                                                    @if($tenant->invoices && $tenant->invoices->count() > 0)
                                                        <div class="table-responsive">
                                                            <table class="table theme-border theme-table">
                                                                <thead>
                                                                    <tr>
                                                                        <th>{{ __('Broj Fakture') }}</th>
                                                                        <th>{{ __('Datum Dospeća') }}</th>
                                                                        <th>{{ __('Iznos') }}</th>
                                                                        <th>{{ __('Status') }}</th>
                                                                        <th>{{ __('Akcije') }}</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    @foreach ($tenant->invoices->sortByDesc('due_date') as $invoice)
                                                                        <tr>
                                                                            <td>
                                                                                <a href="{{ route('owner.invoice.details', $invoice->id) }}">{{ $invoice->invoice_no ?? $invoice->name }}</a>
                                                                            </td>
                                                                            <td>{{ $invoice->due_date ? \Carbon\Carbon::parse($invoice->due_date)->format(getOption('date_format', 'd.m.Y')) : 'N/A' }}</td>
                                                                            <td>{{ number_format($invoice->amount ?? 0, 2) }} {{ $invoice->currency_code ?? getOption('currency_symbol') }}</td>
                                                                            <td>
                                                                                @if ($invoice->status == INVOICE_STATUS_PAID)
                                                                                    <span class="status-btn status-btn-green font-13">{{ __('Plaćeno') }}</span>
                                                                                @elseif ($invoice->status == INVOICE_STATUS_PENDING)
                                                                                     @if(\Carbon\Carbon::parse($invoice->due_date)->isPast() && !\Carbon\Carbon::parse($invoice->due_date)->isToday())
                                                                                        <span class="status-btn status-btn-red font-13">{{ __('Dospelo') }}</span>
                                                                                     @else
                                                                                        <span class="status-btn status-btn-yellow font-13">{{ __('Na čekanju') }}</span>
                                                                                     @endif
                                                                                @elseif ($invoice->status == INVOICE_STATUS_OVERDUE)
                                                                                    <span class="status-btn status-btn-red font-13">{{ __('Dospelo') }}</span>
                                                                                @else
                                                                                     <span class="status-btn status-btn-gray font-13">{{ __('Status: ') . $invoice->status }}</span>
                                                                                @endif
                                                                            </td>
                                                                            <td>
                                                                                <a href="{{ route('owner.invoice.details', $invoice->id) }}" class="btn btn-sm btn-outline-primary" title="{{__('Detalji Fakture')}}"><i class="ri-eye-line"></i></a>
                                                                                {{-- Ovde možeš dodati i dugme za "Označi kao plaćeno" ako imaš tu funkcionalnost --}}
                                                                            </td>
                                                                        </tr>
                                                                    @endforeach
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    @else
                                                        <p>{{ __('Nema izdatih faktura za ovog stanara.') }}</p>
                                                    @endif
                                                </div>
                                                {{-- END: Lista Faktura za Stanara --}}

                                            </div>
                                        </div>
                                        <!-- Account Settings Content Box End -->
                                    </div>
                                    <!-- Tenants Home Details End -->
                                </div>
                            </div>
                            <!-- Account settings Area Right Side End-->
                        </div>
                    </div>
                    <!-- Tenants Details Layout Wrap Area row End -->
                </div>
                <!-- Page Content Wrapper End -->
            </div>
        </div>
        <!-- End Page-content -->
    </div>
@endsection

@push('style')
    {{-- Dodaj stilove ako su potrebni, npr. za statusne bedževe --}}
    <style>
        .status-btn {
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 500;
            color: #fff;
        }
        .status-btn-green { background-color: #198754; }
        .status-btn-orange { background-color: #fd7e14; }
        .status-btn-gray { background-color: #6c757d; }
        .status-btn-yellow { background-color: #ffc107; color: #000;}
        .status-btn-red { background-color: #dc3545; }
        .label-text-title { font-size: 0.9rem; }
    </style>
@endpush

@push('script')
    {{-- Nema specifičnog JS-a za ovaj prikaz, osim ako ne želiš neku interaktivnost --}}
@endpush