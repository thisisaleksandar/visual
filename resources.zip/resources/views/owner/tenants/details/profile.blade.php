@extends('owner.layouts.app')

@section('content')
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <!-- Page Content Wrapper Start -->
                <div class="page-content-wrapper bg-white p-30 radius-20">
                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div
                                class="page-title-box d-sm-flex align-items-center justify-content-between border-bottom mb-20">
                                <div class="page-title-left">
                                    <h3 class="mb-sm-0">{{ $pageTitle }} - {{ $tenant->user->first_name ?? '' }} {{ $tenant->user->last_name ?? '' }}</h3>
                                </div>
                                <div class="page-title-right"> {{-- ISPRAVLJENO SA <Udiv NA <div --}}
                                    <ol class="breadcrumb mb-0">
                                        <li class="breadcrumb-item"><a href="{{ route('owner.dashboard') }}"
                                                title="{{ __('Kontrolna tabla') }}">{{ __('Kontrolna tabla') }}</a></li>
                                        <li class="breadcrumb-item"><a href="{{ route('owner.tenant.index') }}"
                                                title="{{ __('Stanari') }}">{{ __('Stanari') }}</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">{{ $pageTitle }}</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <!-- Tenants Details Layout Wrap Area row Start -->
                    <div class="tenants-details-layout-wrap position-relative">
                        <div class="row">
                            <!-- Account settings Left Side Start-->
                            <div class="col-md-12 col-lg-12 col-xl-4 col-xxl-3">
                                <div class="account-settings-leftside bg-white theme-border radius-4 p-20 mb-25">
                                    <div class="tenants-details-leftsidebar-wrap d-flex flex-column h-100">
                                        @include('owner.tenants.details.sidenav', ['tenant' => $tenant])
                                        <div class="remove-tenants-item mt-auto">
                                            @if(isset($tenant->status) && (!defined('TENANT_STATUS_CLOSE') || $tenant->status != TENANT_STATUS_CLOSE)) {{-- Dodata provera za TENANT_STATUS_CLOSE konstantu --}}
                                                <button type="button" class="account-settings-menu-item red-color w-100 mb-2"
                                                    data-bs-toggle="modal" data-bs-target="#tenantCloseModal"
                                                    title="{{ __('Zatvori Ugovor') }}">
                                                    <span class="bg-red-transparent radius-4 overflow-hidden px-2 me-2"><i
                                                            class="ri-file-lock-line"></i></span>{{ __('Zatvori Ugovor') }}
                                                </button>
                                            @endif
                                            <button type="button" class="account-settings-menu-item red-color w-100"
                                                data-bs-toggle="modal" data-bs-target="#tenantDeleteModal"
                                                title="{{ __('Obriši Stanara') }}">
                                                <span class="bg-red-transparent radius-4 overflow-hidden px-2 me-2"><i
                                                        class="ri-delete-bin-2-line"></i></span>{{ __('Obriši Stanara') }}
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Account settings Left Side End-->

                            <!-- Account settings Area Right Side Start-->
                            <div class="col-md-12 col-lg-12 col-xl-8 col-xxl-9">
                                <div class="account-settings-rightside bg-off-white theme-border radius-4 p-25">
                                    <!-- Tenants Profile Information Start -->
                                    <div class="tenants-profile-information">
                                        <!-- Upload Profile Photo Box Start -->
                                        <div class="upload-profile-photo-box mb-25 text-center">
                                            <div class="profile-user position-relative d-inline-block">
                                                @if($tenant->image_id && $tenant->image && $tenant->image != asset('assets/images/no-image.jpg'))
                                                    <img src="{{ $tenant->image }}"
                                                        class="rounded-circle avatar-xl user-profile-image"
                                                        alt="{{ $tenant->user->first_name ?? 'Profilna slika' }}">
                                                @else
                                                    <div class="avatar-xl rounded-circle bg-secondary d-flex align-items-center justify-content-center user-profile-image" style="font-size: 3rem; color: white;">
                                                        <i class="ri-user-line"></i>
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                        <!-- Upload Profile Photo Box End -->

                                        <!-- Account Settings Content Box Start -->
                                        <div class="account-settings-content-box bg-white theme-border radius-4 mb-25 p-20">
                                            <div class="account-settings-title border-bottom mb-20 pb-20">
                                                <div class="row align-items-center">
                                                    <div class="col-md-6">
                                                        <h4>{{ __('Lične Informacije') }}</h4>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="property-details-right text-end">
                                                            <a href="{{ route('owner.tenant.edit', $tenant->id) }}"
                                                                class="edit-btn"
                                                                title="{{ __('Izmeni Informacije') }}">{{ __('Izmeni Informacije') }}<i
                                                                    class="ri-arrow-right-line ms-2"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="account-settings-info-box">
                                                <div class="row account-settings-info-item">
                                                    <div class="col-md-4 col-lg-3 col-xl-3 col-xxl-2">
                                                        <p class="color-heading">{{ __('Ime') }}:</p>
                                                    </div>
                                                    <div class="col-md-8 col-lg-9 col-xl-9 col-xxl-10">
                                                        <p>{{ $tenant->user->first_name ?? 'N/A' }} {{ $tenant->user->last_name ?? '' }}</p>
                                                    </div>
                                                </div>
                                                <div class="row account-settings-info-item">
                                                    <div class="col-md-4 col-lg-3 col-xl-3 col-xxl-2">
                                                        <p class="color-heading">{{ __('Kontakt Telefon') }}:</p>
                                                    </div>
                                                    <div class="col-md-8 col-lg-9 col-xl-9 col-xxl-10">
                                                        <p>{{ $tenant->user->contact_number ?? 'N/A' }}</p>
                                                    </div>
                                                </div>
                                                <div class="row account-settings-info-item">
                                                    <div class="col-md-4 col-lg-3 col-xl-3 col-xxl-2">
                                                        <p class="color-heading">{{ __('Email') }}:</p>
                                                    </div>
                                                    <div class="col-md-8 col-lg-9 col-xl-9 col-xxl-10">
                                                        <p>{{ $tenant->user->email ?? 'N/A' }}</p>
                                                    </div>
                                                </div>
                                                <div class="row account-settings-info-item">
                                                    <div class="col-md-4 col-lg-3 col-xl-3 col-xxl-2">
                                                        <p class="color-heading">{{ __('Starost') }}:</p>
                                                    </div>
                                                    <div class="col-md-8 col-lg-9 col-xl-9 col-xxl-10">
                                                        <p>{{ $tenant->age ?? 'N/A' }}</p>
                                                    </div>
                                                </div>
                                                <div class="row account-settings-info-item">
                                                    <div class="col-md-4 col-lg-3 col-xl-3 col-xxl-2">
                                                        <p class="color-heading">{{ __('Preferirani Način Plaćanja') }}:</p>
                                                    </div>
                                                    <div class="col-md-8 col-lg-9 col-xl-9 col-xxl-10">
                                                        <p class="fw-medium">
                                                            @if($tenant->preferred_payment_method == 'wu')
                                                                {{ __('Western Union (WU)') }}
                                                            @elseif($tenant->preferred_payment_method == 'postnet')
                                                                {{ __('PostNet') }}
                                                            @elseif($tenant->preferred_payment_method == 'bank_transfer')
                                                                {{ __('Na račun u banci') }}
                                                            @elseif($tenant->preferred_payment_method == 'cash')
                                                                {{ __('Gotovina') }}
                                                            @elseif($tenant->preferred_payment_method == 'manual')
                                                                {{ __('Ručni unos/Ostalo') }}
                                                            @else
                                                                {{ __('Nije navedeno') }}
                                                            @endif
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Account Settings Content Box End -->

                                        @if($tenant->permanent_address || ($tenant->permanent_city_id && ($tenant->permanentCity->name ?? false)) || $tenant->permanent_zip_code)
                                        <div class="account-settings-content-box bg-white theme-border radius-4 p-20">
                                            <div class="account-settings-title border-bottom mb-20 pb-20">
                                                <div class="row align-items-center">
                                                    <div class="col-md-6">
                                                        <h4>{{ __('Stalna Adresa') }}</h4>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="account-settings-info-box">
                                                @if($tenant->permanent_address)
                                                <div class="row account-settings-info-item">
                                                    <div class="col-md-4 col-lg-3 col-xl-3 col-xxl-2">
                                                        <p class="color-heading">{{ __('Adresa') }}:</p>
                                                    </div>
                                                    <div class="col-md-8 col-lg-9 col-xl-9 col-xxl-10">
                                                        <p>{{ $tenant->permanent_address }}</p>
                                                    </div>
                                                </div>
                                                @endif
                                                @if($tenant->permanent_city_id)
                                                <div class="row account-settings-info-item">
                                                    <div class="col-md-4 col-lg-3 col-xl-3 col-xxl-2">
                                                        <p class="color-heading">{{ __('Grad') }}:</p>
                                                    </div>
                                                    <div class="col-md-8 col-lg-9 col-xl-9 col-xxl-10">
                                                        <p>{{ $tenant->permanentCity->name ?? ($tenant->permanent_city_id ?? 'N/A') }}</p>
                                                    </div>
                                                </div>
                                                @endif
                                                @if($tenant->permanent_zip_code)
                                                <div class="row account-settings-info-item">
                                                    <div class="col-md-4 col-lg-3 col-xl-3 col-xxl-2">
                                                        <p class="color-heading">{{ __('Poštanski Broj') }}:</p>
                                                    </div>
                                                    <div class="col-md-8 col-lg-9 col-xl-9 col-xxl-10">
                                                        <p>{{ $tenant->permanent_zip_code }}</p>
                                                    </div>
                                                </div>
                                                @endif
                                            </div>
                                        </div>
                                        @endif
                                        <!-- Account Settings Content Box End: Stalna Adresa -->
                                    </div>
                                    <!-- Tenants Profile Information End -->
                                </div>
                            </div>
                            <!-- Account settings Area Right Side End-->
                        </div>
                    </div>
                    <!-- Tenants Details Layout Wrap Area row End -->
                </div>
                <!-- Page Content Wrapper End -->
            </div>
        </div>
        <!-- End Page-content -->
    </div>

    <!-- Tenant Close Modal Start -->
    <div class="modal fade" id="tenantCloseModal" tabindex="-1" aria-labelledby="tenantCloseModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="tenantCloseModalLabel">{{ __('Zatvaranje Ugovora Stanara') }}</h4>
                    @if(isset($paymentDueInvoiceCount) && $paymentDueInvoiceCount > 0)
                    <div class="account-settings-menu-item ms-auto"
                        title="{{ __('Ovaj stanar ima') }} {{ $paymentDueInvoiceCount }} {{ __('dospelih faktura') }}">
                        {{ __('Dospelih faktura:') }} <a href="{{ route('owner.invoice.index', ['tenant_id' => $tenant->id, 'status' => defined('INVOICE_STATUS_OVERDUE') ? INVOICE_STATUS_OVERDUE : 2 ]) }}"><span
                                class="bg-red-transparent red-color radius-4 overflow-hidden px-2 mx-2">{{ $paymentDueInvoiceCount }}</span></a>
                    </div>
                    @endif
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Zatvori"></button>
                </div>
                <form class="ajax" action="{{ route('owner.tenant.close.history.store', $tenant->id) }}"
                    method="POST" data-handler="closeStatusChange">
                    @csrf
                    <div class="modal-body">
                        <div class="modal-inner-form-box">
                            <div class="row">
                                <div class="col-md-12 mb-25">
                                    <p><strong>{{ __('Stanar') }}:</strong> {{ $tenant->user->first_name ?? '' }} {{ $tenant->user->last_name ?? '' }} ({{ $tenant->user->email ?? '' }})</p>
                                    <p><strong>{{ __('Nekretnina') }}:</strong> {{ $tenant->property->name ?? 'N/A' }} (Jedinica: {{ $tenant->unit->unit_name ?? ($tenant->unit_name ?? 'N/A') }})</p>
                                    <hr>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-25">
                                    <label
                                        class="label-text-title color-heading font-medium mb-2">{{ __('Iznos Povraćaja Depozita') }}</label>
                                    <input type="number" step="any" value="0" min="0"
                                        name="close_refund_amount" class="form-control"
                                        placeholder="{{ __('Iznos Povraćaja') }}">
                                </div>
                                <div class="col-md-6 mb-25">
                                    <label
                                        class="label-text-title color-heading font-medium mb-2">{{ __('Trošak Zatvaranja') }}</label>
                                    <input type="number" step="any" value="0" min="0"
                                        name="close_charge" class="form-control"
                                        placeholder="{{ __('Trošak Zatvaranja') }}">
                                </div>
                                <div class="col-md-6 mb-25">
                                    <label
                                        class="label-text-title color-heading font-medium mb-2">{{ __('Datum Zatvaranja') }}</label>
                                    <div class="custom-datepicker">
                                        <div class="custom-datepicker-inner position-relative">
                                            <input type="text" class="datepicker form-control" autocomplete="off"
                                                placeholder="dd.mm.gggg" name="close_date">
                                            <i class="ri-calendar-2-line"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-25">
                                    <label
                                        class="label-text-title color-heading font-medium mb-2">{{ __('Datum Završetka Zakupa (Originalni)') }}</label>
                                    <div class="custom-datepicker">
                                        <div class="custom-datepicker-inner position-relative">
                                            <input type="text" class="form-control"
                                                value="{{ $tenant->lease_end_date ? \Carbon\Carbon::parse($tenant->lease_end_date)->format('d.m.Y') : '' }}" disabled>
                                            <i class="ri-calendar-2-line"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 mb-25">
                                    <label
                                        class="label-text-title color-heading font-medium mb-2">{{ __('Razlog Zatvaranja') }}</label>
                                    <textarea name="close_reason" id="close_reason" class="form-control" placeholder="{{ __('Unesite razlog') }}"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-start">
                        <button type="button" class="theme-btn-back me-3" data-bs-dismiss="modal"
                            title="{{ __('Nazad') }}">{{ __('Nazad') }}</button>
                        <button type="submit" class="theme-btn me-3"
                            title="{{ __('Potvrdi') }}">{{ __('Potvrdi') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Tenant Close Modal End -->

    <!-- Tenant Delete Modal Start -->
    <div class="modal fade" id="tenantDeleteModal" tabindex="-1" aria-labelledby="tenantDeleteModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="tenantDeleteModalLabel">{{ __('Brisanje Stanara') }}</h4>
                     @if(isset($paymentDueInvoiceCount) && $paymentDueInvoiceCount > 0)
                    <div class="account-settings-menu-item ms-auto"
                        title="{{ __('Ovaj stanar ima') }} {{ $paymentDueInvoiceCount }} {{ __('dospelih faktura') }}">
                        {{ __('Dospelih faktura:') }} <a href="{{ route('owner.invoice.index', ['tenant_id' => $tenant->id, 'status' => defined('INVOICE_STATUS_OVERDUE') ? INVOICE_STATUS_OVERDUE : 2 ]) }}"><span
                                class="bg-red-transparent red-color radius-4 overflow-hidden px-2 mx-2">{{ $paymentDueInvoiceCount }}</span></a>
                    </div>
                    @endif
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Zatvori"></button>
                </div>
                <form class="ajax" action="{{ route('owner.tenant.delete') }}" method="POST"
                    data-handler="deleteShowResponse">
                    @csrf
                    <input type="hidden" name="tenant_id" value="{{ $tenant->id }}">
                    <div class="modal-body">
                        <div class="modal-inner-form-box">
                             <div class="row">
                                <div class="col-md-12 mb-25">
                                    <p><strong>{{ __('Stanar') }}:</strong> {{ $tenant->user->first_name ?? '' }} {{ $tenant->user->last_name ?? '' }} ({{ $tenant->user->email ?? '' }})</p>
                                    <p class="text-danger mt-2">{{ __('Da li ste sigurni da želite da obrišete ovog stanara? Ova akcija se ne može poništiti.') }}</p>
                                    <hr>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 mb-25">
                                    <label
                                        class="label-text-title color-heading font-medium mb-2">{{ __('Za potvrdu, unesite email stanara:') }}</label>
                                    <input type="email" name="email" class="form-control"
                                        placeholder="{{ $tenant->user->email ?? __('Email stanara') }}">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-start">
                        <button type="button" class="theme-btn-back me-3" data-bs-dismiss="modal"
                            title="{{ __('Nazad') }}">{{ __('Nazad') }}</button>
                        <button type="submit" class="theme-btn theme-btn-red me-3"
                            title="{{ __('Obriši') }}">{{ __('Obriši') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Tenant Delete Modal End -->

    <input type="hidden" id="tenantListRoute" value="{{ route('owner.tenant.index') }}">
@endsection

@push('style')
    <link rel="stylesheet" href="{{ asset('assets/libs/jquery-ui-datepicker/jquery-ui.min.css') }}">
    <style>
        .theme-btn-red {
            background-color: #dc3545;
            border-color: #dc3545;
            color: #fff;
        }
        .theme-btn-red:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
        .avatar-xl.bg-secondary {
            width: 100px;
            height: 100px;
        }
        .account-settings-info-item {
            padding-top: 0.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid #f0f0f0;
        }
        .account-settings-info-item:last-child {
            border-bottom: none;
        }
        .account-settings-info-item p {
            margin-bottom: 0;
        }
        .color-heading { font-weight: 500; }
        .account-settings-leftside .remove-tenants-item button { margin-top: 0.5rem; } /* Dodat razmak između dugmića */
    </style>
@endpush

@push('script')
    <script src="{{ asset('assets/libs/jquery-ui-datepicker/jquery-ui.min.js') }}"></script>
    <script src="{{ asset('assets/js/custom/tenant.js') }}"></script>
    <script>
        $(function() {
            if ($(".datepicker").length && typeof $.fn.datepicker === 'function' && typeof $.fn.datepicker.noConflict === 'function' ) {
                 $(".datepicker").datepicker({
                    dateFormat: "dd.mm.yy." // Primer formata, prilagodi ako je potrebno
                 });
            }
        });
    </script>
@endpush